using System.Text.RegularExpressions;
namespace FootballLeague.Services
{
    internal static class ValidationService
    {
        private static readonly string[] ValidPositions = { "GK", "DF", "MF", "FW" };
        public static string? ValidateFullName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "Името не може да е празно.";
            if (name.Trim().Length < 3) return "Името трябва да е поне 3 символа.";
            if (name.Trim().All(c => !char.IsLetter(c))) return "Името трябва да съдържа букви.";
            return null;
        }
        public static string? ValidateBirthDate(DateTime date)
        {
            if (date > DateTime.Today) return "Датата не може да е в бъдещето.";
            int age = DateTime.Today.Year - date.Year - (DateTime.Today.DayOfYear < date.DayOfYear ? 1 : 0);
            if (age < 10) return $"Твърде млад ({age} г.).";
            if (age > 60) return $"Невалидна дата ({age} г.).";
            return null;
        }
        public static string? ValidatePosition(string pos) =>
            !ValidPositions.Contains(pos) ? $"Позицията трябва да е: {string.Join(", ", ValidPositions)}." : null;
        public static string? ValidateClub(int clubId) => clubId <= 0 ? "Моля, изберете клуб." : null;
        public static string? ValidateSeason(string season)
        {
            if (!Regex.IsMatch(season.Trim(), @"^\d{4}/\d{4}$"))
                return "Сезонът трябва да е ГГГГ/ГГГГ (пример: 2025/2026).";
            var parts = season.Trim().Split("/");
            if (int.Parse(parts[1]) != int.Parse(parts[0]) + 1) return "Втората година трябва да е с 1 повече.";
            return null;
        }
        public static List<string> ValidatePlayer(string fullName, DateTime birthDate, string position, int clubId)
        {
            var errors = new List<string>();
            void Add(string? m) { if (m != null) errors.Add(m); }
            Add(ValidateFullName(fullName)); Add(ValidateBirthDate(birthDate));
            Add(ValidatePosition(position)); Add(ValidateClub(clubId));
            return errors;
        }
    }
}