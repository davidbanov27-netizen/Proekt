using FootballLeague.Models;
using FootballLeague.Repositories;
using FootballLeague.Services;
using MySql.Data.MySqlClient;

namespace FootballLeague.Forms
{
    public partial class LeaguesForm : Form
    {
        private readonly LeaguesRepository     _leaguesRepo = new();
        private readonly LeagueTeamsRepository _teamsRepo   = new();
        private readonly MatchesRepository     _matchesRepo = new();
        private readonly ClubsRepository       _clubsRepo   = new();

        private int    _selectedLeagueId   = -1;
        private string _selectedLeagueName = "";

        public LeaguesForm() { InitializeComponent(); }

        private void LeaguesForm_Load(object sender, EventArgs e)
        {
            // SplitContainer настройки след Shown (Width вече е реален)
            this.Shown += (s2, e2) =>
            {
                splitLeagues.Panel1MinSize = 250; splitLeagues.Panel2MinSize = 300;
                splitPart.Panel1MinSize    = 250; splitPart.Panel2MinSize    = 250;
                splitSched.Panel1MinSize   = 250; splitSched.Panel2MinSize   = 250;
                splitLeagues.SplitterDistance = Math.Max(250, (int)(splitLeagues.Width * 0.57));
                splitPart.SplitterDistance    = Math.Max(250, (int)(splitPart.Width    * 0.57));
                splitSched.SplitterDistance   = Math.Max(250, (int)(splitSched.Width   * 0.57));
            };
            GH.Style(dgvLeagues); GH.Style(dgvParticipants); StyleSchedule();
            btnEditLeague.Enabled = false; btnDeleteLeague.Enabled = false;
            LoadLeagues();
        }

        private void StyleSchedule()
        {
            GH.Style(dgvSchedule);
            dgvSchedule.RowTemplate.Height = 34;
            dgvSchedule.ColumnHeadersHeight = 38;
            dgvSchedule.CellFormatting += (s, e) => {
                if (e.RowIndex < 0 || dgvSchedule.Rows[e.RowIndex].DataBoundItem is not Match m) return;
                var colors = new[]{ Color.FromArgb(232,245,233),Color.FromArgb(227,242,253),Color.FromArgb(255,243,224),
                                    Color.FromArgb(243,229,245),Color.FromArgb(252,228,236),Color.FromArgb(224,247,250) };
                dgvSchedule.Rows[e.RowIndex].DefaultCellStyle.BackColor = colors[(m.RoundNo-1) % colors.Length];
                dgvSchedule.Rows[e.RowIndex].DefaultCellStyle.SelectionBackColor = Color.FromArgb(30,78,121);
            };
        }

        // ══ TAB 1 – ЛИГИ ══════════════════════════════════════════════════════
        private void LoadLeagues()
        {
            try
            {
                dgvLeagues.DataSource = _leaguesRepo.GetAll();
                GH.Hide(dgvLeagues, "LeagueId");
                GH.Hdr(dgvLeagues, "Name", "Лига / Първенство");
                GH.Hdr(dgvLeagues, "Season", "Сезон");
                GH.Hdr(dgvLeagues, "TeamCount", "Брой отбори");
                lblStatus.Text = $"Лиги: {dgvLeagues.RowCount}";
            }
            catch (Exception ex) { Err("Грешка при зареждане", ex); }
        }

        private void dgvLeagues_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvLeagues.CurrentRow?.DataBoundItem is League l)
            {
                _selectedLeagueId = l.LeagueId; _selectedLeagueName = l.Name;
                txtName.Text = l.Name; txtSeason.Text = l.Season; numTeamCount.Value = Math.Max(2, l.TeamCount);
                lblSel.Text = $"🏆  {l.Name}  ({l.Season})"; lblSel2.Text = $"📅  {l.Name}  ({l.Season})";
                btnEditLeague.Enabled = btnDeleteLeague.Enabled = true;
                LoadParticipants(); LoadSchedule();
            }
        }

        private void btnAddLeague_Click(object sender, EventArgs e)
        {
            if (!Val()) return;
            try
            {
                _leaguesRepo.Create(new League{Name=txtName.Text.Trim(),Season=txtSeason.Text.Trim(),TeamCount=(int)numTeamCount.Value});
                LoadLeagues(); ClearLeagueForm(); lblStatus.Text="✔  Лигата е добавена.";
                MessageBox.Show("Лигата е добавена!","Успех",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch(MySqlException ex) when(ex.Number==1062){Warn($"Лига \"{txtName.Text}\" ({txtSeason.Text}) вече съществува!");}
            catch(Exception ex){Err("Грешка при добавяне",ex);}
        }

        private void btnEditLeague_Click(object sender, EventArgs e)
        {
            if(_selectedLeagueId==-1){Warn("Изберете лига!");return;} if(!Val())return;
            try{_leaguesRepo.Update(new League{LeagueId=_selectedLeagueId,Name=txtName.Text.Trim(),Season=txtSeason.Text.Trim(),TeamCount=(int)numTeamCount.Value});LoadLeagues();lblStatus.Text="✔  Обновено.";}
            catch(MySqlException ex) when(ex.Number==1062){Warn("Тази комбинация вече съществува!");}
            catch(Exception ex){Err("Грешка при редакция",ex);}
        }

        private void btnDeleteLeague_Click(object sender, EventArgs e)
        {
            if(_selectedLeagueId==-1){Warn("Изберете лига!");return;}
            if(_leaguesRepo.HasParticipants(_selectedLeagueId)){MessageBox.Show("Не може — има участници. Премахни ги от Таб 2.","Забранено",MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
            if(MessageBox.Show($"Изтриване на \"{txtName.Text}\"?","Потвърди",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
            try{_leaguesRepo.Delete(_selectedLeagueId);LoadLeagues();ClearLeagueForm();dgvParticipants.DataSource=null;dgvSchedule.DataSource=null;lblSel.Text="— Изберете лига —";lblSel2.Text="— Изберете лига —";lblStatus.Text="✔  Изтрито.";}
            catch(Exception ex){Err("Грешка",ex);}
        }

        private void btnClearLeagueForm_Click(object s, EventArgs e) => ClearLeagueForm();

        private void ClearLeagueForm()
        { txtName.Text="";txtSeason.Text="";numTeamCount.Value=8;_selectedLeagueId=-1;dgvLeagues.ClearSelection();btnEditLeague.Enabled=btnDeleteLeague.Enabled=false; }

        // ══ TAB 2 – УЧАСТНИЦИ ═════════════════════════════════════════════════
        private void LoadParticipants()
        {
            if(_selectedLeagueId==-1)return;
            try
            {
                var parts=_teamsRepo.GetParticipants(_selectedLeagueId);var avail=_teamsRepo.GetAvailableClubs(_selectedLeagueId);
                dgvParticipants.DataSource=parts;GH.Hide(dgvParticipants,"ClubId","CreatedAt");
                GH.Hdr(dgvParticipants,"Name","Клуб");GH.Hdr(dgvParticipants,"City","Град");
                cboAvail.DataSource=avail;cboAvail.DisplayMember="Name";cboAvail.ValueMember="ClubId";
                lblPInfo.Text=$"Участници: {parts.Count}   |   Налични: {avail.Count}";
            }
            catch(Exception ex){Err("Грешка при участници",ex);}
        }

        private void btnAddClub_Click(object sender, EventArgs e)
        {
            if(_selectedLeagueId==-1){Warn("Изберете лига от Таб 1!");return;}
            if(cboAvail.SelectedItem is not Club club){Warn("Изберете клуб!");return;}
            try{_teamsRepo.AddClub(_selectedLeagueId,club.ClubId);LoadParticipants();}
            catch(MySqlException ex) when(ex.Number==1062){Warn($"\"{club.Name}\" вече участва!");}
            catch(Exception ex){Err("Грешка",ex);}
        }

        private void btnRemoveClub_Click(object sender, EventArgs e)
        {
            if(_selectedLeagueId==-1){Warn("Изберете лига!");return;}
            if(dgvParticipants.CurrentRow?.DataBoundItem is not Club club){Warn("Изберете участник!");return;}
            if(_leaguesRepo.HasMatches(_selectedLeagueId)){MessageBox.Show("Не може — вече има програма! Изтрий я от Таб 3.","Забранено",MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
            if(MessageBox.Show($"Премахване на \"{club.Name}\"?","Потвърди",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
            try{_teamsRepo.RemoveClub(_selectedLeagueId,club.ClubId);LoadParticipants();}
            catch(Exception ex){Err("Грешка",ex);}
        }

        // ══ TAB 3 – ПРОГРАМА ══════════════════════════════════════════════════
        private void LoadSchedule()
        {
            if(_selectedLeagueId==-1)return;
            try
            {
                int? round=numFR.Value>0?(int?)numFR.Value:null;
                var matches=_matchesRepo.GetMatches(_selectedLeagueId,round);
                dgvSchedule.DataSource=matches;
                GH.Hide(dgvSchedule,"MatchId","LeagueId","HomeClubId","HomeClubName","HomeClubCity","AwayClubId","AwayClubName","AwayClubCity","MatchDate","HomePlayers","AwayPlayers","IsPlayed","LeagueName","Stadium","HomeGoals","AwayGoals");
                if(dgvSchedule.Columns["RoundNo"]!=null){dgvSchedule.Columns["RoundNo"]!.Visible=true;dgvSchedule.Columns["RoundNo"]!.HeaderText="Кръг";dgvSchedule.Columns["RoundNo"]!.FillWeight=8;dgvSchedule.Columns["RoundNo"]!.DefaultCellStyle.Alignment=DataGridViewContentAlignment.MiddleCenter;dgvSchedule.Columns["RoundNo"]!.DefaultCellStyle.Font=new Font("Segoe UI",10f,FontStyle.Bold);}
                if(dgvSchedule.Columns["Домакин"]!=null){dgvSchedule.Columns["Домакин"]!.Visible=true;dgvSchedule.Columns["Домакин"]!.HeaderText="🏠  Домакин";dgvSchedule.Columns["Домакин"]!.FillWeight=38;}
                if(dgvSchedule.Columns["Резултат"]!=null){dgvSchedule.Columns["Резултат"]!.Visible=true;dgvSchedule.Columns["Резултат"]!.HeaderText="⚽  Резултат";dgvSchedule.Columns["Резултат"]!.FillWeight=14;}
                if(dgvSchedule.Columns["Гост"]!=null){dgvSchedule.Columns["Гост"]!.Visible=true;dgvSchedule.Columns["Гост"]!.HeaderText="✈  Гост";dgvSchedule.Columns["Гост"]!.FillWeight=38;}
                if(dgvSchedule.Columns["Дата"]!=null){dgvSchedule.Columns["Дата"]!.Visible=true;dgvSchedule.Columns["Дата"]!.HeaderText="📅  Дата";dgvSchedule.Columns["Дата"]!.FillWeight=12;}
                int maxR=matches.Count>0?matches.Max(m=>m.RoundNo):0;
                lblSInfo.Text=matches.Count>0?$"Мачове: {matches.Count}   |   Кръгове: {maxR}":"Няма програма.";
                btnDelSch.Enabled=matches.Count>0;
            }
            catch(Exception ex){Err("Грешка при програма",ex);}
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if(_selectedLeagueId==-1){Warn("Изберете лига!");return;}
            var parts=_teamsRepo.GetParticipants(_selectedLeagueId);
            if(parts.Count<2){MessageBox.Show("Нужни са поне 2 участника!\nДобавете отбори от Таб 2.","Недостатъчно",MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
            if(_leaguesRepo.HasMatches(_selectedLeagueId))if(MessageBox.Show("Вече има програма! Да се презапише?","Внимание",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;
            bool two=chkTwo.Checked;int n=parts.Count;int rounds=two?(n%2==0?(n-1)*2:n*2):(n%2==0?n-1:n);int per=n/2;
            if(MessageBox.Show($"Генериране:\n🏆 {_selectedLeagueName}\n👥 Участници: {n}\n🔄 Кръгове: {rounds}\n⚽ Мача на кръг: {per}\n📋 Общо: {rounds*per}\n{(two?"Двоен кръговник":"Единичен кръговник")}\n\nПотвърждавате?","Потвърди",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
            try
            {
                int total=_matchesRepo.GenerateSchedule(_selectedLeagueId,parts.Select(c=>c.ClubId).ToList(),two);
                LoadSchedule();MessageBox.Show($"✔  Генерирани {total} мача в {rounds} кръга!","Успех!",MessageBoxButtons.OK,MessageBoxIcon.Information);
                tabMain.SelectedTab=tabSchedule;
            }
            catch(Exception ex){Err("Грешка при генериране",ex);}
        }

        private void btnAutoCreate_Click(object sender, EventArgs e)
        {
            using var dlg=new AutoLeagueDialog(_clubsRepo.GetAll());
            if(dlg.ShowDialog()!=DialogResult.OK)return;
            var(name,season,clubIds,twoLegs)=dlg.Result;
            try
            {
                _leaguesRepo.Create(new League{Name=name,Season=season,TeamCount=clubIds.Count});
                var leagues=_leaguesRepo.GetAll();var nl=leagues.FirstOrDefault(l=>l.Name==name&&l.Season==season);
                if(nl==null)throw new Exception("Лигата не беше намерена.");
                foreach(var cid in clubIds)_teamsRepo.AddClub(nl.LeagueId,cid);
                int n=clubIds.Count;int rounds=twoLegs?(n%2==0?(n-1)*2:n*2):(n%2==0?n-1:n);
                int total=_matchesRepo.GenerateSchedule(nl.LeagueId,clubIds,twoLegs);
                LoadLeagues();
                foreach(DataGridViewRow row in dgvLeagues.Rows)if(row.DataBoundItem is League l&&l.LeagueId==nl.LeagueId){dgvLeagues.CurrentCell=row.Cells[0];break;}
                tabMain.SelectedTab=tabSchedule;
                MessageBox.Show($"🏆  Лигата е създадена!\n\nЛига: {name} ({season})\nУчастници: {clubIds.Count}\nКръгове: {rounds}\nМачове: {total}","Успешно!",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch(MySqlException ex) when(ex.Number==1062){Warn($"Лига \"{name}\" ({season}) вече съществува!");}
            catch(Exception ex){Err("Грешка при автоматично създаване",ex);}
        }

        private void btnDelSch_Click(object sender, EventArgs e)
        {
            if(_selectedLeagueId==-1)return;
            if(MessageBox.Show("Изтриване на цялата програма?","Потвърди",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;
            try{_matchesRepo.DeleteSchedule(_selectedLeagueId);LoadSchedule();}
            catch(Exception ex){Err("Грешка",ex);}
        }

        private void btnShowRound_Click(object s,EventArgs e)=>LoadSchedule();
        private void btnShowAll_Click(object s,EventArgs e){numFR.Value=0;LoadSchedule();}
        private void btnRefresh_Click(object s,EventArgs e){LoadLeagues();LoadParticipants();LoadSchedule();}

        private bool Val()
        {
            if(string.IsNullOrWhiteSpace(txtName.Text)){Warn("Името не може да е празно!");return false;}
            var err=ValidationService.ValidateSeason(txtSeason.Text);if(err!=null){Warn(err);return false;}
            if(numTeamCount.Value<2){Warn("Броят трябва да е поне 2!");return false;}
            return true;
        }
        private void Warn(string m)=>MessageBox.Show(m,"Внимание",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        private void Err(string m,Exception ex){MessageBox.Show($"{m}:\n\n{ex.Message}","Грешка",MessageBoxButtons.OK,MessageBoxIcon.Error);lblStatus.Text=$"✘ {m}";}
    }
}
