using FootballLeague.Models;
using FootballLeague.Repositories;
using MySql.Data.MySqlClient;
namespace FootballLeague.Forms
{
    public partial class ClubsForm : Form
    {
        private readonly ClubsRepository _repo = new();
        private int _selectedId = -1;
        public ClubsForm() { InitializeComponent(); }
        private void ClubsForm_Load(object sender, EventArgs e) { GH.Style(dgvClubs); LoadClubs(); }
        private void LoadClubs()
        {
            try
            {
                dgvClubs.DataSource = _repo.GetAll();
                GH.Hide(dgvClubs, "ClubId", "CreatedAt");
                GH.Hdr(dgvClubs, "Name", "Клуб"); GH.Hdr(dgvClubs, "City", "Град");
                lblStatus.Text = $"Клубове: {dgvClubs.RowCount}";
            }
            catch (Exception ex) { Err("Грешка при зареждане", ex); }
        }
        private void dgvClubs_SelectionChanged(object sender, EventArgs e)
        { if (dgvClubs.CurrentRow?.DataBoundItem is Club c) { _selectedId=c.ClubId; txtName.Text=c.Name; txtCity.Text=c.City; } }
        private void btnLoad_Click(object s, EventArgs e) => LoadClubs();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Val()) return;
            try { _repo.Add(new Club{Name=txtName.Text,City=txtCity.Text}); LoadClubs(); Clear(); MessageBox.Show("Клубът е добавен!","Успех",MessageBoxButtons.OK,MessageBoxIcon.Information); }
            catch (MySqlException ex) when (ex.Number==1062) { Warn($"\"{txtName.Text}\" вече съществува!"); }
            catch (Exception ex) { Err("Грешка",ex); }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (_selectedId==-1){Warn("Изберете клуб!");return;} if(!Val())return;
            try { _repo.Update(new Club{ClubId=_selectedId,Name=txtName.Text,City=txtCity.Text}); LoadClubs(); MessageBox.Show("Обновено!","Успех",MessageBoxButtons.OK,MessageBoxIcon.Information); }
            catch (MySqlException ex) when (ex.Number==1062) { Warn($"\"{txtName.Text}\" вече съществува!"); }
            catch (Exception ex) { Err("Грешка",ex); }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_selectedId==-1){Warn("Изберете клуб!");return;}
            if(MessageBox.Show($"Изтриване на \"{txtName.Text}\"?","Потвърди",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
            try { _repo.Delete(_selectedId); LoadClubs(); Clear(); }
            catch (MySqlException ex) when (ex.Number==1451) { Warn("Не може — клубът има свързани записи."); }
            catch (Exception ex) { Err("Грешка",ex); }
        }
        private void btnClear_Click(object s, EventArgs e) => Clear();
        private bool Val() { if(string.IsNullOrWhiteSpace(txtName.Text)){Warn("Името не може да е празно!");return false;} return true; }
        private void Clear() { txtName.Text="";txtCity.Text="";_selectedId=-1;dgvClubs.ClearSelection(); }
        private void Warn(string m) => MessageBox.Show(m,"Внимание",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        private void Err(string m,Exception ex) { MessageBox.Show($"{m}:\n{ex.Message}","Грешка",MessageBoxButtons.OK,MessageBoxIcon.Error); lblStatus.Text=$"✘ {m}"; }
    }
}
