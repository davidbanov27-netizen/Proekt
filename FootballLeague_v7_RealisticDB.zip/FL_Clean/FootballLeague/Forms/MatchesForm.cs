using FootballLeague.Models;
using FootballLeague.Repositories;

namespace FootballLeague.Forms
{
    public partial class MatchesForm : Form
    {
        private readonly MatchesRepository  _matchRepo   = new();
        private readonly EventsRepository   _eventsRepo  = new();
        private readonly ClubsRepository    _clubsRepo   = new();
        private readonly PlayersRepository  _playersRepo = new();
        private readonly LeaguesRepository  _leaguesRepo = new();

        private int    _selectedMatchId = -1;
        private Match? _selectedMatch   = null;

        private List<Player> _homePlayers     = new();
        private List<Player> _awayPlayers     = new();
        private List<Player> _allMatchPlayers = new();

        public MatchesForm() { InitializeComponent(); }

        private void MatchesForm_Load(object sender, EventArgs e)
        {
            // SplitContainer настройки - задаваме при реален Width
            this.Shown += (s2, e2) =>
            {
                splitMatches.Panel1MinSize    = 250;
                splitMatches.Panel2MinSize    = 280;
                splitMatches.SplitterDistance = Math.Max(250, (int)(splitMatches.Width * 0.57));
            };
            // При смяна на главен таб - задаваме splitters за event табовете
            tabMain.SelectedIndexChanged += (st, et) =>
            {
                if (tabMain.SelectedTab == tabEvents)
                    this.BeginInvoke(new Action(SetEventSplitters));
            };
            // При смяна на вътрешен таб (Голове/Картони/Фалове)
            tabEvents2.SelectedIndexChanged += (st, et) =>
                this.BeginInvoke(new Action(SetEventSplitters));
            StyleGrids();
            LoadFilterCombos();
            LoadMatches();
            // Инициализираме combo-тата за играчи с placeholder
            ClearMatchPlayers();
        }

        private void StyleGrids()
        {
            foreach (var dgv in new[] { dgvMatches, dgvGoals, dgvCards, dgvFouls })
                GH.Style(dgv);
            dgvMatches.RowTemplate.Height = 36;
            dgvMatches.Font = new Font("Segoe UI", 9.5f);
        }

        // ══ ФИЛТРИ ════════════════════════════════════════════════════════════
        private void LoadFilterCombos()
        {
            var leagues = _leaguesRepo.GetAll();
            var clubs   = _clubsRepo.GetAll();

            cboFilterLeague.Items.Clear();
            cboFilterLeague.Items.Add(new ComboItem(0, "— Всички лиги —"));
            foreach (var l in leagues)
                cboFilterLeague.Items.Add(new ComboItem(l.LeagueId, $"{l.Name} ({l.Season})"));
            cboFilterLeague.SelectedIndex = 0;

            cboFilterClub.Items.Clear();
            cboFilterClub.Items.Add(new ComboItem(0, "— Всички отбори —"));
            foreach (var c in clubs)
                cboFilterClub.Items.Add(new ComboItem(c.ClubId, c.Name));
            cboFilterClub.SelectedIndex = 0;

            cboLeague.Items.Clear();
            cboLeague.Items.Add(new ComboItem(0, "— Избери лига —"));
            foreach (var l in leagues)
                cboLeague.Items.Add(new ComboItem(l.LeagueId, $"{l.Name} ({l.Season})"));
            cboLeague.SelectedIndex = 0;

            foreach (var cbo in new[] { cboHomeClub, cboAwayClub })
            {
                cbo.Items.Clear();
                cbo.Items.Add(new ComboItem(0, "— Избери отбор —"));
                foreach (var c in clubs)
                    cbo.Items.Add(new ComboItem(c.ClubId, c.Name));
                cbo.SelectedIndex = 0;
            }
        }

        // ══ ТАБ 1 – МАЧОВЕ ═══════════════════════════════════════════════════
        private void LoadMatches()
        {
            try
            {
                int? lid = (cboFilterLeague.SelectedItem as ComboItem)?.Id;
                int? cid = (cboFilterClub.SelectedItem   as ComboItem)?.Id;
                int? rnd = numFilterRound.Value > 0 ? (int?)numFilterRound.Value : null;

                var matches = _matchRepo.GetMatches(
                    lid > 0 ? lid : null,
                    rnd,
                    cid > 0 ? cid : null);

                dgvMatches.DataSource = matches;

                GH.Hide(dgvMatches, "MatchId", "LeagueId", "RoundNo", "HomeClubId", "HomeClubName",
                    "HomeClubCity", "AwayClubId", "AwayClubName", "AwayClubCity",
                    "MatchDate", "Stadium", "HomeGoals", "AwayGoals", "HomePlayers", "AwayPlayers", "IsPlayed");

                ShowCol(dgvMatches, "LeagueName", "Лига",       15);
                ShowCol(dgvMatches, "Домакин",    "🏠 Домакин", 25);
                ShowCol(dgvMatches, "Резултат",   "⚽ Резултат",12);
                ShowCol(dgvMatches, "Гост",       "✈ Гост",     25);
                ShowCol(dgvMatches, "Дата",       "📅 Дата",    13);

                dgvMatches.CellFormatting -= DgvMatches_CellFormat;
                dgvMatches.CellFormatting += DgvMatches_CellFormat;

                lblMatchStatus.Text = $"Мачове: {matches.Count}";
            }
            catch (Exception ex) { Err("Грешка при зареждане", ex); }
        }

        private void DgvMatches_CellFormat(object? s, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || dgvMatches.Rows[e.RowIndex].DataBoundItem is not Match m) return;
            dgvMatches.Rows[e.RowIndex].DefaultCellStyle.BackColor =
                m.IsPlayed ? Color.FromArgb(232, 245, 233) : Color.FromArgb(255, 249, 230);
        }

        private static void ShowCol(DataGridView dgv, string col, string hdr, int weight)
        {
            if (dgv.Columns[col] == null) return;
            dgv.Columns[col]!.Visible    = true;
            dgv.Columns[col]!.HeaderText = hdr;
            dgv.Columns[col]!.FillWeight = weight;
        }

        private void dgvMatches_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvMatches.CurrentRow?.DataBoundItem is Match m)
            {
                _selectedMatchId = m.MatchId;
                _selectedMatch   = m;

                SetCombo(cboLeague,   m.LeagueId);
                numRound.Value    = m.RoundNo;
                SetCombo(cboHomeClub, m.HomeClubId);
                SetCombo(cboAwayClub, m.AwayClubId);
                dtpMatchDate.Value = m.MatchDate ?? DateTime.Today;
                txtStadium.Text    = m.Stadium;

                string title = $"{m.HomeClubName}  {m.Резултат}  {m.AwayClubName}  ({m.Дата})";
                lblSelectedMatch.Text  = $"🏟️  {title}";
                lblSelectedMatch2.Text = $"🏟️  {title}";

                numHomeGoals.Value = m.HomeGoals ?? 0;
                numAwayGoals.Value = m.AwayGoals ?? 0;

                LoadMatchPlayers(m.HomeClubId, m.AwayClubId);
                LoadEvents();

                btnEditMatch.Enabled   = true;
                btnDeleteMatch.Enabled = true;
            }
        }

        private void LoadMatchPlayers(int homeId, int awayId)
        {
            _homePlayers     = _playersRepo.GetPlayers(homeId);
            _awayPlayers     = _playersRepo.GetPlayers(awayId);
            _allMatchPlayers = _homePlayers.Concat(_awayPlayers).ToList();

            foreach (var cbo in new[] { cboGoalPlayer, cboCardPlayer, cboFoulPlayer })
            {
                cbo.Items.Clear();
                if (_allMatchPlayers.Count == 0)
                {
                    cbo.Items.Add(new ComboItem(0, "— Няма играчи за тези отбори —"));
                }
                else
                {
                    cbo.Items.Add(new ComboItem(0, "— Избери играч —"));
                    foreach (var p in _allMatchPlayers)
                        cbo.Items.Add(new ComboItem(p.PlayerId,
                            $"{p.FullName}  [{p.ClubName}  |  {p.Position}]"));
                }
                cbo.SelectedIndex = 0;
            }
            lblEventsCount.Text += _allMatchPlayers.Count > 0
                ? $"  |  Играчи: {_allMatchPlayers.Count}"
                : "  ⚠ Добавете играчи към клубовете!";
        }

        private void ClearMatchPlayers()
        {
            _homePlayers.Clear();
            _awayPlayers.Clear();
            _allMatchPlayers.Clear();
            foreach (var cbo in new[] { cboGoalPlayer, cboCardPlayer, cboFoulPlayer })
            {
                cbo.Items.Clear();
                cbo.Items.Add(new ComboItem(0, "— Изберете мач от Таб 1 —"));
                cbo.SelectedIndex = 0;
            }
        }

        // ── CRUD Мачове ──────────────────────────────────────────────────────
        private void btnAddMatch_Click(object sender, EventArgs e)
        {
            var m = BuildMatchFromForm(); if (m == null) return;
            try
            {
                _matchRepo.Add(m); LoadMatches(); ClearMatchForm();
                MessageBox.Show("Мачът е добавен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { Err("Грешка при добавяне", ex); }
        }

        private void btnEditMatch_Click(object sender, EventArgs e)
        {
            if (_selectedMatchId == -1) { Warn("Изберете мач!"); return; }
            var m = BuildMatchFromForm(); if (m == null) return;
            m.MatchId = _selectedMatchId;
            try
            {
                _matchRepo.Update(m); LoadMatches();
                MessageBox.Show("Обновено!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { Err("Грешка при редакция", ex); }
        }

        private void btnDeleteMatch_Click(object sender, EventArgs e)
        {
            if (_selectedMatchId == -1) { Warn("Изберете мач!"); return; }
            if (MessageBox.Show($"Изтриване на мача?\n{_selectedMatch?.HomeClubName} – {_selectedMatch?.AwayClubName}",
                "Потвърди", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try { _matchRepo.Delete(_selectedMatchId); LoadMatches(); ClearMatchForm(); }
            catch (Exception ex) { Err("Грешка при изтриване", ex); }
        }

        private Match? BuildMatchFromForm()
        {
            var li = cboLeague.SelectedItem   as ComboItem;
            var hi = cboHomeClub.SelectedItem as ComboItem;
            var ai = cboAwayClub.SelectedItem as ComboItem;

            if (li == null || li.Id == 0) { Warn("Изберете лига!"); return null; }
            if (hi == null || hi.Id == 0) { Warn("Изберете домакин!"); return null; }
            if (ai == null || ai.Id == 0) { Warn("Изберете гост!"); return null; }
            if (hi.Id == ai.Id) { Warn("Домакинът и гостът не могат да са един и същ отбор!"); return null; }

            return new Match
            {
                LeagueId   = li.Id,
                RoundNo    = (int)numRound.Value,
                HomeClubId = hi.Id,
                AwayClubId = ai.Id,
                MatchDate  = dtpMatchDate.Value.Date,
                Stadium    = txtStadium.Text.Trim()
            };
        }

        private void ClearMatchForm()
        {
            cboLeague.SelectedIndex = cboHomeClub.SelectedIndex = cboAwayClub.SelectedIndex = 0;
            numRound.Value = 1; txtStadium.Text = "";
            _selectedMatchId = -1; _selectedMatch = null;
            dgvMatches.ClearSelection();
            btnEditMatch.Enabled = btnDeleteMatch.Enabled = false;
            lblSelectedMatch.Text  = "— Изберете мач от Таб 1 —";
            lblSelectedMatch2.Text = "— Изберете мач от Таб 1 —";
            numHomeGoals.Value = 0; numAwayGoals.Value = 0;
            lblResultStatus.Text = "";
            ClearMatchPlayers();
            lblEventsCount.Text = "";
        }

        private void cboFilterLeague_SelectedIndexChanged(object s, EventArgs e) => LoadMatches();
        private void cboFilterClub_SelectedIndexChanged(object s, EventArgs e)   => LoadMatches();
        private void btnFilterRound_Click(object s, EventArgs e)                  => LoadMatches();
        private void btnClearFilters_Click(object s, EventArgs e)
        { cboFilterLeague.SelectedIndex = 0; cboFilterClub.SelectedIndex = 0; numFilterRound.Value = 0; LoadMatches(); }

        // ══ ТАБ 2 – РЕЗУЛТАТ ═════════════════════════════════════════════════
        private void btnSaveResult_Click(object sender, EventArgs e)
        {
            if (_selectedMatchId == -1) { Warn("Изберете мач от Таб 1!"); return; }
            try
            {
                _matchRepo.SaveResult(_selectedMatchId, (int)numHomeGoals.Value, (int)numAwayGoals.Value);
                LoadMatches();
                lblResultStatus.Text = $"✔  Резултат записан: {numHomeGoals.Value} : {numAwayGoals.Value}";
                MessageBox.Show(
                    $"Резултатът е записан:\n{_selectedMatch?.HomeClubName}  {numHomeGoals.Value} : {numAwayGoals.Value}  {_selectedMatch?.AwayClubName}",
                    "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { Err("Грешка при записване на резултат", ex); }
        }

        private void btnAutoCalcResult_Click(object sender, EventArgs e)
        {
            if (_selectedMatchId == -1 || _selectedMatch == null) { Warn("Изберете мач!"); return; }
            var (h, a) = _eventsRepo.CountGoals(_selectedMatchId, _selectedMatch.HomeClubId);
            numHomeGoals.Value = h;
            numAwayGoals.Value = a;
            lblResultStatus.Text = $"Изчислено от голове: {h} : {a}  (натисни Запиши за да запазиш)";
        }

        // ══ ТАБ 3 – СЪБИТИЯ ══════════════════════════════════════════════════
        private void LoadEvents()
        {
            if (_selectedMatchId == -1) return;
            try
            {
                var goals = _eventsRepo.GetGoals(_selectedMatchId);
                dgvGoals.DataSource = goals;
                GH.Hide(dgvGoals, "GoalId", "MatchId", "PlayerId", "ClubId", "IsOwnGoal");
                GH.Hdr(dgvGoals, "Минута", "⏱"); GH.Hdr(dgvGoals, "PlayerName", "Играч");
                GH.Hdr(dgvGoals, "ClubName", "Отбор"); GH.Hdr(dgvGoals, "Тип", "Вид");
                lblGoalsCount.Text = $"Голове: {goals.Count}";

                var cards = _eventsRepo.GetCards(_selectedMatchId);
                dgvCards.DataSource = cards;
                GH.Hide(dgvCards, "CardId", "MatchId", "PlayerId", "ClubId", "CardType");
                GH.Hdr(dgvCards, "Минута", "⏱"); GH.Hdr(dgvCards, "PlayerName", "Играч");
                GH.Hdr(dgvCards, "ClubName", "Отбор"); GH.Hdr(dgvCards, "Тип", "Картон");

                var fouls = _eventsRepo.GetFouls(_selectedMatchId);
                dgvFouls.DataSource = fouls;
                GH.Hide(dgvFouls, "FoulId", "MatchId", "PlayerId", "ClubId");
                GH.Hdr(dgvFouls, "Минута", "⏱"); GH.Hdr(dgvFouls, "PlayerName", "Играч");
                GH.Hdr(dgvFouls, "ClubName", "Отбор"); GH.Hdr(dgvFouls, "FoulType", "Вид нарушение");

                lblEventsCount.Text = $"Голове: {goals.Count}  |  Картони: {cards.Count}  |  Фалове: {fouls.Count}";
            }
            catch (Exception ex) { Err("Грешка при зареждане на събития", ex); }
        }

        private void btnAddGoal_Click(object sender, EventArgs e)
        {
            if (_selectedMatchId == -1 || _selectedMatch == null) { Warn("Изберете мач!"); return; }
            var pi = cboGoalPlayer.SelectedItem as ComboItem;
            if (pi == null || pi.Id == 0) { Warn("Изберете играч!"); return; }
            var player = _allMatchPlayers.FirstOrDefault(p => p.PlayerId == pi.Id);
            if (player == null) { Warn("Играчът не е намерен!"); return; }
            if (player.ClubId != _selectedMatch.HomeClubId && player.ClubId != _selectedMatch.AwayClubId)
            { Warn("Играчът не принадлежи на нито един от двата отбора в мача!"); return; }
            try
            {
                _eventsRepo.AddGoal(new Goal
                {
                    MatchId   = _selectedMatchId,
                    PlayerId  = player.PlayerId,
                    ClubId    = player.ClubId,
                    Minute    = (int)numGoalMinute.Value,
                    IsOwnGoal = chkOwnGoal.Checked
                });
                LoadEvents();
                lblGoalsCount.Text = "✔  Голът е добавен.";
            }
            catch (Exception ex) { Err("Грешка при добавяне на гол", ex); }
        }

        private void btnDeleteGoal_Click(object sender, EventArgs e)
        {
            if (dgvGoals.CurrentRow?.DataBoundItem is not Goal g) { Warn("Изберете гол!"); return; }
            if (MessageBox.Show("Изтриване на гола?", "Потвърди", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try { _eventsRepo.DeleteGoal(g.GoalId); LoadEvents(); }
            catch (Exception ex) { Err("Грешка", ex); }
        }

        private void btnAddCard_Click(object sender, EventArgs e)
        {
            if (_selectedMatchId == -1 || _selectedMatch == null) { Warn("Изберете мач!"); return; }
            var pi = cboCardPlayer.SelectedItem as ComboItem;
            if (pi == null || pi.Id == 0) { Warn("Изберете играч!"); return; }
            var player = _allMatchPlayers.FirstOrDefault(p => p.PlayerId == pi.Id);
            if (player == null) { Warn("Играчът не е намерен!"); return; }
            if (player.ClubId != _selectedMatch.HomeClubId && player.ClubId != _selectedMatch.AwayClubId)
            { Warn("Играчът не е от нито един от двата отбора!"); return; }
            try
            {
                _eventsRepo.AddCard(new Card
                {
                    MatchId  = _selectedMatchId,
                    PlayerId = player.PlayerId,
                    CardType = rbRedCard.Checked ? "Red" : "Yellow",
                    Minute   = (int)numCardMinute.Value
                });
                LoadEvents();
            }
            catch (Exception ex) { Err("Грешка при добавяне на картон", ex); }
        }

        private void btnDeleteCard_Click(object sender, EventArgs e)
        {
            if (dgvCards.CurrentRow?.DataBoundItem is not Card c) { Warn("Изберете картон!"); return; }
            if (MessageBox.Show("Изтриване?", "Потвърди", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try { _eventsRepo.DeleteCard(c.CardId); LoadEvents(); }
            catch (Exception ex) { Err("Грешка", ex); }
        }

        private void btnAddFoul_Click(object sender, EventArgs e)
        {
            if (_selectedMatchId == -1 || _selectedMatch == null) { Warn("Изберете мач!"); return; }
            var pi = cboFoulPlayer.SelectedItem as ComboItem;
            if (pi == null || pi.Id == 0) { Warn("Изберете играч!"); return; }
            var player = _allMatchPlayers.FirstOrDefault(p => p.PlayerId == pi.Id);
            if (player == null) { Warn("Играчът не е намерен!"); return; }
            if (player.ClubId != _selectedMatch.HomeClubId && player.ClubId != _selectedMatch.AwayClubId)
            { Warn("Играчът не е от нито един от двата отбора!"); return; }
            try
            {
                _eventsRepo.AddFoul(new Foul
                {
                    MatchId  = _selectedMatchId,
                    PlayerId = player.PlayerId,
                    Minute   = (int)numFoulMinute.Value,
                    FoulType = cboFoulType.SelectedItem?.ToString() ?? ""
                });
                LoadEvents();
            }
            catch (Exception ex) { Err("Грешка при добавяне на фал", ex); }
        }

        private void btnDeleteFoul_Click(object sender, EventArgs e)
        {
            if (dgvFouls.CurrentRow?.DataBoundItem is not Foul f) { Warn("Изберете фал!"); return; }
            if (MessageBox.Show("Изтриване?", "Потвърди", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try { _eventsRepo.DeleteFoul(f.FoulId); LoadEvents(); }
            catch (Exception ex) { Err("Грешка", ex); }
        }

        private void btnRefresh_Click(object s, EventArgs e) { LoadMatches(); LoadEvents(); }

        // Задава SplitterDistance за event-табовете само когато имат реален Width
        private void SetEventSplitters()
        {
            void TrySet(SplitContainer sc) {
                if (!sc.IsHandleCreated || sc.Width < 50) return;
                try {
                    if (sc.Panel1MinSize != 200) sc.Panel1MinSize = 200;
                    if (sc.Panel2MinSize != 220) sc.Panel2MinSize = 220;
                    int dist = Math.Max(200, sc.Width - 280);
                    if (dist < sc.Width - sc.Panel2MinSize)
                        sc.SplitterDistance = dist;
                } catch { }
            }
            TrySet(splitGoals);
            TrySet(splitCards);
            TrySet(splitFouls);
        }

        private void SetCombo(ComboBox c, int id)
        { foreach (var i in c.Items) if (i is ComboItem ci && ci.Id == id) { c.SelectedItem = i; return; } }

        private void Warn(string m) => MessageBox.Show(m, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        private void Err(string m, Exception ex)
        { MessageBox.Show($"{m}:\n\n{ex.Message}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error); lblMatchStatus.Text = $"✘ {m}"; }
    }
}
