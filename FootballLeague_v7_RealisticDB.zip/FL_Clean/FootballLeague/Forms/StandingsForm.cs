using FootballLeague.Models;
using FootballLeague.Repositories;

namespace FootballLeague.Forms
{
    public partial class StandingsForm : Form
    {
        private readonly StandingsRepository _repo        = new();
        private readonly LeaguesRepository   _leaguesRepo = new();

        public StandingsForm() { InitializeComponent(); }

        private void StandingsForm_Load(object sender, EventArgs e)
        {
            this.Shown += (s2, e2) =>
            {
                try {
                    splitMain.Panel1MinSize    = 180;
                    splitMain.Panel2MinSize    = 400;
                    splitMain.SplitterDistance = Math.Max(180, (int)(splitMain.Width * 0.22));
                } catch { }
            };
            LoadLeagues();
            GH.Style(dgvStandings);
            StyleGrid();
        }

        private void StyleGrid()
        {
            dgvStandings.RowTemplate.Height      = 38;
            dgvStandings.ColumnHeadersHeight     = 42;
            dgvStandings.Font                    = new Font("Segoe UI", 10f);
            dgvStandings.DefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgvStandings.CellFormatting          += DgvStandings_CellFormat;
        }

        private void DgvStandings_CellFormat(object? s, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || dgvStandings.Rows[e.RowIndex].DataBoundItem is not Standing st) return;

            var row = dgvStandings.Rows[e.RowIndex];

            // Цветове по позиция
            var bg = st.Position switch {
                1     => Color.FromArgb(212, 237, 218),   // Зелено – Шампион
                2     => Color.FromArgb(209, 231, 221),   // Светлозелено
                3     => Color.FromArgb(204, 229, 255),   // Синьо
                var p when p == dgvStandings.RowCount => Color.FromArgb(255, 205, 210), // Червено – Изпада
                _     => e.RowIndex % 2 == 0
                          ? Color.White
                          : Color.FromArgb(245, 249, 255)
            };
            row.DefaultCellStyle.BackColor          = bg;
            row.DefaultCellStyle.SelectionBackColor = Color.FromArgb(30, 78, 121);
            row.DefaultCellStyle.SelectionForeColor = Color.White;

            // Получерни точки
            if (dgvStandings.Columns[e.ColumnIndex]?.Name == "Points")
                e.CellStyle.Font = new Font("Segoe UI", 11f, FontStyle.Bold);

            // Позиция с медали
            if (dgvStandings.Columns[e.ColumnIndex]?.Name == "Position")
                e.Value = st.Position switch {
                    1 => "🥇 1",
                    2 => "🥈 2",
                    3 => "🥉 3",
                    _ => st.Position.ToString()
                };
        }

        // ── Зареждане на лиги (ляв панел) ─────────────────────────────────────
        private void LoadLeagues()
        {
            try
            {
                var leagues = _leaguesRepo.GetAll();
                lstLeagues.Items.Clear();
                foreach (var l in leagues)
                    lstLeagues.Items.Add(new ComboItem(l.LeagueId, $"{l.Name}  ({l.Season})"));
                if (lstLeagues.Items.Count > 0)
                    lstLeagues.SelectedIndex = 0;
            }
            catch (Exception ex) { Err("Грешка при зареждане на лиги", ex); }
        }

        // ── Изчисляване и показване на класирането ────────────────────────────
        private void LoadStandings()
        {
            if (lstLeagues.SelectedItem is not ComboItem ci || ci.Id == 0) return;
            try
            {
                lblStatus.Text = "⏳ Изчисляване...";
                Cursor = Cursors.WaitCursor;

                var standings = _repo.GetStandings(ci.Id);
                dgvStandings.DataSource = standings;

                ConfigureColumns();

                int played  = standings.Sum(s => s.MatchesPlayed) / 2;
                int total   = standings.Sum(s => s.GoalsFor);
                lblStatus.Text = standings.Count > 0
                    ? $"✔  Отбори: {standings.Count}  |  Изиграни мача: {played}  |  Общо голове: {total}"
                    : "⚠  Няма изиграни мачове за тази лига.";

                lblLeagueTitle.Text = $"🏆  {ci.Name}";
            }
            catch (Exception ex) { Err("Грешка при класирането", ex); }
            finally { Cursor = Cursors.Default; }
        }

        private void ConfigureColumns()
        {
            GH.Hide(dgvStandings, "ClubId", "GoalsFor", "GoalsAgainst", "GoalDifference");

            void Col(string name, string hdr, int w, DataGridViewContentAlignment align = DataGridViewContentAlignment.MiddleCenter)
            {
                if (dgvStandings.Columns[name] == null) return;
                var col = dgvStandings.Columns[name]!;
                col.Visible    = true;
                col.HeaderText = hdr;
                col.Width      = w;
                col.DefaultCellStyle.Alignment       = align;
                col.HeaderCell.Style.Alignment        = DataGridViewContentAlignment.MiddleCenter;
                col.SortMode   = DataGridViewColumnSortMode.Automatic;
            }

            Col("Position",      "#",            44);
            Col("ClubName",      "Отбор",       200, DataGridViewContentAlignment.MiddleLeft);
            Col("MatchesPlayed", "И",            44);
            Col("Wins",          "П",            44);
            Col("Draws",         "Р",            44);
            Col("Losses",        "З",            44);
            Col("Голове",        "Голове",       90);
            Col("Разлика",       "±",            54);
            Col("Points",        "Точки",        64);
            Col("Форма",         "Форма (5)",   120, DataGridViewContentAlignment.MiddleLeft);

            // Ред на колоните
            string[] order = { "Position","ClubName","MatchesPlayed","Wins","Draws","Losses","Голове","Разлика","Points","Форма" };
            for (int i = 0; i < order.Length; i++)
                if (dgvStandings.Columns[order[i]] != null)
                    dgvStandings.Columns[order[i]]!.DisplayIndex = i;
        }

        // ── Events ────────────────────────────────────────────────────────────
        private void lstLeagues_SelectedIndexChanged(object sender, EventArgs e) => LoadStandings();
        private void btnRefresh_Click(object sender, EventArgs e)                => LoadStandings();
        private void btnExport_Click(object sender, EventArgs e)                 => ExportToCsv();

        private void ExportToCsv()
        {
            if (dgvStandings.DataSource is not List<Standing> standings || standings.Count == 0)
            { MessageBox.Show("Няма данни за експорт!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            using var dlg = new SaveFileDialog {
                Filter   = "CSV файл|*.csv",
                FileName = $"Класиране_{DateTime.Now:yyyyMMdd_HHmm}.csv"
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                var lines = new List<string> { "#,Отбор,И,П,Р,З,ВГ,ДГ,±,Точки" };
                lines.AddRange(standings.Select(s =>
                    $"{s.Position},{s.ClubName},{s.MatchesPlayed},{s.Wins},{s.Draws},{s.Losses},{s.GoalsFor},{s.GoalsAgainst},{s.GoalDifference},{s.Points}"));
                File.WriteAllLines(dlg.FileName, lines, System.Text.Encoding.UTF8);
                MessageBox.Show($"✔  Класирането е експортирано!\n{dlg.FileName}", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { Err("Грешка при експорт", ex); }
        }

        private void Err(string m, Exception ex)
        {
            MessageBox.Show($"{m}:\n\n{ex.Message}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            lblStatus.Text = $"✘ {m}";
        }
    }
}
