using FootballLeague.Models;
using FootballLeague.Repositories;
using FootballLeague.Services;
using MySql.Data.MySqlClient;
namespace FootballLeague.Forms
{
    public partial class PlayersForm : Form
    {
        private readonly PlayersRepository _repo = new();
        private readonly ClubsRepository _clubs = new();
        private int _selectedId = -1;
        public PlayersForm() { InitializeComponent(); }
        private void PlayersForm_Load(object s, EventArgs e) { GH.Style(dgvPlayers); LoadCombos(); LoadPlayers(); }
        private void LoadCombos()
        {
            var clubs = _clubs.GetAll();
            void Fill(ComboBox cbo, bool all) { cbo.Items.Clear(); if(all)cbo.Items.Add(new ComboItem(0,"— Всички —")); foreach(var c in clubs)cbo.Items.Add(new ComboItem(c.ClubId,c.Name)); cbo.SelectedIndex=0; }
            Fill(cboClubFilter,true);Fill(cboClub,false);
            string[] pos={"GK","DF","MF","FW"};
            cboPosFilter.Items.Clear();cboPosFilter.Items.Add("— Всички —");cboPosFilter.Items.AddRange(pos);cboPosFilter.SelectedIndex=0;
            cboPosition.Items.Clear();cboPosition.Items.AddRange(pos);cboPosition.SelectedIndex=0;
            cboStatus.Items.Clear();cboStatus.Items.AddRange(new object[]{"Active","Injured","Suspended"});cboStatus.SelectedIndex=0;
        }
        private void LoadPlayers()
        {
            try
            {
                int? cid=(cboClubFilter.SelectedItem as ComboItem)?.Id;
                string? pos=cboPosFilter.SelectedIndex>0?cboPosFilter.SelectedItem?.ToString():null;
                string? name=string.IsNullOrWhiteSpace(txtSearch.Text)?null:txtSearch.Text;
                dgvPlayers.DataSource=_repo.GetPlayers(cid>0?cid:null,pos,name);
                GH.Hide(dgvPlayers,"PlayerId","ClubId");
                GH.Hdr(dgvPlayers,"ClubName","Клуб");GH.Hdr(dgvPlayers,"FullName","Играч");
                GH.Hdr(dgvPlayers,"BirthDate","Роден");GH.Hdr(dgvPlayers,"Age","Възраст");
                GH.Hdr(dgvPlayers,"Position","Позиция");GH.Hdr(dgvPlayers,"ShirtNumber","№");GH.Hdr(dgvPlayers,"Status","Статус");
                lblStatus.Text=$"Играчи: {dgvPlayers.RowCount}";
            }
            catch(Exception ex){Err("Грешка",ex);}
        }
        private void dgvPlayers_SelectionChanged(object s, EventArgs e)
        {
            if(dgvPlayers.CurrentRow?.DataBoundItem is Player p)
            {
                _selectedId=p.PlayerId;txtFullName.Text=p.FullName;dtpBirth.Value=p.BirthDate;numShirt.Value=p.ShirtNumber??1;
                SC(cboClub,p.ClubId);ST(cboPosition,p.Position);ST(cboStatus,p.Status);
            }
        }
        private void cboClubFilter_SelectedIndexChanged(object s,EventArgs e)=>LoadPlayers();
        private void cboPosFilter_SelectedIndexChanged(object s,EventArgs e)=>LoadPlayers();
        private void btnSearch_Click(object s,EventArgs e)=>LoadPlayers();
        private void btnClearFilters_Click(object s,EventArgs e){cboClubFilter.SelectedIndex=0;cboPosFilter.SelectedIndex=0;txtSearch.Text="";LoadPlayers();}
        private void btnAdd_Click(object s,EventArgs e)
        {
            var p=Build();if(p==null)return;
            try{_repo.Add(p);LoadPlayers();ClearForm();MessageBox.Show("Добавен!","Успех",MessageBoxButtons.OK,MessageBoxIcon.Information);}
            catch(Exception ex){Err("Грешка",ex);}
        }
        private void btnUpdate_Click(object s,EventArgs e)
        {
            if(_selectedId==-1){Warn("Изберете играч!");return;}var p=Build();if(p==null)return;p.PlayerId=_selectedId;
            try{_repo.Update(p);LoadPlayers();MessageBox.Show("Обновено!","Успех",MessageBoxButtons.OK,MessageBoxIcon.Information);}
            catch(Exception ex){Err("Грешка",ex);}
        }
        private void btnDelete_Click(object s,EventArgs e)
        {
            if(_selectedId==-1){Warn("Изберете играч!");return;}
            if(MessageBox.Show($"Изтриване на \"{txtFullName.Text}\"?","Потвърди",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
            try{_repo.Delete(_selectedId);LoadPlayers();ClearForm();}
            catch(MySqlException ex) when(ex.Number==1451){Warn("Играчът има свързани трансфери.");}
            catch(Exception ex){Err("Грешка",ex);}
        }
        private void btnClear_Click(object s,EventArgs e)=>ClearForm();
        private Player? Build()
        {
            var ci=cboClub.SelectedItem as ComboItem;
            var errs=ValidationService.ValidatePlayer(txtFullName.Text,dtpBirth.Value,cboPosition.SelectedItem?.ToString()??"",ci?.Id??0);
            if(errs.Count>0){Warn(string.Join("\n",errs.Select(x=>"• "+x)));return null;}
            return new Player{ClubId=ci!.Id,FullName=txtFullName.Text.Trim(),BirthDate=dtpBirth.Value.Date,
                Position=cboPosition.SelectedItem!.ToString()!,ShirtNumber=(int)numShirt.Value,Status=cboStatus.SelectedItem?.ToString()??"Active"};
        }
        private void ClearForm(){txtFullName.Text="";dtpBirth.Value=DateTime.Today.AddYears(-20);numShirt.Value=1;_selectedId=-1;dgvPlayers.ClearSelection();if(cboClub.Items.Count>0)cboClub.SelectedIndex=0;}
        private void SC(ComboBox c,int id){foreach(var i in c.Items)if(i is ComboItem ci&&ci.Id==id){c.SelectedItem=i;return;}}
        private void ST(ComboBox c,string t){for(int i=0;i<c.Items.Count;i++)if(c.Items[i]?.ToString()==t){c.SelectedIndex=i;return;}}
        private void Warn(string m)=>MessageBox.Show(m,"Внимание",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        private void Err(string m,Exception ex){MessageBox.Show($"{m}:\n{ex.Message}","Грешка",MessageBoxButtons.OK,MessageBoxIcon.Error);lblStatus.Text=$"✘ {m}";}
    }
}
