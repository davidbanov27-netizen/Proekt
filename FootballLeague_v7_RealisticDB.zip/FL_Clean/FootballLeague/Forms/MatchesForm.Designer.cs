namespace FootballLeague.Forms
{
    partial class MatchesForm
    {
        private System.ComponentModel.IContainer components = null;

        // Общи
        private Label      lblTitle       = null!;
        private Label      lblMatchStatus = null!;
        private TabControl tabMain        = null!;
        private TabPage    tabMatches     = null!;
        private TabPage    tabResult      = null!;
        private TabPage    tabEvents      = null!;

        // Таб 1 – Мачове
        private Panel         pnlFilters      = null!;
        private ComboBox      cboFilterLeague = null!;
        private ComboBox      cboFilterClub   = null!;
        private NumericUpDown numFilterRound  = null!;
        private Button        btnFilterRound  = null!;
        private Button        btnClearFilters = null!;
        private SplitContainer splitMatches   = null!;
        private DataGridView  dgvMatches      = null!;
        private Panel         pnlMatchForm    = null!;
        private Label         lblLeague       = null!;
        private ComboBox      cboLeague       = null!;
        private Label         lblRound        = null!;
        private NumericUpDown numRound        = null!;
        private Label         lblHomeClub     = null!;
        private ComboBox      cboHomeClub     = null!;
        private Label         lblAwayClub     = null!;
        private ComboBox      cboAwayClub     = null!;
        private Label         lblMatchDate    = null!;
        private DateTimePicker dtpMatchDate   = null!;
        private Label         lblStadium      = null!;
        private TextBox       txtStadium      = null!;
        private Button        btnAddMatch     = null!;
        private Button        btnEditMatch    = null!;
        private Button        btnDeleteMatch  = null!;
        private Button        btnClearMatch   = null!;

        // Таб 2 – Резултат
        private Label         lblSelectedMatch  = null!;
        private Panel         pnlResult         = null!;
        private Label         lblHomeTeamR      = null!;
        private NumericUpDown numHomeGoals      = null!;
        private Label         lblVs             = null!;
        private NumericUpDown numAwayGoals      = null!;
        private Label         lblAwayTeamR      = null!;
        private Button        btnSaveResult     = null!;
        private Button        btnAutoCalcResult = null!;
        private Label         lblResultStatus   = null!;

        // Таб 3 – Събития
        private Label         lblSelectedMatch2 = null!;
        private Label         lblEventsCount    = null!;
        private TabControl    tabEvents2        = null!;
        private TabPage       tabGoals          = null!;
        private TabPage       tabCards          = null!;
        private TabPage       tabFouls          = null!;

        // Голове
        private SplitContainer splitGoals    = null!;
        private DataGridView   dgvGoals      = null!;
        private Label          lblGoalsCount = null!;
        private Panel          pnlGoalForm   = null!;
        private ComboBox       cboGoalPlayer = null!;
        private NumericUpDown  numGoalMinute = null!;
        private CheckBox       chkOwnGoal   = null!;
        private Button         btnAddGoal   = null!;
        private Button         btnDeleteGoal= null!;

        // Картони
        private SplitContainer splitCards    = null!;
        private DataGridView   dgvCards      = null!;
        private Panel          pnlCardForm   = null!;
        private ComboBox       cboCardPlayer = null!;
        private NumericUpDown  numCardMinute = null!;
        private RadioButton    rbYellowCard  = null!;
        private RadioButton    rbRedCard     = null!;
        private Button         btnAddCard    = null!;
        private Button         btnDeleteCard = null!;

        // Фалове
        private SplitContainer splitFouls    = null!;
        private DataGridView   dgvFouls      = null!;
        private Panel          pnlFoulForm   = null!;
        private ComboBox       cboFoulPlayer = null!;
        private NumericUpDown  numFoulMinute = null!;
        private ComboBox       cboFoulType   = null!;
        private Button         btnAddFoul    = null!;
        private Button         btnDeleteFoul = null!;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        // Помощен метод за форматиране на бутони в панели
        private static Button MakeBtn(string text, Color bg, int x, int y, int w, int h, EventHandler? ev = null)
        {
            var b = new Button {
                Text = text, Location = new Point(x, y), Size = new Size(w, h),
                BackColor = bg, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold), Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            if (ev != null) b.Click += ev;
            return b;
        }

        private static Panel MakeSectionHeader(string text, Color? bg = null)
            => new Panel {
                Dock = DockStyle.Top, Height = 32,
                BackColor = bg ?? Color.FromArgb(220, 230, 245),
                Controls = { new Label {
                    Text = text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft,
                    Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(30, 78, 121),
                    Padding = new Padding(8, 0, 0, 0)
                }}
            };

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // ── init ────────────────────────────────────────────────────────
            lblTitle       = new Label();
            lblMatchStatus = new Label();
            tabMain        = new TabControl();
            tabMatches     = new TabPage(); tabResult = new TabPage(); tabEvents = new TabPage();

            pnlFilters      = new Panel();
            cboFilterLeague = new ComboBox(); cboFilterClub  = new ComboBox();
            numFilterRound  = new NumericUpDown();
            btnFilterRound  = new Button();   btnClearFilters = new Button();
            splitMatches    = new SplitContainer();
            dgvMatches      = new DataGridView();
            pnlMatchForm    = new Panel();
            lblLeague       = new Label();    cboLeague    = new ComboBox();
            lblRound        = new Label();    numRound     = new NumericUpDown();
            lblHomeClub     = new Label();    cboHomeClub  = new ComboBox();
            lblAwayClub     = new Label();    cboAwayClub  = new ComboBox();
            lblMatchDate    = new Label();    dtpMatchDate = new DateTimePicker();
            lblStadium      = new Label();    txtStadium   = new TextBox();
            btnAddMatch     = new Button();   btnEditMatch  = new Button();
            btnDeleteMatch  = new Button();   btnClearMatch = new Button();

            lblSelectedMatch  = new Label();
            pnlResult         = new Panel();
            lblHomeTeamR      = new Label();  numHomeGoals = new NumericUpDown();
            lblVs             = new Label();  numAwayGoals = new NumericUpDown();
            lblAwayTeamR      = new Label();
            btnSaveResult     = new Button(); btnAutoCalcResult = new Button();
            lblResultStatus   = new Label();

            lblSelectedMatch2 = new Label();
            lblEventsCount    = new Label();
            tabEvents2        = new TabControl();
            tabGoals          = new TabPage(); tabCards = new TabPage(); tabFouls = new TabPage();

            splitGoals    = new SplitContainer(); dgvGoals  = new DataGridView();
            lblGoalsCount = new Label();          pnlGoalForm = new Panel();
            cboGoalPlayer = new ComboBox();       numGoalMinute = new NumericUpDown();
            chkOwnGoal    = new CheckBox();       btnAddGoal  = new Button(); btnDeleteGoal = new Button();

            splitCards    = new SplitContainer(); dgvCards  = new DataGridView();
            pnlCardForm   = new Panel();
            cboCardPlayer = new ComboBox();       numCardMinute = new NumericUpDown();
            rbYellowCard  = new RadioButton();    rbRedCard  = new RadioButton();
            btnAddCard    = new Button();         btnDeleteCard = new Button();

            splitFouls    = new SplitContainer(); dgvFouls  = new DataGridView();
            pnlFoulForm   = new Panel();
            cboFoulPlayer = new ComboBox();       numFoulMinute = new NumericUpDown();
            cboFoulType   = new ComboBox();
            btnAddFoul    = new Button();         btnDeleteFoul = new Button();

            // ── ФОРМА ───────────────────────────────────────────────────────
            this.Text          = "⚽  Мачове и Резултати";
            this.Size          = new Size(1200, 750);
            this.MinimumSize   = new Size(1000, 640);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor     = Color.FromArgb(240, 244, 248);
            this.Font          = new Font("Segoe UI", 9.5f);
            this.Load         += MatchesForm_Load;

            lblTitle.Text      = "⚽  Мачове, Резултати и Събития";
            lblTitle.Font      = new Font("Segoe UI", 14f, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(30, 78, 121);
            lblTitle.Location  = new Point(12, 10);
            lblTitle.AutoSize  = true;

            lblMatchStatus.Text      = "Готово.";
            lblMatchStatus.Dock      = DockStyle.Bottom;
            lblMatchStatus.Height    = 24;
            lblMatchStatus.ForeColor = Color.FromArgb(80, 100, 120);
            lblMatchStatus.Padding   = new Padding(8, 4, 0, 0);
            lblMatchStatus.BackColor = Color.FromArgb(225, 232, 240);

            tabMain.Location = new Point(4, 44);
            tabMain.Anchor   = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            tabMain.Size     = new Size(this.ClientSize.Width - 8, this.ClientSize.Height - 72);
            tabMain.Font     = new Font("Segoe UI", 10f, FontStyle.Bold);
            tabMatches.Text = "  📋  Мачове  ";
            tabResult.Text  = "  ⚽  Резултат  ";
            tabEvents.Text  = "  🎯  Събития  ";
            tabMatches.BackColor = tabResult.BackColor = tabEvents.BackColor = Color.FromArgb(240, 244, 248);
            tabMain.TabPages.AddRange(new TabPage[] { tabMatches, tabResult, tabEvents });

            // ════════════════════════════════════════════════════════════════
            //  ТАБ 1 – МАЧОВЕ
            // ════════════════════════════════════════════════════════════════

            // Лента с филтри
            pnlFilters.Dock      = DockStyle.Top;
            pnlFilters.Height    = 48;
            pnlFilters.BackColor = Color.White;
            pnlFilters.Padding   = new Padding(6, 8, 6, 6);

            var lFL = new Label { Text = "Лига:", Location = new Point(8, 14), AutoSize = true };
            cboFilterLeague.Location = new Point(50, 10); cboFilterLeague.Size = new Size(200, 26);
            cboFilterLeague.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFilterLeague.SelectedIndexChanged += cboFilterLeague_SelectedIndexChanged;

            var lFC = new Label { Text = "Отбор:", Location = new Point(260, 14), AutoSize = true };
            cboFilterClub.Location = new Point(310, 10); cboFilterClub.Size = new Size(170, 26);
            cboFilterClub.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFilterClub.SelectedIndexChanged += cboFilterClub_SelectedIndexChanged;

            var lFR = new Label { Text = "Кръг:", Location = new Point(492, 14), AutoSize = true };
            numFilterRound.Location = new Point(536, 10); numFilterRound.Size = new Size(60, 26);
            numFilterRound.Minimum = 0; numFilterRound.Maximum = 99; numFilterRound.Value = 0;

            btnFilterRound.Text = "🔍"; btnFilterRound.Location = new Point(602, 8);
            btnFilterRound.Size = new Size(36, 30); btnFilterRound.FlatStyle = FlatStyle.Flat;
            btnFilterRound.Cursor = Cursors.Hand; btnFilterRound.Click += btnFilterRound_Click;

            btnClearFilters.Text = "✖ Изчисти"; btnClearFilters.Location = new Point(644, 8);
            btnClearFilters.Size = new Size(110, 30); btnClearFilters.FlatStyle = FlatStyle.Flat;
            btnClearFilters.Cursor = Cursors.Hand; btnClearFilters.Click += btnClearFilters_Click;

            pnlFilters.Controls.AddRange(new Control[] {
                lFL, cboFilterLeague, lFC, cboFilterClub, lFR, numFilterRound, btnFilterRound, btnClearFilters
            });

            // SplitContainer: грид | форма
            splitMatches.Dock             = DockStyle.Fill;
            splitMatches.SplitterWidth    = 6;
            splitMatches.BackColor        = Color.FromArgb(200, 210, 225);

            dgvMatches.Dock             = DockStyle.Fill;
            dgvMatches.SelectionChanged += dgvMatches_SelectionChanged;
            splitMatches.Panel1.Controls.Add(dgvMatches);

            // Форма (дясно)
            pnlMatchForm.Dock       = DockStyle.Fill;
            pnlMatchForm.BackColor  = Color.White;
            pnlMatchForm.AutoScroll = true;

            var mhdr = MakeSectionHeader("  Данни за мача");

            int my = 44;
            void ML(Label l, string t) { l.Text = t; l.Location = new Point(16, my); l.AutoSize = true; l.Font = new Font("Segoe UI", 9f, FontStyle.Bold); my += 20; }
            void MC(Control c, int h = 28) { c.Location = new Point(16, my); c.Size = new Size(330, h); c.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top; my += h + 10; }

            ML(lblLeague, "Лига *"); MC(cboLeague); cboLeague.DropDownStyle = ComboBoxStyle.DropDownList;
            ML(lblRound, "Кръг *"); MC(numRound); numRound.Minimum = 1; numRound.Maximum = 99; numRound.Value = 1;
            ML(lblHomeClub, "Домакин *"); MC(cboHomeClub); cboHomeClub.DropDownStyle = ComboBoxStyle.DropDownList;
            ML(lblAwayClub, "Гост *"); MC(cboAwayClub); cboAwayClub.DropDownStyle = ComboBoxStyle.DropDownList;
            ML(lblMatchDate, "Дата на мача"); MC(dtpMatchDate); dtpMatchDate.Format = DateTimePickerFormat.Short; dtpMatchDate.Value = DateTime.Today;
            ML(lblStadium, "Стадион"); MC(txtStadium); my += 4;

            var sepMa = new Label { Location = new Point(0, my), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top }; my += 12;

            btnAddMatch.Text = "➕  ДОБАВИ МАЧ"; btnAddMatch.Location = new Point(16, my); btnAddMatch.Size = new Size(330, 48);
            btnAddMatch.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnAddMatch.BackColor = Color.FromArgb(39, 174, 96); btnAddMatch.ForeColor = Color.White;
            btnAddMatch.FlatStyle = FlatStyle.Flat; btnAddMatch.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            btnAddMatch.Cursor = Cursors.Hand; btnAddMatch.Click += btnAddMatch_Click; my += 56;

            var sepMb = new Label { Location = new Point(0, my), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top }; my += 12;

            btnEditMatch.Text = "✏️  Редактирай избрания"; btnEditMatch.Location = new Point(16, my); btnEditMatch.Size = new Size(330, 40);
            btnEditMatch.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnEditMatch.BackColor = Color.FromArgb(230, 126, 34); btnEditMatch.ForeColor = Color.White;
            btnEditMatch.FlatStyle = FlatStyle.Flat; btnEditMatch.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnEditMatch.Cursor = Cursors.Hand; btnEditMatch.Enabled = false; btnEditMatch.Click += btnEditMatch_Click; my += 48;

            btnDeleteMatch.Text = "🗑️  Изтрий избрания"; btnDeleteMatch.Location = new Point(16, my); btnDeleteMatch.Size = new Size(330, 40);
            btnDeleteMatch.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnDeleteMatch.BackColor = Color.FromArgb(192, 57, 43); btnDeleteMatch.ForeColor = Color.White;
            btnDeleteMatch.FlatStyle = FlatStyle.Flat; btnDeleteMatch.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnDeleteMatch.Cursor = Cursors.Hand; btnDeleteMatch.Enabled = false; btnDeleteMatch.Click += btnDeleteMatch_Click; my += 48;

            var sepMc = new Label { Location = new Point(0, my), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top }; my += 12;

            btnClearMatch.Text = "✖  Изчисти форма"; btnClearMatch.Location = new Point(16, my); btnClearMatch.Size = new Size(330, 36);
            btnClearMatch.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnClearMatch.BackColor = Color.FromArgb(127, 140, 141); btnClearMatch.ForeColor = Color.White;
            btnClearMatch.FlatStyle = FlatStyle.Flat; btnClearMatch.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnClearMatch.Cursor = Cursors.Hand; btnClearMatch.Click += (s, e) => ClearMatchForm();

            pnlMatchForm.Controls.AddRange(new Control[] {
                mhdr, lblLeague, cboLeague, lblRound, numRound,
                lblHomeClub, cboHomeClub, lblAwayClub, cboAwayClub,
                lblMatchDate, dtpMatchDate, lblStadium, txtStadium,
                sepMa, btnAddMatch, sepMb, btnEditMatch, btnDeleteMatch, sepMc, btnClearMatch
            });
            splitMatches.Panel2.Controls.Add(pnlMatchForm);

            var pnlMatchWrap = new Panel { Dock = DockStyle.Fill };
            pnlMatchWrap.Controls.Add(splitMatches);
            pnlMatchWrap.Controls.Add(pnlFilters);
            tabMatches.Controls.Add(pnlMatchWrap);

            // ════════════════════════════════════════════════════════════════
            //  ТАБ 2 – РЕЗУЛТАТ
            // ════════════════════════════════════════════════════════════════
            var pnlResultPage = new Panel { Dock = DockStyle.Fill };

            var resHdr = MakeSectionHeader("  Резултат на мача");

            lblSelectedMatch.Text      = "— Изберете мач от Таб 1 —";
            lblSelectedMatch.Location  = new Point(12, 42);
            lblSelectedMatch.AutoSize  = true;
            lblSelectedMatch.Font      = new Font("Segoe UI", 11f, FontStyle.Bold);
            lblSelectedMatch.ForeColor = Color.FromArgb(30, 78, 121);

            // Score panel
            pnlResult.Location  = new Point(12, 78);
            pnlResult.Size      = new Size(660, 200);
            pnlResult.BackColor = Color.White;
            pnlResult.BorderStyle = BorderStyle.FixedSingle;

            lblHomeTeamR.Text      = "Домакин";
            lblHomeTeamR.Location  = new Point(30, 20);
            lblHomeTeamR.AutoSize  = true;
            lblHomeTeamR.Font      = new Font("Segoe UI", 12f, FontStyle.Bold);
            lblHomeTeamR.ForeColor = Color.FromArgb(30, 78, 121);

            numHomeGoals.Location = new Point(30, 56);
            numHomeGoals.Size     = new Size(110, 60);
            numHomeGoals.Minimum  = 0; numHomeGoals.Maximum = 99; numHomeGoals.Value = 0;
            numHomeGoals.Font     = new Font("Segoe UI", 26f, FontStyle.Bold);

            lblVs.Text      = ":";
            lblVs.Location  = new Point(160, 62);
            lblVs.AutoSize  = true;
            lblVs.Font      = new Font("Segoe UI", 32f, FontStyle.Bold);
            lblVs.ForeColor = Color.FromArgb(30, 78, 121);

            numAwayGoals.Location = new Point(208, 56);
            numAwayGoals.Size     = new Size(110, 60);
            numAwayGoals.Minimum  = 0; numAwayGoals.Maximum = 99; numAwayGoals.Value = 0;
            numAwayGoals.Font     = new Font("Segoe UI", 26f, FontStyle.Bold);

            lblAwayTeamR.Text      = "Гост";
            lblAwayTeamR.Location  = new Point(208, 20);
            lblAwayTeamR.AutoSize  = true;
            lblAwayTeamR.Font      = new Font("Segoe UI", 12f, FontStyle.Bold);
            lblAwayTeamR.ForeColor = Color.FromArgb(30, 78, 121);

            btnSaveResult.Text      = "💾  ЗАПИШИ РЕЗУЛТАТА";
            btnSaveResult.Location  = new Point(30, 134);
            btnSaveResult.Size      = new Size(280, 48);
            btnSaveResult.BackColor = Color.FromArgb(30, 78, 121); btnSaveResult.ForeColor = Color.White;
            btnSaveResult.FlatStyle = FlatStyle.Flat; btnSaveResult.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            btnSaveResult.Cursor    = Cursors.Hand; btnSaveResult.Click += btnSaveResult_Click;

            btnAutoCalcResult.Text      = "🧮  Изчисли от голове";
            btnAutoCalcResult.Location  = new Point(320, 134);
            btnAutoCalcResult.Size      = new Size(280, 48);
            btnAutoCalcResult.BackColor = Color.FromArgb(142, 68, 173); btnAutoCalcResult.ForeColor = Color.White;
            btnAutoCalcResult.FlatStyle = FlatStyle.Flat; btnAutoCalcResult.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnAutoCalcResult.Cursor    = Cursors.Hand; btnAutoCalcResult.Click += btnAutoCalcResult_Click;

            pnlResult.Controls.AddRange(new Control[] {
                lblHomeTeamR, numHomeGoals, lblVs, numAwayGoals, lblAwayTeamR,
                btnSaveResult, btnAutoCalcResult
            });

            lblResultStatus.Text      = "";
            lblResultStatus.Location  = new Point(12, 292);
            lblResultStatus.AutoSize  = true;
            lblResultStatus.Font      = new Font("Segoe UI", 10f);
            lblResultStatus.ForeColor = Color.FromArgb(39, 174, 96);

            pnlResultPage.Controls.AddRange(new Control[] { resHdr, lblSelectedMatch, pnlResult, lblResultStatus });
            tabResult.Controls.Add(pnlResultPage);

            // ════════════════════════════════════════════════════════════════
            //  ТАБ 3 – СЪБИТИЯ  (вложен TabControl)
            // ════════════════════════════════════════════════════════════════
            var pnlEvPage = new Panel { Dock = DockStyle.Fill };

            var evHdr = MakeSectionHeader("  Събития по мача");

            lblSelectedMatch2.Text      = "— Изберете мач от Таб 1 —";
            lblSelectedMatch2.Location  = new Point(10, 38);
            lblSelectedMatch2.AutoSize  = true;
            lblSelectedMatch2.Font      = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblSelectedMatch2.ForeColor = Color.FromArgb(30, 78, 121);

            lblEventsCount.Text      = "";
            lblEventsCount.Location  = new Point(10, 62);
            lblEventsCount.AutoSize  = true;
            lblEventsCount.ForeColor = Color.FromArgb(80, 100, 120);

            tabEvents2.Dock     = DockStyle.Fill;
            tabEvents2.Font     = new Font("Segoe UI", 9.5f, FontStyle.Bold);

            tabGoals.Text = "  ⚽ Голове  ";
            tabCards.Text = "  🟨 Картони  ";
            tabFouls.Text = "  🦵 Фалове  ";
            tabGoals.BackColor = tabCards.BackColor = tabFouls.BackColor = Color.FromArgb(248, 250, 252);
            tabEvents2.TabPages.AddRange(new TabPage[] { tabGoals, tabCards, tabFouls });

            // Wrap header labels in a top panel so tabEvents2 can Dock=Fill
            var pnlEvTop = new Panel { Dock = DockStyle.Top, Height = 58, BackColor = Color.FromArgb(220, 230, 245) };
            lblSelectedMatch2.Location = new Point(10, 6); lblSelectedMatch2.AutoSize = true;
            lblEventsCount.Location    = new Point(10, 32); lblEventsCount.AutoSize = true;
            pnlEvTop.Controls.Add(lblEventsCount);
            pnlEvTop.Controls.Add(lblSelectedMatch2);
            pnlEvPage.Controls.Add(tabEvents2);   // Add Fill control FIRST
            pnlEvPage.Controls.Add(pnlEvTop);     // Then Top-docked
            pnlEvPage.Controls.Add(evHdr);        // Then Top header
            tabEvents.Controls.Add(pnlEvPage);

            // ── Голове ─────────────────────────────────────────────────────
            splitGoals.Dock             = DockStyle.Fill;
            splitGoals.SplitterWidth    = 6;
            splitGoals.BackColor        = Color.FromArgb(200, 210, 225);

            dgvGoals.Dock = DockStyle.Fill;
            splitGoals.Panel1.Controls.Add(dgvGoals);

            pnlGoalForm.Dock      = DockStyle.Fill;
            pnlGoalForm.BackColor = Color.White;

            var ghdr = MakeSectionHeader("  Добави гол", Color.FromArgb(39, 174, 96) );
            ghdr.Controls[0].ForeColor = Color.White;

            lblGoalsCount.Text = ""; lblGoalsCount.Location = new Point(14, 40); lblGoalsCount.AutoSize = true; lblGoalsCount.ForeColor = Color.Gray;

            var lgP = new Label { Text = "Играч *", Location = new Point(14, 62), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            cboGoalPlayer.Location = new Point(14, 84); cboGoalPlayer.Size = new Size(330, 28);
            cboGoalPlayer.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            cboGoalPlayer.DropDownStyle = ComboBoxStyle.DropDownList;

            var lgM = new Label { Text = "Минута (1-120) *", Location = new Point(14, 122), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            numGoalMinute.Location = new Point(14, 144); numGoalMinute.Size = new Size(120, 28);
            numGoalMinute.Minimum = 1; numGoalMinute.Maximum = 120; numGoalMinute.Value = 1;

            chkOwnGoal.Text = "Автогол"; chkOwnGoal.Location = new Point(150, 146); chkOwnGoal.AutoSize = true; chkOwnGoal.Font = new Font("Segoe UI", 9.5f);

            var sepG = new Label { Location = new Point(0, 184), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            btnAddGoal.Text = "⚽  Добави гол"; btnAddGoal.Location = new Point(14, 194); btnAddGoal.Size = new Size(330, 48);
            btnAddGoal.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnAddGoal.BackColor = Color.FromArgb(39, 174, 96); btnAddGoal.ForeColor = Color.White;
            btnAddGoal.FlatStyle = FlatStyle.Flat; btnAddGoal.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnAddGoal.Cursor = Cursors.Hand; btnAddGoal.Click += btnAddGoal_Click;

            btnDeleteGoal.Text = "🗑️  Изтрий избрания гол"; btnDeleteGoal.Location = new Point(14, 252); btnDeleteGoal.Size = new Size(330, 42);
            btnDeleteGoal.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnDeleteGoal.BackColor = Color.FromArgb(192, 57, 43); btnDeleteGoal.ForeColor = Color.White;
            btnDeleteGoal.FlatStyle = FlatStyle.Flat; btnDeleteGoal.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            btnDeleteGoal.Cursor = Cursors.Hand; btnDeleteGoal.Click += btnDeleteGoal_Click;

            pnlGoalForm.Controls.AddRange(new Control[] { ghdr, lblGoalsCount, lgP, cboGoalPlayer, lgM, numGoalMinute, chkOwnGoal, sepG, btnAddGoal, btnDeleteGoal });
            splitGoals.Panel2.Controls.Add(pnlGoalForm);
            tabGoals.Controls.Add(splitGoals);

            // ── Картони ────────────────────────────────────────────────────
            splitCards.Dock             = DockStyle.Fill;
            splitCards.SplitterWidth    = 6;
            splitCards.BackColor        = Color.FromArgb(200, 210, 225);

            dgvCards.Dock = DockStyle.Fill;
            splitCards.Panel1.Controls.Add(dgvCards);

            pnlCardForm.Dock      = DockStyle.Fill;
            pnlCardForm.BackColor = Color.White;

            var chdr = MakeSectionHeader("  Добави картон", Color.FromArgb(230, 126, 34));
            chdr.Controls[0].ForeColor = Color.White;

            var lcP = new Label { Text = "Играч *", Location = new Point(14, 44), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            cboCardPlayer.Location = new Point(14, 66); cboCardPlayer.Size = new Size(330, 28);
            cboCardPlayer.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            cboCardPlayer.DropDownStyle = ComboBoxStyle.DropDownList;

            var lcM = new Label { Text = "Минута (1-120) *", Location = new Point(14, 104), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            numCardMinute.Location = new Point(14, 126); numCardMinute.Size = new Size(120, 28);
            numCardMinute.Minimum = 1; numCardMinute.Maximum = 120; numCardMinute.Value = 1;

            var sepCt = new Label { Location = new Point(0, 164), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            var lCardT = new Label { Text = "Вид картон", Location = new Point(14, 174), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            rbYellowCard.Text = "  🟨 Жълт картон"; rbYellowCard.Location = new Point(14, 196); rbYellowCard.AutoSize = true; rbYellowCard.Font = new Font("Segoe UI", 10.5f); rbYellowCard.Checked = true;
            rbRedCard.Text    = "  🟥 Червен картон"; rbRedCard.Location = new Point(14, 224); rbRedCard.AutoSize = true; rbRedCard.Font = new Font("Segoe UI", 10.5f);

            var sepCb = new Label { Location = new Point(0, 260), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            btnAddCard.Text = "🃏  Добави картон"; btnAddCard.Location = new Point(14, 272); btnAddCard.Size = new Size(330, 48);
            btnAddCard.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnAddCard.BackColor = Color.FromArgb(230, 126, 34); btnAddCard.ForeColor = Color.White;
            btnAddCard.FlatStyle = FlatStyle.Flat; btnAddCard.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnAddCard.Cursor = Cursors.Hand; btnAddCard.Click += btnAddCard_Click;

            btnDeleteCard.Text = "🗑️  Изтрий избрания"; btnDeleteCard.Location = new Point(14, 330); btnDeleteCard.Size = new Size(330, 40);
            btnDeleteCard.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnDeleteCard.BackColor = Color.FromArgb(192, 57, 43); btnDeleteCard.ForeColor = Color.White;
            btnDeleteCard.FlatStyle = FlatStyle.Flat; btnDeleteCard.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            btnDeleteCard.Cursor = Cursors.Hand; btnDeleteCard.Click += btnDeleteCard_Click;

            pnlCardForm.Controls.AddRange(new Control[] { chdr, lcP, cboCardPlayer, lcM, numCardMinute, sepCt, lCardT, rbYellowCard, rbRedCard, sepCb, btnAddCard, btnDeleteCard });
            splitCards.Panel2.Controls.Add(pnlCardForm);
            tabCards.Controls.Add(splitCards);

            // ── Фалове ─────────────────────────────────────────────────────
            splitFouls.Dock             = DockStyle.Fill;
            splitFouls.SplitterWidth    = 6;
            splitFouls.BackColor        = Color.FromArgb(200, 210, 225);

            dgvFouls.Dock = DockStyle.Fill;
            splitFouls.Panel1.Controls.Add(dgvFouls);

            pnlFoulForm.Dock      = DockStyle.Fill;
            pnlFoulForm.BackColor = Color.White;

            var fhdr = MakeSectionHeader("  Добави нарушение", Color.FromArgb(41, 128, 185));
            fhdr.Controls[0].ForeColor = Color.White;

            var lfP = new Label { Text = "Играч *", Location = new Point(14, 44), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            cboFoulPlayer.Location = new Point(14, 66); cboFoulPlayer.Size = new Size(330, 28);
            cboFoulPlayer.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            cboFoulPlayer.DropDownStyle = ComboBoxStyle.DropDownList;

            var lfM = new Label { Text = "Минута (1-120) *", Location = new Point(14, 104), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            numFoulMinute.Location = new Point(14, 126); numFoulMinute.Size = new Size(120, 28);
            numFoulMinute.Minimum = 1; numFoulMinute.Maximum = 120; numFoulMinute.Value = 1;

            var sepFt = new Label { Location = new Point(0, 164), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            var lfT = new Label { Text = "Вид нарушение", Location = new Point(14, 174), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            cboFoulType.Location = new Point(14, 196); cboFoulType.Size = new Size(330, 28);
            cboFoulType.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            cboFoulType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFoulType.Items.AddRange(new object[] { "Обикновен фал", "Груб фал", "Умишлена игра с ръка", "Симулация", "Опасна игра", "Друго" });
            cboFoulType.SelectedIndex = 0;

            var sepFb = new Label { Location = new Point(0, 236), Height = 1, Width = 380, BorderStyle = BorderStyle.Fixed3D, Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            btnAddFoul.Text = "🦵  Добави нарушение"; btnAddFoul.Location = new Point(14, 248); btnAddFoul.Size = new Size(330, 48);
            btnAddFoul.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnAddFoul.BackColor = Color.FromArgb(41, 128, 185); btnAddFoul.ForeColor = Color.White;
            btnAddFoul.FlatStyle = FlatStyle.Flat; btnAddFoul.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnAddFoul.Cursor = Cursors.Hand; btnAddFoul.Click += btnAddFoul_Click;

            btnDeleteFoul.Text = "🗑️  Изтрий избрания"; btnDeleteFoul.Location = new Point(14, 306); btnDeleteFoul.Size = new Size(330, 40);
            btnDeleteFoul.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnDeleteFoul.BackColor = Color.FromArgb(192, 57, 43); btnDeleteFoul.ForeColor = Color.White;
            btnDeleteFoul.FlatStyle = FlatStyle.Flat; btnDeleteFoul.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            btnDeleteFoul.Cursor = Cursors.Hand; btnDeleteFoul.Click += btnDeleteFoul_Click;

            pnlFoulForm.Controls.AddRange(new Control[] { fhdr, lfP, cboFoulPlayer, lfM, numFoulMinute, sepFt, lfT, cboFoulType, sepFb, btnAddFoul, btnDeleteFoul });
            splitFouls.Panel2.Controls.Add(pnlFoulForm);
            tabFouls.Controls.Add(splitFouls);

            // ── Добавяне към форма ──────────────────────────────────────────
            this.Controls.AddRange(new Control[] { lblTitle, tabMain, lblMatchStatus });
            this.ResumeLayout(false);
        }
    }
}
