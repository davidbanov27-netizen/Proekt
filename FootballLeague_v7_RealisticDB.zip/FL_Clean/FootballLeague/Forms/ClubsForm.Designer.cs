namespace FootballLeague.Forms
{
    partial class ClubsForm
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvClubs = null!; private Panel panelForm = null!;
        private Label lblTitle = null!; private Label lblStatus = null!;
        private Label lblName = null!; private TextBox txtName = null!;
        private Label lblCity = null!; private TextBox txtCity = null!;
        private Button btnLoad = null!; private Button btnAdd = null!;
        private Button btnEdit = null!; private Button btnDelete = null!; private Button btnClear = null!;
        protected override void Dispose(bool d) { if(d&&components!=null)components.Dispose();base.Dispose(d); }
        private void InitializeComponent()
        {
            components=new System.ComponentModel.Container();
            dgvClubs=new DataGridView();panelForm=new Panel();lblTitle=new Label();lblStatus=new Label();
            lblName=new Label();txtName=new TextBox();lblCity=new Label();txtCity=new TextBox();
            btnLoad=new Button();btnAdd=new Button();btnEdit=new Button();btnDelete=new Button();btnClear=new Button();
            this.SuspendLayout();
            this.Text="🏟️ Управление на клубове";this.Size=new Size(860,600);
            this.StartPosition=FormStartPosition.CenterScreen;this.BackColor=Color.FromArgb(240,244,248);this.Font=new Font("Segoe UI",9.5f);
            this.Load+=ClubsForm_Load;
            lblTitle.Text="🏟️  Управление на клубове";lblTitle.Font=new Font("Segoe UI",14f,FontStyle.Bold);
            lblTitle.ForeColor=Color.FromArgb(30,78,121);lblTitle.Location=new Point(12,12);lblTitle.AutoSize=true;
            dgvClubs.Location=new Point(12,50);dgvClubs.Size=new Size(580,490);
            dgvClubs.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Bottom|AnchorStyles.Right;
            dgvClubs.SelectionChanged+=dgvClubs_SelectionChanged;
            panelForm.Location=new Point(606,50);panelForm.Size=new Size(230,490);
            panelForm.Anchor=AnchorStyles.Top|AnchorStyles.Right|AnchorStyles.Bottom;panelForm.BackColor=Color.White;
            int y=16;
            void AF(Label l,string t,Control c){l.Text=t;l.Location=new Point(12,y);l.AutoSize=true;l.Font=new Font("Segoe UI",9f,FontStyle.Bold);y+=20;c.Location=new Point(12,y);c.Size=new Size(202,26);y+=36;panelForm.Controls.Add(l);panelForm.Controls.Add(c);}
            AF(lblName,"Клуб *",txtName);AF(lblCity,"Град",txtCity);y+=10;
            Button B(string t,Color bg){var b=GH.Btn(t,bg,12,y,202,36);y+=44;panelForm.Controls.Add(b);return b;}
            btnLoad=B("🔄  Зареди",Color.FromArgb(70,130,180));btnAdd=B("➕  Добави",Color.FromArgb(39,174,96));
            btnEdit=B("✏️  Редактирай",Color.FromArgb(230,126,34));btnDelete=B("🗑️  Изтрий",Color.FromArgb(192,57,43));btnClear=B("✖  Изчисти",Color.FromArgb(127,140,141));
            btnLoad.Click+=btnLoad_Click;btnAdd.Click+=btnAdd_Click;btnEdit.Click+=btnEdit_Click;btnDelete.Click+=btnDelete_Click;btnClear.Click+=btnClear_Click;
            lblStatus.Text="Готово.";lblStatus.Location=new Point(12,548);lblStatus.Size=new Size(820,22);
            lblStatus.Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;lblStatus.ForeColor=Color.FromArgb(80,100,120);
            this.Controls.AddRange(new Control[]{lblTitle,dgvClubs,panelForm,lblStatus});
            this.ResumeLayout(false);
        }
    }
}
