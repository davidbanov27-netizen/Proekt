using FootballLeague.Models;
using FootballLeague.Services;
namespace FootballLeague.Forms
{
    public class AutoLeagueDialog : Form
    {
        private readonly List<Club> _clubs;
        public (string Name, string Season, List<int> ClubIds, bool TwoLegs) Result { get; private set; }
        private TabControl tabs=null!;private TabPage t1=null!,t2=null!,t3=null!;
        private TextBox txtName=null!;private TextBox txtSeason=null!;
        private CheckedListBox clb=null!;private Label lblSel=null!;
        private RadioButton rbS=null!,rbD=null!;private Label lblPrev=null!;
        private Button btnPrev=null!,btnNext=null!,btnCreate=null!,btnCancel=null!;

        public AutoLeagueDialog(List<Club> clubs) { _clubs=clubs; Init(); }

        private void Init()
        {
            this.Text="⚡  Автоматично създаване на лига";this.Size=new Size(520,520);
            this.StartPosition=FormStartPosition.CenterParent;this.FormBorderStyle=FormBorderStyle.FixedDialog;
            this.MaximizeBox=this.MinimizeBox=false;this.BackColor=Color.FromArgb(240,244,248);this.Font=new Font("Segoe UI",9.5f);
            tabs=new TabControl{Location=new Point(10,10),Size=new Size(480,390)};
            t1=new TabPage{Text=" 1️⃣  Данни "};t2=new TabPage{Text=" 2️⃣  Отбори "};t3=new TabPage{Text=" 3️⃣  Опции "};
            t1.BackColor=t2.BackColor=t3.BackColor=Color.FromArgb(248,250,252);
            tabs.Font=new Font("Segoe UI",9.5f,FontStyle.Bold);tabs.TabPages.AddRange(new[]{t1,t2,t3});
            tabs.SelectedIndexChanged+=(s,e)=>UpdatePrev();
            // Tab1
            var h1=new Label{Text="Данни за новото първенство:",Location=new Point(14,12),AutoSize=true,Font=new Font("Segoe UI",9.5f,FontStyle.Bold),ForeColor=Color.FromArgb(30,78,121)};
            var lN=new Label{Text="Ime на лигата *",Location=new Point(14,44),AutoSize=true,Font=new Font("Segoe UI",9f,FontStyle.Bold)};
            txtName=new TextBox{Location=new Point(14,64),Size=new Size(450,28),Font=new Font("Segoe UI",10f)};
            var lS=new Label{Text="Сезон * (формат: 2025/2026)",Location=new Point(14,104),AutoSize=true,Font=new Font("Segoe UI",9f,FontStyle.Bold)};
            txtSeason=new TextBox{Location=new Point(14,124),Size=new Size(450,28),Font=new Font("Segoe UI",10f),Text=$"{DateTime.Today.Year}/{DateTime.Today.Year+1}"};
            var hint=new Label{Text="💡 Сезонът е попълнен автоматично.",Location=new Point(14,162),AutoSize=true,ForeColor=Color.Gray,Font=new Font("Segoe UI",8.5f,FontStyle.Italic)};
            t1.Controls.AddRange(new Control[]{h1,lN,txtName,lS,txtSeason,hint});
            // Tab2
            var h2=new Label{Text="Изберете отборите:",Location=new Point(14,12),AutoSize=true,Font=new Font("Segoe UI",9.5f,FontStyle.Bold),ForeColor=Color.FromArgb(30,78,121)};
            clb=new CheckedListBox{Location=new Point(14,42),Size=new Size(440,260),CheckOnClick=true,Font=new Font("Segoe UI",10f),BorderStyle=BorderStyle.FixedSingle};
            foreach(var c in _clubs)clb.Items.Add(c,false);
            clb.ItemCheck+=(s,e)=>BeginInvoke(new Action(UpdateSelCount));
            lblSel=new Label{Text="Избрани: 0 отбора",Location=new Point(14,310),AutoSize=true,Font=new Font("Segoe UI",9.5f,FontStyle.Bold),ForeColor=Color.FromArgb(30,78,121)};
            var bAll=new Button{Text="✔ Избери всички",Location=new Point(14,336),Size=new Size(160,32),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(39,174,96),ForeColor=Color.White,Font=new Font("Segoe UI",9f,FontStyle.Bold)};
            bAll.Click+=(s,e)=>{for(int i=0;i<clb.Items.Count;i++)clb.SetItemChecked(i,true);UpdateSelCount();};
            var bNone=new Button{Text="✖ Изчисти",Location=new Point(184,336),Size=new Size(130,32),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(127,140,141),ForeColor=Color.White,Font=new Font("Segoe UI",9f,FontStyle.Bold)};
            bNone.Click+=(s,e)=>{for(int i=0;i<clb.Items.Count;i++)clb.SetItemChecked(i,false);UpdateSelCount();};
            t2.Controls.AddRange(new Control[]{h2,clb,lblSel,bAll,bNone});
            // Tab3
            var h3=new Label{Text="Формат на първенството:",Location=new Point(14,12),AutoSize=true,Font=new Font("Segoe UI",9.5f,FontStyle.Bold),ForeColor=Color.FromArgb(30,78,121)};
            rbS=new RadioButton{Text="Единичен кръговник\n(всеки срещу всеки по веднъж)",Location=new Point(20,48),Size=new Size(430,48),Font=new Font("Segoe UI",10f),Checked=true};
            rbD=new RadioButton{Text="Двоен кръговник\n(домакинство + гостуване)",Location=new Point(20,106),Size=new Size(430,48),Font=new Font("Segoe UI",10f)};
            rbS.CheckedChanged+=(s,e)=>UpdatePrev();rbD.CheckedChanged+=(s,e)=>UpdatePrev();
            lblPrev=new Label{Text="",Location=new Point(14,178),Size=new Size(440,160),Font=new Font("Segoe UI",9.5f),ForeColor=Color.FromArgb(30,78,121),BorderStyle=BorderStyle.FixedSingle,BackColor=Color.White,Padding=new Padding(10)};
            t3.Controls.AddRange(new Control[]{h3,rbS,rbD,lblPrev});
            // Nav
            btnPrev=new Button{Text="◀ Назад",Location=new Point(10,412),Size=new Size(110,38),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(127,140,141),ForeColor=Color.White,Font=new Font("Segoe UI",9.5f,FontStyle.Bold)};
            btnNext=new Button{Text="Напред ▶",Location=new Point(130,412),Size=new Size(110,38),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(41,128,185),ForeColor=Color.White,Font=new Font("Segoe UI",9.5f,FontStyle.Bold)};
            btnCreate=new Button{Text="⚡ СЪЗДАЙ ЛИГА",Location=new Point(260,412),Size=new Size(160,38),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(39,174,96),ForeColor=Color.White,Font=new Font("Segoe UI",10f,FontStyle.Bold),Visible=false};
            btnCancel=new Button{Text="Отказ",Location=new Point(430,412),Size=new Size(80,38),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(192,57,43),ForeColor=Color.White,Font=new Font("Segoe UI",9.5f,FontStyle.Bold)};
            btnPrev.Click+=BtnPrev;btnNext.Click+=BtnNext;btnCreate.Click+=BtnCreate;
            btnCancel.Click+=(s,e)=>{DialogResult=DialogResult.Cancel;Close();};
            this.Controls.AddRange(new Control[]{tabs,btnPrev,btnNext,btnCreate,btnCancel});
            UpdateNav();
        }
        private void BtnPrev(object s,EventArgs e){if(tabs.SelectedIndex>0)tabs.SelectedIndex--;UpdateNav();}
        private void BtnNext(object s,EventArgs e){if(!ValTab())return;if(tabs.SelectedIndex<tabs.TabCount-1){tabs.SelectedIndex++;UpdateNav();UpdatePrev();}}
        private void BtnCreate(object s,EventArgs e)
        {
            if(!ValTab())return;
            var ids=clb.CheckedItems.Cast<Club>().Select(c=>c.ClubId).ToList();
            Result=(txtName.Text.Trim(),txtSeason.Text.Trim(),ids,rbD.Checked);
            DialogResult=DialogResult.OK;Close();
        }
        private bool ValTab()
        {
            if(tabs.SelectedIndex==0){if(string.IsNullOrWhiteSpace(txtName.Text)){Warn("Въведете Ime!");return false;}var err=ValidationService.ValidateSeason(txtSeason.Text);if(err!=null){Warn(err);return false;}}
            if(tabs.SelectedIndex==1){if(clb.CheckedItems.Count<2){Warn("Изберете поне 2 отбора!");return false;}}
            return true;
        }
        private void UpdateNav(){btnPrev.Enabled=tabs.SelectedIndex>0;btnNext.Visible=tabs.SelectedIndex<tabs.TabCount-1;btnCreate.Visible=tabs.SelectedIndex==tabs.TabCount-1;}
        private void UpdateSelCount(){lblSel.Text=$"Избрани: {clb.CheckedItems.Count} отбора";UpdatePrev();}
        private void UpdatePrev()
        {
            if(tabs.SelectedIndex!=2)return;int n=clb.CheckedItems.Count;
            if(n<2){lblPrev.Text="Изберете поне 2 отбора от Стъпка 2.";return;}
            bool two=rbD.Checked;int rounds=two?(n%2==0?(n-1)*2:n*2):(n%2==0?n-1:n);int per=n/2;
            lblPrev.Text=$"📋  Преглед:\n\n   Лига: {txtName.Text} ({txtSeason.Text})\n   Участници: {n}\n   Кръгове: {rounds}\n   Мача на кръг: {per}\n   Общо мачове: {rounds*per}\n   Формат: {(two?"Двоен кръговник":"Единичен кръговник")}\n\n   Натиснете ⚡ СЪЗДАЙ ЛИГА.";
        }
        private void Warn(string m)=>MessageBox.Show(m,"Внимание",MessageBoxButtons.OK,MessageBoxIcon.Warning);
    }
}
