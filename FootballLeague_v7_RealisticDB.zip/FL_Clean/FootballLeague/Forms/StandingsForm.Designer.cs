namespace FootballLeague.Forms
{
    partial class StandingsForm
    {
        private System.ComponentModel.IContainer components = null;

        private Label          lblTitle       = null!;
        private Label          lblStatus      = null!;
        private SplitContainer splitMain      = null!;
        private Label          lblLeaguesList = null!;
        private ListBox        lstLeagues     = null!;
        private Button         btnRefresh     = null!;
        private Button         btnExport      = null!;
        private Label          lblLeagueTitle = null!;
        private Panel          pnlLegend      = null!;
        private DataGridView   dgvStandings   = null!;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            lblTitle       = new Label();
            lblStatus      = new Label();
            splitMain      = new SplitContainer();
            lblLeaguesList = new Label();
            lstLeagues     = new ListBox();
            btnRefresh     = new Button();
            btnExport      = new Button();
            lblLeagueTitle = new Label();
            pnlLegend      = new Panel();
            dgvStandings   = new DataGridView();

            // ── ФОРМА ────────────────────────────────────────────────────────
            this.Text          = "🏆  Класиране";
            this.Size          = new Size(1100, 720);
            this.MinimumSize   = new Size(860, 580);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor     = Color.FromArgb(240, 244, 248);
            this.Font          = new Font("Segoe UI", 9.5f);
            this.Load         += StandingsForm_Load;

            // ── Заглавие ─────────────────────────────────────────────────────
            lblTitle.Text      = "🏆  Класиране";
            lblTitle.Font      = new Font("Segoe UI", 14f, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(30, 78, 121);
            lblTitle.Location  = new Point(12, 10);
            lblTitle.AutoSize  = true;

            // ── Статус лента ─────────────────────────────────────────────────
            lblStatus.Text      = "Изберете лига от списъка вляво.";
            lblStatus.Dock      = DockStyle.Bottom;
            lblStatus.Height    = 24;
            lblStatus.Padding   = new Padding(8, 4, 0, 0);
            lblStatus.BackColor = Color.FromArgb(225, 232, 240);
            lblStatus.ForeColor = Color.FromArgb(50, 80, 120);

            // ── SplitContainer ───────────────────────────────────────────────
            splitMain.Dock         = DockStyle.None;
            splitMain.Location     = new Point(4, 44);
            splitMain.Anchor       = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            splitMain.Size         = new Size(this.ClientSize.Width - 8, this.ClientSize.Height - 72);
            splitMain.SplitterWidth= 6;
            splitMain.BackColor    = Color.FromArgb(200, 210, 225);

            // ── Ляв панел – списък лиги ──────────────────────────────────────
            var pnlLeft = new Panel { Dock = DockStyle.Fill, BackColor = Color.White };

            lblLeaguesList.Text      = "  📋  Лиги / Първенства";
            lblLeaguesList.Dock      = DockStyle.Top;
            lblLeaguesList.Height    = 36;
            lblLeaguesList.Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            lblLeaguesList.ForeColor = Color.White;
            lblLeaguesList.BackColor = Color.FromArgb(30, 78, 121);
            lblLeaguesList.TextAlign = ContentAlignment.MiddleLeft;
            lblLeaguesList.Padding   = new Padding(8, 0, 0, 0);

            lstLeagues.Dock                 = DockStyle.Fill;
            lstLeagues.Font                 = new Font("Segoe UI", 10f);
            lstLeagues.BorderStyle          = BorderStyle.None;
            lstLeagues.ItemHeight           = 32;
            lstLeagues.BackColor            = Color.White;
            lstLeagues.SelectedIndexChanged += lstLeagues_SelectedIndexChanged;

            pnlLeft.Controls.Add(lstLeagues);
            pnlLeft.Controls.Add(lblLeaguesList);
            splitMain.Panel1.Controls.Add(pnlLeft);

            // ── Десен панел – класиране ──────────────────────────────────────
            var pnlRight = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(240, 244, 248) };

            // Заглавна лента с лига + бутони
            var pnlTop = new Panel { Dock = DockStyle.Top, Height = 52, BackColor = Color.FromArgb(30, 78, 121), Padding = new Padding(8, 8, 8, 8) };

            lblLeagueTitle.Text      = "— Изберете лига —";
            lblLeagueTitle.Location  = new Point(10, 14);
            lblLeagueTitle.AutoSize  = true;
            lblLeagueTitle.Font      = new Font("Segoe UI", 12f, FontStyle.Bold);
            lblLeagueTitle.ForeColor = Color.White;

            btnRefresh.Text      = "🔄  Обнови";
            btnRefresh.Size      = new Size(110, 34);
            btnRefresh.Anchor    = AnchorStyles.Top | AnchorStyles.Right;
            btnRefresh.BackColor = Color.FromArgb(52, 152, 219);
            btnRefresh.ForeColor = Color.White;
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.Font      = new Font("Segoe UI", 9f, FontStyle.Bold);
            btnRefresh.Cursor    = Cursors.Hand;
            btnRefresh.Click    += btnRefresh_Click;

            btnExport.Text      = "📥  Експорт CSV";
            btnExport.Size      = new Size(130, 34);
            btnExport.Anchor    = AnchorStyles.Top | AnchorStyles.Right;
            btnExport.BackColor = Color.FromArgb(39, 174, 96);
            btnExport.ForeColor = Color.White;
            btnExport.FlatStyle = FlatStyle.Flat;
            btnExport.Font      = new Font("Segoe UI", 9f, FontStyle.Bold);
            btnExport.Cursor    = Cursors.Hand;
            btnExport.Click    += btnExport_Click;

            // Position buttons in top panel via Resize
            pnlTop.Resize += (s, e) => {
                btnExport.Location  = new Point(pnlTop.Width - 148, 9);
                btnRefresh.Location = new Point(pnlTop.Width - 266, 9);
            };

            pnlTop.Controls.AddRange(new Control[] { lblLeagueTitle, btnRefresh, btnExport });

            // Легенда за цветовете
            pnlLegend.Dock      = DockStyle.Bottom;
            pnlLegend.Height    = 30;
            pnlLegend.BackColor = Color.FromArgb(248, 250, 252);
            pnlLegend.Padding   = new Padding(6, 4, 6, 4);

            var legend = new Label {
                Text      = "  🥇 Шампион   🟢 Европа   🔵 3-то място   🔴 Изпада   |   И=Изиграни  П=Победи  Р=Равни  З=Загуби  ±=Голова разлика",
                Dock      = DockStyle.Fill,
                Font      = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(80, 100, 120),
                TextAlign = ContentAlignment.MiddleLeft
            };
            pnlLegend.Controls.Add(legend);

            // DataGridView
            dgvStandings.Dock = DockStyle.Fill;

            pnlRight.Controls.Add(dgvStandings);
            pnlRight.Controls.Add(pnlTop);
            pnlRight.Controls.Add(pnlLegend);

            // Fix: Fill must be added before Top/Bottom in WinForms
            pnlRight.Controls.SetChildIndex(dgvStandings, 0);
            pnlRight.Controls.SetChildIndex(pnlTop, 1);
            pnlRight.Controls.SetChildIndex(pnlLegend, 2);

            splitMain.Panel2.Controls.Add(pnlRight);

            this.Controls.AddRange(new Control[] { lblTitle, splitMain, lblStatus });
            this.ResumeLayout(false);
        }
    }
}
