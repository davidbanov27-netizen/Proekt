using FootballLeague.Models;
using FootballLeague.Repositories;
namespace FootballLeague.Forms
{
    public partial class TransfersForm : Form
    {
        private readonly TransfersRepository _repo = new();
        private readonly PlayersRepository _players = new();
        private readonly ClubsRepository _clubs = new();
        private List<Player> _cache = new();
        public TransfersForm() { InitializeComponent(); }
        private void TransfersForm_Load(object s, EventArgs e) { GH.Style(dgvTransfers); LoadCombos(); LoadTransfers(); }
        private void LoadCombos()
        {
            _cache = _players.GetPlayers(); var clubs = _clubs.GetAll();
            cboPlayer.Items.Clear(); cboPlayer.Items.Add(new ComboItem(0,"— Избери играч —"));
            foreach(var p in _cache) cboPlayer.Items.Add(new ComboItem(p.PlayerId,$"{p.FullName} [{p.ClubName}]")); cboPlayer.SelectedIndex=0;
            cboToClub.Items.Clear(); cboToClub.Items.Add(new ComboItem(0,"— Нов клуб —"));
            foreach(var c in clubs) cboToClub.Items.Add(new ComboItem(c.ClubId,c.Name)); cboToClub.SelectedIndex=0;
            cboFP.Items.Clear(); cboFP.Items.Add(new ComboItem(0,"— Всички играчи —"));
            foreach(var p in _cache) cboFP.Items.Add(new ComboItem(p.PlayerId,p.FullName)); cboFP.SelectedIndex=0;
            cboFC.Items.Clear(); cboFC.Items.Add(new ComboItem(0,"— Всички клубове —"));
            foreach(var c in clubs) cboFC.Items.Add(new ComboItem(c.ClubId,c.Name)); cboFC.SelectedIndex=0;
        }
        private void cboPlayer_SelectedIndexChanged(object s,EventArgs e)
        { var i=cboPlayer.SelectedItem as ComboItem; txtFromClub.Text=i==null||i.Id==0?"":_cache.FirstOrDefault(p=>p.PlayerId==i.Id)?.ClubName??""; }
        private void LoadTransfers()
        {
            try
            {
                int? pid=(cboFP.SelectedItem as ComboItem)?.Id; int? cid=(cboFC.SelectedItem as ComboItem)?.Id;
                DateTime? from=chkDate.Checked?(DateTime?)dtpFrom.Value.Date:null; DateTime? to=chkDate.Checked?(DateTime?)dtpTo.Value.Date:null;
                dgvTransfers.DataSource=_repo.GetTransfers(pid>0?pid:null,cid>0?cid:null,from,to);
                GH.Hide(dgvTransfers,"TransferId","PlayerId","FromClubId","ToClubId");
                GH.Hdr(dgvTransfers,"PlayerName","Играч");GH.Hdr(dgvTransfers,"FromClubName","От клуб");
                GH.Hdr(dgvTransfers,"ToClubName","Към клуб");GH.Hdr(dgvTransfers,"TransferDate","Дата");
                GH.Hdr(dgvTransfers,"Fee","Сума (€)");GH.Hdr(dgvTransfers,"Note","Бележка");
                lblStatus.Text=$"Трансфери: {dgvTransfers.RowCount}";
            }
            catch(Exception ex){Err("Грешка",ex);}
        }
        private void btnTransfer_Click(object s,EventArgs e)
        {
            var pi=cboPlayer.SelectedItem as ComboItem; var ci=cboToClub.SelectedItem as ComboItem;
            if(pi==null||pi.Id==0){Warn("Изберете играч!");return;} if(ci==null||ci.Id==0){Warn("Изберете нов клуб!");return;}
            var player=_cache.FirstOrDefault(p=>p.PlayerId==pi.Id); if(player==null){Warn("Играчът не е намерен.");return;}
            if(player.ClubId==ci.Id){Warn($"Играчът вече е в \"{player.ClubName}\"!");return;}
            if(dtpDate.Value.Date>DateTime.Today){Warn("Датата не може да е в бъдещето!");return;}
            if(MessageBox.Show($"Трансфер: {player.FullName}\nОт: {player.ClubName}\nКъм: {ci.Name}\nПотвърждавате?","Потвърди",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
            try
            {
                _repo.AddTransfer(new Transfer{PlayerId=player.PlayerId,FromClubId=player.ClubId>0?player.ClubId:null,
                    ToClubId=ci.Id,TransferDate=dtpDate.Value.Date,Fee=numFee.Value>0?numFee.Value:null,Note=txtNote.Text.Trim()});
                MessageBox.Show($"✔  {player.FullName} → {ci.Name}","Успех",MessageBoxButtons.OK,MessageBoxIcon.Information);
                LoadCombos();LoadTransfers();Clear();
            }
            catch(Exception ex){Err("Грешка при трансфер",ex);}
        }
        private void cboFP_SelectedIndexChanged(object s,EventArgs e)=>LoadTransfers();
        private void cboFC_SelectedIndexChanged(object s,EventArgs e)=>LoadTransfers();
        private void btnRefresh_Click(object s,EventArgs e)=>LoadTransfers();
        private void chkDate_CheckedChanged(object s,EventArgs e){dtpFrom.Enabled=dtpTo.Enabled=chkDate.Checked;LoadTransfers();}
        private void dtpFrom_ValueChanged(object s,EventArgs e)=>LoadTransfers();
        private void dtpTo_ValueChanged(object s,EventArgs e)=>LoadTransfers();
        private void btnClearF_Click(object s,EventArgs e){cboFP.SelectedIndex=0;cboFC.SelectedIndex=0;chkDate.Checked=false;LoadTransfers();}
        private void btnClear_Click(object s,EventArgs e)=>Clear();
        private void Clear(){cboPlayer.SelectedIndex=0;cboToClub.SelectedIndex=0;txtFromClub.Text="";txtNote.Text="";numFee.Value=0;dtpDate.Value=DateTime.Today;}
        private void Warn(string m)=>MessageBox.Show(m,"Внимание",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        private void Err(string m,Exception ex){MessageBox.Show($"{m}:\n{ex.Message}","Грешка",MessageBoxButtons.OK,MessageBoxIcon.Error);lblStatus.Text=$"✘ {m}";}
    }

    partial class TransfersForm
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvTransfers=null!;private Panel pF=null!;private Label lblTitle=null!;private Label lblStatus=null!;
        private ComboBox cboFP=null!;private ComboBox cboFC=null!;private CheckBox chkDate=null!;
        private DateTimePicker dtpFrom=null!;private Label lTo=null!;private DateTimePicker dtpTo=null!;
        private Button btnRefresh=null!;private Button btnClearF=null!;
        private Label lP=null!;private ComboBox cboPlayer=null!;private Label lFC=null!;private TextBox txtFromClub=null!;
        private Label lTC=null!;private ComboBox cboToClub=null!;private Label lD=null!;private DateTimePicker dtpDate=null!;
        private Label lF=null!;private NumericUpDown numFee=null!;private Label lN=null!;private TextBox txtNote=null!;
        private Button btnTransfer=null!;private Button btnClear=null!;
        protected override void Dispose(bool d){if(d&&components!=null)components.Dispose();base.Dispose(d);}
        private void InitializeComponent()
        {
            components=new System.ComponentModel.Container();
            dgvTransfers=new DataGridView();pF=new Panel();lblTitle=new Label();lblStatus=new Label();
            cboFP=new ComboBox();cboFC=new ComboBox();chkDate=new CheckBox();dtpFrom=new DateTimePicker();lTo=new Label();dtpTo=new DateTimePicker();btnRefresh=new Button();btnClearF=new Button();
            lP=new Label();cboPlayer=new ComboBox();lFC=new Label();txtFromClub=new TextBox();lTC=new Label();cboToClub=new ComboBox();
            lD=new Label();dtpDate=new DateTimePicker();lF=new Label();numFee=new NumericUpDown();lN=new Label();txtNote=new TextBox();
            btnTransfer=new Button();btnClear=new Button();
            this.SuspendLayout();
            this.Text="🔄 Трансфери";this.Size=new Size(1100,700);this.StartPosition=FormStartPosition.CenterScreen;
            this.MinimumSize=new Size(1000,640);this.BackColor=Color.FromArgb(240,244,248);this.Font=new Font("Segoe UI",9.5f);this.Load+=TransfersForm_Load;
            lblTitle.Text="🔄  Трансфери";lblTitle.Font=new Font("Segoe UI",14f,FontStyle.Bold);lblTitle.ForeColor=Color.FromArgb(30,78,121);lblTitle.Location=new Point(12,12);lblTitle.AutoSize=true;
            var pFilt=new Panel{Location=new Point(12,46),Size=new Size(760,50),BackColor=Color.White};
            cboFP.Location=new Point(6,12);cboFP.Size=new Size(160,26);cboFP.DropDownStyle=ComboBoxStyle.DropDownList;cboFP.SelectedIndexChanged+=cboFP_SelectedIndexChanged;
            cboFC.Location=new Point(174,12);cboFC.Size=new Size(150,26);cboFC.DropDownStyle=ComboBoxStyle.DropDownList;cboFC.SelectedIndexChanged+=cboFC_SelectedIndexChanged;
            chkDate.Text="Период:";chkDate.Location=new Point(332,15);chkDate.AutoSize=true;chkDate.CheckedChanged+=chkDate_CheckedChanged;
            dtpFrom.Location=new Point(400,12);dtpFrom.Size=new Size(100,26);dtpFrom.Format=DateTimePickerFormat.Short;dtpFrom.Enabled=false;dtpFrom.ValueChanged+=dtpFrom_ValueChanged;
            lTo.Text="–";lTo.Location=new Point(504,16);lTo.AutoSize=true;
            dtpTo.Location=new Point(514,12);dtpTo.Size=new Size(100,26);dtpTo.Format=DateTimePickerFormat.Short;dtpTo.Enabled=false;dtpTo.ValueChanged+=dtpTo_ValueChanged;
            btnRefresh.Text="🔄";btnRefresh.Location=new Point(622,10);btnRefresh.Size=new Size(32,28);btnRefresh.FlatStyle=FlatStyle.Flat;btnRefresh.Click+=btnRefresh_Click;
            btnClearF.Text="✖";btnClearF.Location=new Point(660,10);btnClearF.Size=new Size(32,28);btnClearF.FlatStyle=FlatStyle.Flat;btnClearF.Click+=btnClearF_Click;
            pFilt.Controls.AddRange(new Control[]{cboFP,cboFC,chkDate,dtpFrom,lTo,dtpTo,btnRefresh,btnClearF});
            dgvTransfers.Location=new Point(12,104);dgvTransfers.Size=new Size(760,534);
            dgvTransfers.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Bottom|AnchorStyles.Right;
            pF.Location=new Point(784,46);pF.Size=new Size(290,592);pF.Anchor=AnchorStyles.Top|AnchorStyles.Right|AnchorStyles.Bottom;pF.BackColor=Color.White;
            int y=12;
            void AF(Label l,string t,Control c,int h=28){l.Text=t;l.Location=new Point(12,y);l.AutoSize=true;l.Font=new Font("Segoe UI",9f,FontStyle.Bold);y+=20;c.Location=new Point(12,y);c.Size=new Size(264,h);y+=h+10;pF.Controls.Add(l);pF.Controls.Add(c);}
            AF(lP,"Играч *",cboPlayer);cboPlayer.DropDownStyle=ComboBoxStyle.DropDownList;cboPlayer.SelectedIndexChanged+=cboPlayer_SelectedIndexChanged;
            AF(lFC,"Текущ клуб",txtFromClub);txtFromClub.ReadOnly=true;txtFromClub.BackColor=Color.FromArgb(245,245,245);
            AF(lTC,"Нов клуб *",cboToClub);cboToClub.DropDownStyle=ComboBoxStyle.DropDownList;
            AF(lD,"Дата *",dtpDate);dtpDate.Format=DateTimePickerFormat.Short;dtpDate.Value=DateTime.Today;
            AF(lF,"Сума (€)",numFee);numFee.Minimum=0;numFee.Maximum=999999999;numFee.ThousandsSeparator=true;
            AF(lN,"Бележка",txtNote,50);txtNote.Multiline=true;
            y+=10;
            btnTransfer=GH.Btn("🔄  Потвърди трансфер",Color.FromArgb(30,78,121),12,y,264,44);y+=52;pF.Controls.Add(btnTransfer);btnTransfer.Click+=btnTransfer_Click;
            btnClear=GH.Btn("✖  Изчисти",Color.FromArgb(127,140,141),12,y,264,36);pF.Controls.Add(btnClear);btnClear.Click+=btnClear_Click;
            lblStatus.Text="Готово.";lblStatus.Location=new Point(12,648);lblStatus.Size=new Size(1060,22);
            lblStatus.Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;lblStatus.ForeColor=Color.FromArgb(80,100,120);
            this.Controls.AddRange(new Control[]{lblTitle,pFilt,dgvTransfers,pF,lblStatus});
            this.ResumeLayout(false);
        }
    }
}
