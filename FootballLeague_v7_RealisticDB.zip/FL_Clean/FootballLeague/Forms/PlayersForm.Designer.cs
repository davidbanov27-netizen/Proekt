namespace FootballLeague.Forms
{
    partial class PlayersForm
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvPlayers=null!;private Panel panelFilters=null!;private Panel panelForm=null!;
        private Label lblTitle=null!;private Label lblStatus=null!;
        private Label l1=null!;private ComboBox cboClubFilter=null!;
        private Label l2=null!;private ComboBox cboPosFilter=null!;
        private Label l3=null!;private TextBox txtSearch=null!;
        private Button btnSearch=null!;private Button btnClearFilters=null!;
        private Label lFN=null!;private TextBox txtFullName=null!;
        private Label lBD=null!;private DateTimePicker dtpBirth=null!;
        private Label lCL=null!;private ComboBox cboClub=null!;
        private Label lPO=null!;private ComboBox cboPosition=null!;
        private Label lSH=null!;private NumericUpDown numShirt=null!;
        private Label lST=null!;private ComboBox cboStatus=null!;
        private Button btnAdd=null!;private Button btnUpdate=null!;private Button btnDelete=null!;private Button btnClear=null!;
        protected override void Dispose(bool d){if(d&&components!=null)components.Dispose();base.Dispose(d);}
        private void InitializeComponent()
        {
            components=new System.ComponentModel.Container();
            dgvPlayers=new DataGridView();panelFilters=new Panel();panelForm=new Panel();
            lblTitle=new Label();lblStatus=new Label();
            l1=new Label();cboClubFilter=new ComboBox();l2=new Label();cboPosFilter=new ComboBox();
            l3=new Label();txtSearch=new TextBox();btnSearch=new Button();btnClearFilters=new Button();
            lFN=new Label();txtFullName=new TextBox();lBD=new Label();dtpBirth=new DateTimePicker();
            lCL=new Label();cboClub=new ComboBox();lPO=new Label();cboPosition=new ComboBox();
            lSH=new Label();numShirt=new NumericUpDown();lST=new Label();cboStatus=new ComboBox();
            btnAdd=new Button();btnUpdate=new Button();btnDelete=new Button();btnClear=new Button();
            this.SuspendLayout();
            this.Text="👤 Управление на играчи";this.Size=new Size(1100,680);this.StartPosition=FormStartPosition.CenterScreen;
            this.MinimumSize=new Size(1000,600);this.BackColor=Color.FromArgb(240,244,248);this.Font=new Font("Segoe UI",9.5f);this.Load+=PlayersForm_Load;
            lblTitle.Text="👤  Управление на играчи";lblTitle.Font=new Font("Segoe UI",14f,FontStyle.Bold);
            lblTitle.ForeColor=Color.FromArgb(30,78,121);lblTitle.Location=new Point(12,12);lblTitle.AutoSize=true;
            panelFilters.Location=new Point(12,46);panelFilters.Size=new Size(760,46);panelFilters.BackColor=Color.White;
            l1.Text="Клуб:";l1.Location=new Point(8,15);l1.AutoSize=true;
            cboClubFilter.Location=new Point(46,11);cboClubFilter.Size=new Size(155,26);cboClubFilter.DropDownStyle=ComboBoxStyle.DropDownList;cboClubFilter.SelectedIndexChanged+=cboClubFilter_SelectedIndexChanged;
            l2.Text="Позиция:";l2.Location=new Point(210,15);l2.AutoSize=true;
            cboPosFilter.Location=new Point(268,11);cboPosFilter.Size=new Size(90,26);cboPosFilter.DropDownStyle=ComboBoxStyle.DropDownList;cboPosFilter.SelectedIndexChanged+=cboPosFilter_SelectedIndexChanged;
            l3.Text="Търси:";l3.Location=new Point(368,15);l3.AutoSize=true;
            txtSearch.Location=new Point(410,11);txtSearch.Size=new Size(155,26);
            btnSearch.Text="🔍";btnSearch.Location=new Point(572,9);btnSearch.Size=new Size(34,28);btnSearch.FlatStyle=FlatStyle.Flat;btnSearch.Click+=btnSearch_Click;
            btnClearFilters.Text="✖";btnClearFilters.Location=new Point(612,9);btnClearFilters.Size=new Size(34,28);btnClearFilters.FlatStyle=FlatStyle.Flat;btnClearFilters.Click+=btnClearFilters_Click;
            panelFilters.Controls.AddRange(new Control[]{l1,cboClubFilter,l2,cboPosFilter,l3,txtSearch,btnSearch,btnClearFilters});
            dgvPlayers.Location=new Point(12,100);dgvPlayers.Size=new Size(760,520);
            dgvPlayers.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Bottom|AnchorStyles.Right;dgvPlayers.SelectionChanged+=dgvPlayers_SelectionChanged;
            panelForm.Location=new Point(784,46);panelForm.Size=new Size(290,574);
            panelForm.Anchor=AnchorStyles.Top|AnchorStyles.Right|AnchorStyles.Bottom;panelForm.BackColor=Color.White;
            int y=12;
            void AF(Label l,string t,Control c,int h=28){l.Text=t;l.Location=new Point(12,y);l.AutoSize=true;l.Font=new Font("Segoe UI",9f,FontStyle.Bold);y+=20;c.Location=new Point(12,y);c.Size=new Size(262,h);y+=h+10;panelForm.Controls.Add(l);panelForm.Controls.Add(c);}
            AF(lFN,"Пълно Ime *",txtFullName);
            AF(lBD,"Дата на раждане *",dtpBirth);dtpBirth.Format=DateTimePickerFormat.Short;dtpBirth.Value=DateTime.Today.AddYears(-20);
            AF(lCL,"Клуб *",cboClub);cboClub.DropDownStyle=ComboBoxStyle.DropDownList;
            AF(lPO,"Позиция *",cboPosition);cboPosition.DropDownStyle=ComboBoxStyle.DropDownList;
            AF(lSH,"Номер фланелка",numShirt);numShirt.Minimum=1;numShirt.Maximum=99;
            AF(lST,"Статус",cboStatus);cboStatus.DropDownStyle=ComboBoxStyle.DropDownList;
            y+=10;
            Button B(string t,Color bg){var b=GH.Btn(t,bg,12,y,262,36);y+=44;panelForm.Controls.Add(b);return b;}
            btnAdd=B("➕  Добави",Color.FromArgb(39,174,96));btnUpdate=B("✏️  Обнови",Color.FromArgb(230,126,34));
            btnDelete=B("🗑️  Изтрий",Color.FromArgb(192,57,43));btnClear=B("✖  Изчисти",Color.FromArgb(127,140,141));
            btnAdd.Click+=btnAdd_Click;btnUpdate.Click+=btnUpdate_Click;btnDelete.Click+=btnDelete_Click;btnClear.Click+=btnClear_Click;
            lblStatus.Text="Готово.";lblStatus.Location=new Point(12,628);lblStatus.Size=new Size(1060,22);
            lblStatus.Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;lblStatus.ForeColor=Color.FromArgb(80,100,120);
            this.Controls.AddRange(new Control[]{lblTitle,panelFilters,dgvPlayers,panelForm,lblStatus});
            this.ResumeLayout(false);
        }
    }
}
