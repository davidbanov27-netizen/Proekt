namespace FootballLeague.Forms
{
    internal class ComboItem
    {
        public int Id { get; }
        public string Name { get; }
        public ComboItem(int id, string name) { Id = id; Name = name; }
        public override string ToString() => Name;
    }

    internal static class GH
    {
        public static void Style(DataGridView dgv)
        {
            dgv.ReadOnly = true;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.MultiSelect = false;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.AllowUserToAddRows = false;
            dgv.BackgroundColor = Color.White;
            dgv.BorderStyle = BorderStyle.None;
            dgv.RowHeadersVisible = false;
            dgv.GridColor = Color.FromArgb(220, 230, 240);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 78, 121);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            dgv.EnableHeadersVisualStyles = false;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(245, 249, 255);
        }
        public static void Hide(DataGridView dgv, params string[] cols)
        { foreach (var c in cols) if (dgv.Columns[c] != null) dgv.Columns[c]!.Visible = false; }
        public static void Hdr(DataGridView dgv, string col, string hdr)
        { if (dgv.Columns[col] != null) dgv.Columns[col]!.HeaderText = hdr; }
        public static Button Btn(string text, Color bg, int x, int y, int w = 200, int h = 36)
            => new() { Text = text, Location = new Point(x, y), Size = new Size(w, h),
                       BackColor = bg, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                       Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), Cursor = Cursors.Hand };
    }
}
