namespace FootballLeague.Forms
{
    partial class LeaguesForm
    {
        private System.ComponentModel.IContainer components = null;

        // Общи
        private Label      lblTitle        = null!;
        private Label      lblStatus       = null!;
        private TabControl tabMain         = null!;
        private TabPage    tabLeagues      = null!;
        private TabPage    tabParticipants = null!;
        private TabPage    tabSchedule     = null!;

        // Таб 1 – Лиги
        private SplitContainer splitLeagues   = null!;
        private DataGridView   dgvLeagues     = null!;
        private Panel          pnlLeagueForm  = null!;
        private Label          lN             = null!;
        private TextBox        txtName        = null!;
        private Label          lS             = null!;
        private TextBox        txtSeason      = null!;
        private Label          lblSeasonHint  = null!;
        private Label          lT             = null!;
        private NumericUpDown  numTeamCount   = null!;
        private Button         btnAddLeague   = null!;
        private Button         btnEditLeague  = null!;
        private Button         btnDeleteLeague= null!;
        private Button         btnClearLeague = null!;

        // Таб 2 – Участници
        private SplitContainer splitPart      = null!;
        private Panel          pnlPartTop     = null!;
        private Label          lblSel         = null!;
        private Label          lblPInfo       = null!;
        private DataGridView   dgvParticipants= null!;
        private Panel          pnlPartForm    = null!;
        private Label          lAC            = null!;
        private ComboBox       cboAvail       = null!;
        private Button         btnAddClub     = null!;
        private Button         btnRemoveClub  = null!;

        // Таб 3 – Програма
        private SplitContainer splitSched     = null!;
        private Panel          pnlSchedLeft   = null!;
        private Label          lblSel2        = null!;
        private Label          lblSInfo       = null!;
        private DataGridView   dgvSchedule    = null!;
        private Panel          pnlSchedRight  = null!;
        private CheckBox       chkTwo         = null!;
        private Button         btnGenerate    = null!;
        private Button         btnDelSch      = null!;
        private Button         btnAutoCreate  = null!;
        private Label          lFR            = null!;
        private NumericUpDown  numFR          = null!;
        private Button         btnShowRound   = null!;
        private Button         btnShowAll     = null!;
        private Button         btnRefresh     = null!;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // ── init ────────────────────────────────────────────────────────
            lblTitle        = new Label();
            lblStatus       = new Label();
            tabMain         = new TabControl();
            tabLeagues      = new TabPage();
            tabParticipants = new TabPage();
            tabSchedule     = new TabPage();

            splitLeagues    = new SplitContainer();
            dgvLeagues      = new DataGridView();
            pnlLeagueForm   = new Panel();
            lN              = new Label();   txtName      = new TextBox();
            lS              = new Label();   txtSeason    = new TextBox();
            lblSeasonHint   = new Label();
            lT              = new Label();   numTeamCount = new NumericUpDown();
            btnAddLeague    = new Button();  btnEditLeague  = new Button();
            btnDeleteLeague = new Button();  btnClearLeague = new Button();

            splitPart       = new SplitContainer();
            pnlPartTop      = new Panel();
            lblSel          = new Label();   lblPInfo  = new Label();
            dgvParticipants = new DataGridView();
            pnlPartForm     = new Panel();
            lAC             = new Label();   cboAvail      = new ComboBox();
            btnAddClub      = new Button();  btnRemoveClub = new Button();

            splitSched      = new SplitContainer();
            pnlSchedLeft    = new Panel();
            lblSel2         = new Label();   lblSInfo = new Label();
            dgvSchedule     = new DataGridView();
            pnlSchedRight   = new Panel();
            chkTwo          = new CheckBox();
            btnGenerate     = new Button();  btnDelSch     = new Button();
            btnAutoCreate   = new Button();
            lFR             = new Label();   numFR         = new NumericUpDown();
            btnShowRound    = new Button();  btnShowAll    = new Button();
            btnRefresh      = new Button();

            // ── ФОРМА ───────────────────────────────────────────────────────
            this.Text          = "🏆 Лиги, Участници и Програма";
            this.Size          = new Size(1100, 720);
            this.MinimumSize   = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor     = Color.FromArgb(240, 244, 248);
            this.Font          = new Font("Segoe UI", 9.5f);
            this.Load         += LeaguesForm_Load;

            lblTitle.Text      = "🏆  Управление на Лиги / Първенства";
            lblTitle.Font      = new Font("Segoe UI", 14f, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(30, 78, 121);
            lblTitle.Location  = new Point(12, 10);
            lblTitle.AutoSize  = true;

            lblStatus.Text      = "Готово.";
            lblStatus.Location  = new Point(0, 0);
            lblStatus.Dock      = DockStyle.Bottom;
            lblStatus.Height    = 24;
            lblStatus.ForeColor = Color.FromArgb(80, 100, 120);
            lblStatus.Padding   = new Padding(8, 4, 0, 0);
            lblStatus.BackColor = Color.FromArgb(225, 232, 240);

            tabMain.Location = new Point(4, 44);
            tabMain.Anchor   = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            tabMain.Size     = new Size(this.ClientSize.Width - 8, this.ClientSize.Height - 72);
            tabMain.Font     = new Font("Segoe UI", 10f, FontStyle.Bold);
            tabLeagues.Text      = "   📋  Лиги   ";
            tabParticipants.Text = "   👥  Участници   ";
            tabSchedule.Text     = "   📅  Програма   ";
            tabLeagues.BackColor = tabParticipants.BackColor = tabSchedule.BackColor = Color.FromArgb(240, 244, 248);
            tabMain.TabPages.AddRange(new TabPage[] { tabLeagues, tabParticipants, tabSchedule });

            // ════════════════════════════════════════════════════════════════
            //  ТАБ 1 – ЛИГИ   (SplitContainer: ляво=грид, дясно=форма)
            // ════════════════════════════════════════════════════════════════
            splitLeagues.Dock             = DockStyle.Fill;
            splitLeagues.SplitterWidth    = 6;
            splitLeagues.BackColor        = Color.FromArgb(200, 210, 225);

            // Грид
            dgvLeagues.Dock             = DockStyle.Fill;
            dgvLeagues.SelectionChanged += dgvLeagues_SelectionChanged;
            splitLeagues.Panel1.Controls.Add(dgvLeagues);

            // Панел форма (дясно)
            pnlLeagueForm.Dock      = DockStyle.Fill;
            pnlLeagueForm.BackColor = Color.White;
            pnlLeagueForm.Padding   = new Padding(16, 12, 16, 12);

            // Помощна функция за ред
            int y = 12;
            Label MkLbl(string t) {
                var l = new Label { Text = t, Location = new Point(16, y), AutoSize = true,
                    Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
                y += 20; return l;
            }
            Control MkCtrl(Control c, int h = 28) {
                c.Location = new Point(16, y); c.Size = new Size(pnlLeagueForm.Width > 0 ? pnlLeagueForm.Width - 32 : 340, h);
                c.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                y += h + 10; return c;
            }
            Button MkBtn(string t, Color bg, EventHandler ev) {
                var b = new Button { Text = t, BackColor = bg, ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                    Cursor = Cursors.Hand, Location = new Point(16, y),
                    Size = new Size(340, 46), Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };
                b.Click += ev; y += 52; return b;
            }

            var lblName = MkLbl("Лига / Първенство *");
            txtName.Location = new Point(16, y); txtName.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            txtName.Size = new Size(340, 28); y += 38;

            var lblSeas = MkLbl("Сезон * (формат: 2025/2026)");
            txtSeason.Location = new Point(16, y); txtSeason.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            txtSeason.Size = new Size(340, 28); y += 32;

            lblSeasonHint.Text = "Пример: 2025/2026"; lblSeasonHint.Location = new Point(16, y);
            lblSeasonHint.AutoSize = true; lblSeasonHint.ForeColor = Color.Gray;
            lblSeasonHint.Font = new Font("Segoe UI", 8.5f, FontStyle.Italic); y += 28;

            var lblTc = MkLbl("Брой отбори *");
            numTeamCount.Location = new Point(16, y); numTeamCount.Size = new Size(340, 28);
            numTeamCount.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            numTeamCount.Minimum  = 2; numTeamCount.Maximum = 32; numTeamCount.Value = 8; y += 44;

            // Separator
            var sep1 = new Label { Location = new Point(0, y), Height = 1, Dock = DockStyle.None,
                Width = 360, BorderStyle = BorderStyle.Fixed3D, BackColor = Color.LightGray }; y += 12;

            btnAddLeague.Text = "➕  ДОБАВИ НОВА ЛИГА"; btnAddLeague.Location = new Point(16, y);
            btnAddLeague.Size = new Size(340, 46); btnAddLeague.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnAddLeague.BackColor = Color.FromArgb(39, 174, 96); btnAddLeague.ForeColor = Color.White;
            btnAddLeague.FlatStyle = FlatStyle.Flat; btnAddLeague.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnAddLeague.Cursor = Cursors.Hand; btnAddLeague.Click += btnAddLeague_Click; y += 54;

            btnEditLeague.Text = "✏️  Редактирай избраната"; btnEditLeague.Location = new Point(16, y);
            btnEditLeague.Size = new Size(340, 40); btnEditLeague.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnEditLeague.BackColor = Color.FromArgb(230, 126, 34); btnEditLeague.ForeColor = Color.White;
            btnEditLeague.FlatStyle = FlatStyle.Flat; btnEditLeague.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnEditLeague.Cursor = Cursors.Hand; btnEditLeague.Enabled = false; btnEditLeague.Click += btnEditLeague_Click; y += 48;

            btnDeleteLeague.Text = "🗑️  Изтрий избраната"; btnDeleteLeague.Location = new Point(16, y);
            btnDeleteLeague.Size = new Size(340, 40); btnDeleteLeague.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnDeleteLeague.BackColor = Color.FromArgb(192, 57, 43); btnDeleteLeague.ForeColor = Color.White;
            btnDeleteLeague.FlatStyle = FlatStyle.Flat; btnDeleteLeague.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnDeleteLeague.Cursor = Cursors.Hand; btnDeleteLeague.Enabled = false; btnDeleteLeague.Click += btnDeleteLeague_Click; y += 48;

            var sep2 = new Label { Location = new Point(0, y), Height = 1, Width = 360,
                BorderStyle = BorderStyle.Fixed3D, BackColor = Color.LightGray }; y += 12;

            btnClearLeague.Text = "✖  Изчисти полетата"; btnClearLeague.Location = new Point(16, y);
            btnClearLeague.Size = new Size(340, 36); btnClearLeague.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnClearLeague.BackColor = Color.FromArgb(127, 140, 141); btnClearLeague.ForeColor = Color.White;
            btnClearLeague.FlatStyle = FlatStyle.Flat; btnClearLeague.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnClearLeague.Cursor = Cursors.Hand; btnClearLeague.Click += btnClearLeagueForm_Click;

            pnlLeagueForm.Controls.AddRange(new Control[] {
                lblName, txtName, lblSeas, txtSeason, lblSeasonHint,
                lblTc, numTeamCount, sep1, btnAddLeague,
                btnEditLeague, btnDeleteLeague, sep2, btnClearLeague
            });
            splitLeagues.Panel2.Controls.Add(pnlLeagueForm);

            // Scroll in right panel
            pnlLeagueForm.AutoScroll = true;
            var innerLbl = new Label { Text = "  Данни за лигата", Dock = DockStyle.Top, Height = 32,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 78, 121),
                BackColor = Color.FromArgb(220, 230, 245),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0) };
            pnlLeagueForm.Controls.Add(innerLbl);

            tabLeagues.Controls.Add(splitLeagues);

            // ════════════════════════════════════════════════════════════════
            //  ТАБ 2 – УЧАСТНИЦИ
            // ════════════════════════════════════════════════════════════════
            splitPart.Dock             = DockStyle.Fill;
            splitPart.SplitterWidth    = 6;
            splitPart.BackColor        = Color.FromArgb(200, 210, 225);

            // Ляво: заглавие + грид
            var pnlPL = new Panel { Dock = DockStyle.Fill };

            pnlPartTop.Dock      = DockStyle.Top;
            pnlPartTop.Height    = 56;
            pnlPartTop.BackColor = Color.FromArgb(220, 230, 245);
            pnlPartTop.Padding   = new Padding(8, 6, 8, 4);

            lblSel.Text      = "— Изберете лига от Таб 1 —";
            lblSel.Dock      = DockStyle.Top;
            lblSel.Height    = 26;
            lblSel.Font      = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblSel.ForeColor = Color.FromArgb(30, 78, 121);

            lblPInfo.Text      = "";
            lblPInfo.Dock      = DockStyle.Top;
            lblPInfo.Height    = 22;
            lblPInfo.ForeColor = Color.FromArgb(80, 100, 120);

            pnlPartTop.Controls.Add(lblPInfo);
            pnlPartTop.Controls.Add(lblSel);

            dgvParticipants.Dock = DockStyle.Fill;

            pnlPL.Controls.Add(dgvParticipants);
            pnlPL.Controls.Add(pnlPartTop);
            splitPart.Panel1.Controls.Add(pnlPL);

            // Дясно: форма за добавяне/премахване
            pnlPartForm.Dock      = DockStyle.Fill;
            pnlPartForm.BackColor = Color.White;
            pnlPartForm.Padding   = new Padding(16, 12, 16, 12);

            var partTitle = new Label { Text = "  Управление на участници", Dock = DockStyle.Top, Height = 32,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 78, 121),
                BackColor = Color.FromArgb(220, 230, 245),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0) };

            var lAddTitle = new Label { Text = "➕  Добавяне на отбор", Location = new Point(16, 48),
                AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(39, 174, 96) };

            lAC.Text = "Налични клубове:"; lAC.Location = new Point(16, 70);
            lAC.AutoSize = true; lAC.Font = new Font("Segoe UI", 9f, FontStyle.Bold);

            cboAvail.Location = new Point(16, 92); cboAvail.Size = new Size(310, 28);
            cboAvail.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            cboAvail.DropDownStyle = ComboBoxStyle.DropDownList;
            cboAvail.Font     = new Font("Segoe UI", 9.5f);

            btnAddClub.Text      = "➕   Добави отбора в лигата";
            btnAddClub.Location  = new Point(16, 130); btnAddClub.Size = new Size(310, 46);
            btnAddClub.Anchor    = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnAddClub.BackColor = Color.FromArgb(39, 174, 96); btnAddClub.ForeColor = Color.White;
            btnAddClub.FlatStyle = FlatStyle.Flat; btnAddClub.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnAddClub.Cursor    = Cursors.Hand; btnAddClub.Click += btnAddClub_Click;

            var sepPart = new Label { Location = new Point(0, 188), Height = 1, Width = 360,
                BorderStyle = BorderStyle.Fixed3D, BackColor = Color.LightGray,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            var lRemTitle = new Label { Text = "🗑️  Премахване на отбор", Location = new Point(16, 200),
                AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(192, 57, 43) };

            var lRemHint = new Label { Text = "Изберете отбор от списъка вляво и натиснете:",
                Location = new Point(16, 222), AutoSize = true, ForeColor = Color.FromArgb(100, 100, 100) };

            btnRemoveClub.Text      = "🗑️   Премахни избрания отбор";
            btnRemoveClub.Location  = new Point(16, 248); btnRemoveClub.Size = new Size(310, 46);
            btnRemoveClub.Anchor    = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnRemoveClub.BackColor = Color.FromArgb(192, 57, 43); btnRemoveClub.ForeColor = Color.White;
            btnRemoveClub.FlatStyle = FlatStyle.Flat; btnRemoveClub.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnRemoveClub.Cursor    = Cursors.Hand; btnRemoveClub.Click += btnRemoveClub_Click;

            pnlPartForm.Controls.AddRange(new Control[] {
                partTitle, lAddTitle, lAC, cboAvail, btnAddClub,
                sepPart, lRemTitle, lRemHint, btnRemoveClub
            });
            splitPart.Panel2.Controls.Add(pnlPartForm);
            tabParticipants.Controls.Add(splitPart);

            // ════════════════════════════════════════════════════════════════
            //  ТАБ 3 – ПРОГРАМА
            // ════════════════════════════════════════════════════════════════
            splitSched.Dock             = DockStyle.Fill;
            splitSched.SplitterWidth    = 6;
            splitSched.BackColor        = Color.FromArgb(200, 210, 225);

            // Ляво: заглавие + грид
            var pnlSL = new Panel { Dock = DockStyle.Fill };

            var pnlSchedTop = new Panel { Dock = DockStyle.Top, Height = 56, BackColor = Color.FromArgb(220, 230, 245), Padding = new Padding(8, 6, 8, 4) };

            lblSel2.Text      = "— Изберете лига от Таб 1 —";
            lblSel2.Dock      = DockStyle.Top; lblSel2.Height = 26;
            lblSel2.Font      = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblSel2.ForeColor = Color.FromArgb(30, 78, 121);

            lblSInfo.Text      = ""; lblSInfo.Dock = DockStyle.Top; lblSInfo.Height = 22;
            lblSInfo.ForeColor = Color.FromArgb(80, 100, 120);

            pnlSchedTop.Controls.Add(lblSInfo);
            pnlSchedTop.Controls.Add(lblSel2);

            dgvSchedule.Dock = DockStyle.Fill;

            pnlSL.Controls.Add(dgvSchedule);
            pnlSL.Controls.Add(pnlSchedTop);
            splitSched.Panel1.Controls.Add(pnlSL);

            // Дясно: контроли за генериране
            pnlSchedRight.Dock      = DockStyle.Fill;
            pnlSchedRight.BackColor = Color.White;
            pnlSchedRight.AutoScroll= true;

            var schedTitle = new Label { Text = "  Генериране на програма", Dock = DockStyle.Top, Height = 32,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 78, 121),
                BackColor = Color.FromArgb(220, 230, 245),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0) };

            chkTwo.Text     = "Двоен кръговник (домакинство + гостуване)";
            chkTwo.Location = new Point(16, 44);
            chkTwo.Size     = new Size(310, 36);
            chkTwo.Anchor   = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            chkTwo.Font     = new Font("Segoe UI", 9.5f);

            btnGenerate.Text      = "⚡   ГЕНЕРИРАЙ ПРОГРАМА";
            btnGenerate.Location  = new Point(16, 88); btnGenerate.Size = new Size(310, 52);
            btnGenerate.Anchor    = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnGenerate.BackColor = Color.FromArgb(30, 78, 121); btnGenerate.ForeColor = Color.White;
            btnGenerate.FlatStyle = FlatStyle.Flat; btnGenerate.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            btnGenerate.Cursor    = Cursors.Hand; btnGenerate.Click += btnGenerate_Click;

            btnDelSch.Text      = "🗑️   Изтрий програмата";
            btnDelSch.Location  = new Point(16, 150); btnDelSch.Size = new Size(310, 42);
            btnDelSch.Anchor    = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnDelSch.BackColor = Color.FromArgb(192, 57, 43); btnDelSch.ForeColor = Color.White;
            btnDelSch.FlatStyle = FlatStyle.Flat; btnDelSch.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnDelSch.Cursor    = Cursors.Hand; btnDelSch.Enabled = false; btnDelSch.Click += btnDelSch_Click;

            var sepSG = new Label { Location = new Point(0, 202), Height = 1, Width = 360,
                BorderStyle = BorderStyle.Fixed3D, BackColor = Color.LightGray,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            btnAutoCreate.Text      = "🪄   АВТОМАТИЧНО СЪЗДАВАНЕ";
            btnAutoCreate.Location  = new Point(16, 212); btnAutoCreate.Size = new Size(310, 52);
            btnAutoCreate.Anchor    = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnAutoCreate.BackColor = Color.FromArgb(142, 68, 173); btnAutoCreate.ForeColor = Color.White;
            btnAutoCreate.FlatStyle = FlatStyle.Flat; btnAutoCreate.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnAutoCreate.Cursor    = Cursors.Hand; btnAutoCreate.Click += btnAutoCreate_Click;

            var sepSF = new Label { Location = new Point(0, 274), Height = 1, Width = 360,
                BorderStyle = BorderStyle.Fixed3D, BackColor = Color.LightGray,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            var lFilter = new Label { Text = "  Филтър по кръг", Location = new Point(0, 284),
                Height = 28, Width = 360, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 78, 121), BackColor = Color.FromArgb(230, 238, 250),
                TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8,0,0,0),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            lFR.Text = "Кръг №:"; lFR.Location = new Point(16, 322); lFR.AutoSize = true;

            numFR.Location = new Point(90, 318); numFR.Size = new Size(68, 28);
            numFR.Minimum  = 0; numFR.Maximum = 99; numFR.Value = 0;

            btnShowRound.Text      = "🔍  Покажи кръга";
            btnShowRound.Location  = new Point(16, 358); btnShowRound.Size = new Size(148, 38);
            btnShowRound.BackColor = Color.FromArgb(70, 130, 180); btnShowRound.ForeColor = Color.White;
            btnShowRound.FlatStyle = FlatStyle.Flat; btnShowRound.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            btnShowRound.Cursor    = Cursors.Hand; btnShowRound.Click += btnShowRound_Click;

            btnShowAll.Text      = "📋  Всички";
            btnShowAll.Location  = new Point(172, 358); btnShowAll.Size = new Size(154, 38);
            btnShowAll.BackColor = Color.FromArgb(127, 140, 141); btnShowAll.ForeColor = Color.White;
            btnShowAll.FlatStyle = FlatStyle.Flat; btnShowAll.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            btnShowAll.Cursor    = Cursors.Hand; btnShowAll.Click += btnShowAll_Click;

            var sepSR = new Label { Location = new Point(0, 408), Height = 1, Width = 360,
                BorderStyle = BorderStyle.Fixed3D, BackColor = Color.LightGray,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top };

            btnRefresh.Text      = "🔄  Обнови всичко";
            btnRefresh.Location  = new Point(16, 418); btnRefresh.Size = new Size(310, 38);
            btnRefresh.Anchor    = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            btnRefresh.BackColor = Color.FromArgb(52, 73, 94); btnRefresh.ForeColor = Color.White;
            btnRefresh.FlatStyle = FlatStyle.Flat; btnRefresh.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnRefresh.Cursor    = Cursors.Hand; btnRefresh.Click += btnRefresh_Click;

            pnlSchedRight.Controls.AddRange(new Control[] {
                schedTitle, chkTwo, btnGenerate, btnDelSch, sepSG, btnAutoCreate,
                sepSF, lFilter, lFR, numFR, btnShowRound, btnShowAll, sepSR, btnRefresh
            });
            splitSched.Panel2.Controls.Add(pnlSchedRight);
            tabSchedule.Controls.Add(splitSched);

            // ── Финално ─────────────────────────────────────────────────────
            this.Controls.AddRange(new Control[] { lblTitle, tabMain, lblStatus });
            this.ResumeLayout(false);
        }
    }
}
