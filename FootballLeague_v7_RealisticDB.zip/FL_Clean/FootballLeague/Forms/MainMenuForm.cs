namespace FootballLeague.Forms
{
    public class MainMenuForm : Form
    {
        public MainMenuForm()
        {
            this.Text = "Football League – Главно меню";
            this.Size = new Size(380, 530);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 244, 248);
            this.Font = new Font("Segoe UI", 10f);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            var lbl = new Label
            {
                Text = "⚽  Football League",
                Font = new Font("Segoe UI", 14f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 78, 121),
                Location = new Point(20, 20), AutoSize = true
            };

            Button B(string t, Color bg, int y, EventHandler h)
            {
                var b = GH.Btn(t, bg, 40, y, 290, 46);
                b.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
                b.Click += h; return b;
            }

            var b1 = B("🏟️  Управление на клубове",  Color.FromArgb(30,78,121),   70,  (s,e) => new ClubsForm().ShowDialog());
            var b2 = B("👤  Управление на играчи",    Color.FromArgb(39,174,96),   126, (s,e) => new PlayersForm().ShowDialog());
            var b3 = B("🔄  Трансфери",               Color.FromArgb(142,68,173),  182, (s,e) => new TransfersForm().ShowDialog());
            var b4 = B("🏆  Лиги и Програма",         Color.FromArgb(41,128,185),  238, (s,e) => new LeaguesForm().ShowDialog());
            var b5 = B("⚽  Мачове и Резултати",       Color.FromArgb(192,57,43),   294, (s,e) => new MatchesForm().ShowDialog());
            var b6 = B("📊  Класиране",               Color.FromArgb(243,156,18),  350, (s,e) => new StandingsForm().ShowDialog());

            this.Controls.AddRange(new Control[] { lbl, b1, b2, b3, b4, b5, b6 });
        }
    }
}
