using System.Configuration;
namespace FootballLeague.Data
{
    internal static class DbConfig
    {
        public static string ConnectionString =>
            ConfigurationManager.ConnectionStrings["FootballDB"]?.ConnectionString
            ?? throw new InvalidOperationException("Connection string FootballDB not found.");
    }
}