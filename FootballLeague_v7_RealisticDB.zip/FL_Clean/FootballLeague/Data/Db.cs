using MySql.Data.MySqlClient;
using System.Data;
namespace FootballLeague.Data
{
    internal static class Db
    {
        public static MySqlConnection GetConnection() => new(DbConfig.ConnectionString);
        public static int ExecuteNonQuery(string sql, params MySqlParameter[] p)
        {
            using var conn = GetConnection(); conn.Open();
            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddRange(p); return cmd.ExecuteNonQuery();
        }
        public static DataTable GetDataTable(string sql, params MySqlParameter[] p)
        {
            using var conn = GetConnection(); conn.Open();
            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddRange(p);
            using var adapter = new MySqlDataAdapter(cmd);
            var table = new DataTable(); adapter.Fill(table); return table;
        }
        public static object? ExecuteScalar(string sql, params MySqlParameter[] p)
        {
            using var conn = GetConnection(); conn.Open();
            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddRange(p); return cmd.ExecuteScalar();
        }
        public static MySqlParameter Param(string name, object? value) => new(name, value ?? DBNull.Value);
    }
}