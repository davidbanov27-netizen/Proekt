using FootballLeague.Data;
using FootballLeague.Models;
using MySql.Data.MySqlClient;
using System.Data;
namespace FootballLeague.Repositories
{
    internal class PlayersRepository
    {
        public List<Player> GetPlayers(int? clubId = null, string? position = null, string? nameLike = null)
        {
            var sql = @"SELECT p.PlayerId,p.ClubId,c.Name AS ClubName,p.FullName,
                               p.BirthDate,p.Position,p.ShirtNumber,p.Status
                        FROM players p JOIN clubs c ON c.ClubId=p.ClubId WHERE 1=1";
            var prms = new List<MySqlParameter>();
            if (clubId > 0)   { sql += " AND p.ClubId=@C";     prms.Add(Db.Param("@C", clubId)); }
            if (!string.IsNullOrWhiteSpace(position) && position != "Всички")
                               { sql += " AND p.Position=@P";  prms.Add(Db.Param("@P", position)); }
            if (!string.IsNullOrWhiteSpace(nameLike))
                               { sql += " AND p.FullName LIKE @N"; prms.Add(Db.Param("@N", $"%{nameLike.Trim()}%")); }
            sql += " ORDER BY c.Name,p.FullName;";
            return Db.GetDataTable(sql, prms.ToArray()).Rows.Cast<DataRow>().Select(Map).ToList();
        }
        public void Add(Player p) => Db.ExecuteNonQuery(
            "INSERT INTO players(ClubId,FullName,BirthDate,Position,ShirtNumber,Status) VALUES(@C,@F,@B,@P,@S,@St);",
            Db.Param("@C", p.ClubId), Db.Param("@F", p.FullName.Trim()),
            Db.Param("@B", p.BirthDate.ToString("yyyy-MM-dd")), Db.Param("@P", p.Position),
            Db.Param("@S", p.ShirtNumber.HasValue ? (object)p.ShirtNumber.Value : DBNull.Value),
            Db.Param("@St", p.Status));
        public void Update(Player p) => Db.ExecuteNonQuery(
            "UPDATE players SET ClubId=@C,FullName=@F,BirthDate=@B,Position=@P,ShirtNumber=@S,Status=@St WHERE PlayerId=@Id;",
            Db.Param("@C", p.ClubId), Db.Param("@F", p.FullName.Trim()),
            Db.Param("@B", p.BirthDate.ToString("yyyy-MM-dd")), Db.Param("@P", p.Position),
            Db.Param("@S", p.ShirtNumber.HasValue ? (object)p.ShirtNumber.Value : DBNull.Value),
            Db.Param("@St", p.Status), Db.Param("@Id", p.PlayerId));
        public void Delete(int id) => Db.ExecuteNonQuery(
            "DELETE FROM players WHERE PlayerId=@Id;", Db.Param("@Id", id));
        private static Player Map(DataRow r) => new()
        {
            PlayerId = Convert.ToInt32(r["PlayerId"]), ClubId = Convert.ToInt32(r["ClubId"]),
            ClubName = r["ClubName"]?.ToString() ?? "", FullName = r["FullName"]?.ToString() ?? "",
            BirthDate = Convert.ToDateTime(r["BirthDate"]), Position = r["Position"]?.ToString() ?? "",
            ShirtNumber = r["ShirtNumber"] is DBNull ? null : Convert.ToInt32(r["ShirtNumber"]),
            Status = r["Status"]?.ToString() ?? "Active"
        };
    }
}
