using FootballLeague.Data;
using FootballLeague.Models;
using System.Data;
namespace FootballLeague.Repositories
{
    internal class LeaguesRepository
    {
        public List<League> GetAll()
        {
            var t = Db.GetDataTable("SELECT LeagueId,Name,Season,TeamCount FROM leagues ORDER BY Season DESC,Name;");
            return t.Rows.Cast<DataRow>().Select(Map).ToList();
        }
        public void Create(League l) => Db.ExecuteNonQuery(
            "INSERT INTO leagues(Name,Season,TeamCount) VALUES(@N,@S,@T);",
            Db.Param("@N", l.Name.Trim()), Db.Param("@S", l.Season.Trim()), Db.Param("@T", l.TeamCount));
        public void Update(League l) => Db.ExecuteNonQuery(
            "UPDATE leagues SET Name=@N,Season=@S,TeamCount=@T WHERE LeagueId=@Id;",
            Db.Param("@N", l.Name.Trim()), Db.Param("@S", l.Season.Trim()),
            Db.Param("@T", l.TeamCount), Db.Param("@Id", l.LeagueId));
        public void Delete(int id) => Db.ExecuteNonQuery(
            "DELETE FROM leagues WHERE LeagueId=@Id;", Db.Param("@Id", id));
        public bool HasParticipants(int id) =>
            Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM league_teams WHERE LeagueId=@Id;", Db.Param("@Id", id))) > 0;
        public bool HasMatches(int id) =>
            Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM matches WHERE LeagueId=@Id;", Db.Param("@Id", id))) > 0;
        private static League Map(DataRow r) => new()
        {
            LeagueId = Convert.ToInt32(r["LeagueId"]), Name = r["Name"]?.ToString() ?? "",
            Season = r["Season"]?.ToString() ?? "", TeamCount = Convert.ToInt32(r["TeamCount"])
        };
    }
}
