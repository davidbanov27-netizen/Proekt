using FootballLeague.Data;
using FootballLeague.Models;
using MySql.Data.MySqlClient;
using System.Data;
namespace FootballLeague.Repositories
{
    internal class TransfersRepository
    {
        public List<Transfer> GetTransfers(int? playerId=null,int? clubId=null,DateTime? fromDate=null,DateTime? toDate=null)
        {
            var sql=@"SELECT t.TransferId,t.PlayerId,p.FullName AS PlayerName,t.FromClubId,
                             IFNULL(fc.Name,'Free agent') AS FromClubName,t.ToClubId,tc.Name AS ToClubName,
                             t.TransferDate,t.Fee,t.Note
                      FROM transfers t JOIN players p ON p.PlayerId=t.PlayerId
                      LEFT JOIN clubs fc ON fc.ClubId=t.FromClubId
                      JOIN clubs tc ON tc.ClubId=t.ToClubId WHERE 1=1";
            var prms=new List<MySqlParameter>();
            if(playerId>0){sql+=" AND t.PlayerId=@P";prms.Add(Db.Param("@P",playerId));}
            if(clubId>0){sql+=" AND (t.FromClubId=@C OR t.ToClubId=@C)";prms.Add(Db.Param("@C",clubId));}
            if(fromDate.HasValue){sql+=" AND t.TransferDate>=@F";prms.Add(Db.Param("@F",fromDate.Value.ToString("yyyy-MM-dd")));}
            if(toDate.HasValue){sql+=" AND t.TransferDate<=@T";prms.Add(Db.Param("@T",toDate.Value.ToString("yyyy-MM-dd")));}
            sql+=" ORDER BY t.TransferDate DESC;";
            return Db.GetDataTable(sql,prms.ToArray()).Rows.Cast<DataRow>().Select(Map).ToList();
        }
        public void AddTransfer(Transfer t)
        {
            using var conn=Db.GetConnection();conn.Open();
            using var tx=conn.BeginTransaction();
            try
            {
                using(var cmd=new MySqlCommand("INSERT INTO transfers(PlayerId,FromClubId,ToClubId,TransferDate,Fee,Note) VALUES(@P,@F,@T,@D,@Fe,@N);",conn,tx))
                {
                    cmd.Parameters.AddRange(new[]{Db.Param("@P",t.PlayerId),
                        Db.Param("@F",t.FromClubId.HasValue?(object)t.FromClubId.Value:DBNull.Value),
                        Db.Param("@T",t.ToClubId),Db.Param("@D",t.TransferDate.ToString("yyyy-MM-dd")),
                        Db.Param("@Fe",t.Fee.HasValue?(object)t.Fee.Value:DBNull.Value),Db.Param("@N",t.Note.Trim())});
                    cmd.ExecuteNonQuery();
                }
                using(var cmd=new MySqlCommand("UPDATE players SET ClubId=@T WHERE PlayerId=@P;",conn,tx))
                { cmd.Parameters.AddRange(new[]{Db.Param("@T",t.ToClubId),Db.Param("@P",t.PlayerId)}); cmd.ExecuteNonQuery(); }
                tx.Commit();
            }
            catch{tx.Rollback();throw;}
        }
        private static Transfer Map(DataRow r)=>new()
        {
            TransferId=Convert.ToInt32(r["TransferId"]),PlayerId=Convert.ToInt32(r["PlayerId"]),
            PlayerName=r["PlayerName"]?.ToString()??"",
            FromClubId=r["FromClubId"] is DBNull?null:Convert.ToInt32(r["FromClubId"]),
            FromClubName=r["FromClubName"]?.ToString()??"",ToClubId=Convert.ToInt32(r["ToClubId"]),
            ToClubName=r["ToClubName"]?.ToString()??"",TransferDate=Convert.ToDateTime(r["TransferDate"]),
            Fee=r["Fee"] is DBNull?null:Convert.ToDecimal(r["Fee"]),Note=r["Note"]?.ToString()??""
        };
    }
}
