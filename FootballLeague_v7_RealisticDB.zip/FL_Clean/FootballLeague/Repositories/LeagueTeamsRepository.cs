using FootballLeague.Data;
using FootballLeague.Models;
using System.Data;
namespace FootballLeague.Repositories
{
    internal class LeagueTeamsRepository
    {
        public List<Club> GetParticipants(int leagueId)
        {
            const string sql = @"SELECT c.ClubId,c.Name,c.City,c.CreatedAt
                                 FROM league_teams lt JOIN clubs c ON c.ClubId=lt.ClubId
                                 WHERE lt.LeagueId=@L ORDER BY c.Name;";
            return Db.GetDataTable(sql, Db.Param("@L", leagueId))
                     .Rows.Cast<DataRow>().Select(Map).ToList();
        }
        public List<Club> GetAvailableClubs(int leagueId)
        {
            const string sql = @"SELECT c.ClubId,c.Name,c.City,c.CreatedAt FROM clubs c
                                 LEFT JOIN league_teams lt ON lt.ClubId=c.ClubId AND lt.LeagueId=@L
                                 WHERE lt.ClubId IS NULL ORDER BY c.Name;";
            return Db.GetDataTable(sql, Db.Param("@L", leagueId))
                     .Rows.Cast<DataRow>().Select(Map).ToList();
        }
        public void AddClub(int leagueId, int clubId) => Db.ExecuteNonQuery(
            "INSERT INTO league_teams(LeagueId,ClubId) VALUES(@L,@C);",
            Db.Param("@L", leagueId), Db.Param("@C", clubId));
        public void RemoveClub(int leagueId, int clubId) => Db.ExecuteNonQuery(
            "DELETE FROM league_teams WHERE LeagueId=@L AND ClubId=@C;",
            Db.Param("@L", leagueId), Db.Param("@C", clubId));
        private static Club Map(DataRow r) => new()
        {
            ClubId = Convert.ToInt32(r["ClubId"]), Name = r["Name"]?.ToString() ?? "",
            City = r["City"]?.ToString() ?? "",
            CreatedAt = r["CreatedAt"] is DBNull ? null : Convert.ToDateTime(r["CreatedAt"])
        };
    }
}
