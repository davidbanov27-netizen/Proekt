using FootballLeague.Data;
using FootballLeague.Models;
using System.Data;
namespace FootballLeague.Repositories
{
    internal class EventsRepository
    {
        // ── Голове ─────────────────────────────────────────────────────────────
        public List<Goal> GetGoals(int matchId)
        {
            const string sql=@"SELECT g.GoalId,g.MatchId,g.PlayerId,p.FullName AS PlayerName,
                                      g.ClubId,c.Name AS ClubName,g.Minute,g.IsOwnGoal
                               FROM goals g JOIN players p ON p.PlayerId=g.PlayerId
                               JOIN clubs c ON c.ClubId=g.ClubId WHERE g.MatchId=@M ORDER BY g.Minute;";
            return Db.GetDataTable(sql,Db.Param("@M",matchId)).Rows.Cast<DataRow>().Select(MapGoal).ToList();
        }
        public void AddGoal(Goal g)
        {
            ValidateMinute(g.Minute);
            Db.ExecuteNonQuery("INSERT INTO goals(MatchId,PlayerId,ClubId,Minute,IsOwnGoal) VALUES(@M,@P,@C,@Mi,@O);",
                Db.Param("@M",g.MatchId),Db.Param("@P",g.PlayerId),Db.Param("@C",g.ClubId),
                Db.Param("@Mi",g.Minute),Db.Param("@O",g.IsOwnGoal?1:0));
        }
        public void DeleteGoal(int id) => Db.ExecuteNonQuery("DELETE FROM goals WHERE GoalId=@Id;",Db.Param("@Id",id));
        public (int home,int away) CountGoals(int matchId,int homeClubId)
        {
            int hN=Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM goals WHERE MatchId=@M AND ClubId=@C AND IsOwnGoal=0;",Db.Param("@M",matchId),Db.Param("@C",homeClubId)));
            int hO=Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM goals WHERE MatchId=@M AND ClubId<>@C AND IsOwnGoal=1;",Db.Param("@M",matchId),Db.Param("@C",homeClubId)));
            int aN=Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM goals WHERE MatchId=@M AND ClubId<>@C AND IsOwnGoal=0;",Db.Param("@M",matchId),Db.Param("@C",homeClubId)));
            int aO=Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM goals WHERE MatchId=@M AND ClubId=@C AND IsOwnGoal=1;",Db.Param("@M",matchId),Db.Param("@C",homeClubId)));
            return(hN+hO,aN+aO);
        }
        // ── Картони ────────────────────────────────────────────────────────────
        public List<Card> GetCards(int matchId)
        {
            const string sql=@"SELECT k.CardId,k.MatchId,k.PlayerId,p.FullName AS PlayerName,
                                      p.ClubId AS ClubId,c.Name AS ClubName,k.CardType,k.Minute
                               FROM cards k JOIN players p ON p.PlayerId=k.PlayerId
                               JOIN clubs c ON c.ClubId=p.ClubId WHERE k.MatchId=@M ORDER BY k.Minute;";
            return Db.GetDataTable(sql,Db.Param("@M",matchId)).Rows.Cast<DataRow>().Select(MapCard).ToList();
        }
        public void AddCard(Card c)
        {
            ValidateMinute(c.Minute);
            if(c.CardType!="Yellow"&&c.CardType!="Red") throw new ArgumentException("Картонът трябва да е Yellow или Red!");
            Db.ExecuteNonQuery("INSERT INTO cards(MatchId,PlayerId,CardType,Minute) VALUES(@M,@P,@T,@Mi);",
                Db.Param("@M",c.MatchId),Db.Param("@P",c.PlayerId),Db.Param("@T",c.CardType),Db.Param("@Mi",c.Minute));
        }
        public void DeleteCard(int id) => Db.ExecuteNonQuery("DELETE FROM cards WHERE CardId=@Id;",Db.Param("@Id",id));
        // ── Фалове ─────────────────────────────────────────────────────────────
        public List<Foul> GetFouls(int matchId)
        {
            const string sql=@"SELECT f.FoulId,f.MatchId,f.PlayerId,p.FullName AS PlayerName,
                                      p.ClubId AS ClubId,c.Name AS ClubName,f.Minute,f.FoulType
                               FROM fouls f JOIN players p ON p.PlayerId=f.PlayerId
                               JOIN clubs c ON c.ClubId=p.ClubId WHERE f.MatchId=@M ORDER BY f.Minute;";
            return Db.GetDataTable(sql,Db.Param("@M",matchId)).Rows.Cast<DataRow>().Select(MapFoul).ToList();
        }
        public void AddFoul(Foul f)
        {
            ValidateMinute(f.Minute);
            Db.ExecuteNonQuery("INSERT INTO fouls(MatchId,PlayerId,Minute,FoulType) VALUES(@M,@P,@Mi,@T);",
                Db.Param("@M",f.MatchId),Db.Param("@P",f.PlayerId),Db.Param("@Mi",f.Minute),Db.Param("@T",f.FoulType.Trim()));
        }
        public void DeleteFoul(int id) => Db.ExecuteNonQuery("DELETE FROM fouls WHERE FoulId=@Id;",Db.Param("@Id",id));
        // ── Helpers ────────────────────────────────────────────────────────────
        private static void ValidateMinute(int min)
        { if(min<1||min>120) throw new ArgumentException($"Минутата трябва да е между 1 и 120 (въведено: {min})!"); }
        private static Goal MapGoal(DataRow r)=>new(){GoalId=Convert.ToInt32(r["GoalId"]),MatchId=Convert.ToInt32(r["MatchId"]),
            PlayerId=Convert.ToInt32(r["PlayerId"]),PlayerName=r["PlayerName"]?.ToString()??"",
            ClubId=Convert.ToInt32(r["ClubId"]),ClubName=r["ClubName"]?.ToString()??"",
            Minute=Convert.ToInt32(r["Minute"]),IsOwnGoal=Convert.ToInt32(r["IsOwnGoal"])==1};
        private static Card MapCard(DataRow r)=>new(){CardId=Convert.ToInt32(r["CardId"]),MatchId=Convert.ToInt32(r["MatchId"]),
            PlayerId=Convert.ToInt32(r["PlayerId"]),PlayerName=r["PlayerName"]?.ToString()??"",
            ClubId=Convert.ToInt32(r["ClubId"]),ClubName=r["ClubName"]?.ToString()??"",
            CardType=r["CardType"]?.ToString()??"Yellow",Minute=Convert.ToInt32(r["Minute"])};
        private static Foul MapFoul(DataRow r)=>new(){FoulId=Convert.ToInt32(r["FoulId"]),MatchId=Convert.ToInt32(r["MatchId"]),
            PlayerId=Convert.ToInt32(r["PlayerId"]),PlayerName=r["PlayerName"]?.ToString()??"",
            ClubId=Convert.ToInt32(r["ClubId"]),ClubName=r["ClubName"]?.ToString()??"",
            Minute=Convert.ToInt32(r["Minute"]),FoulType=r["FoulType"]?.ToString()??""};
    }
}
