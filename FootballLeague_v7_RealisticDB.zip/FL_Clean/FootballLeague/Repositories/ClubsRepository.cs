using FootballLeague.Data;
using FootballLeague.Models;
using System.Data;
namespace FootballLeague.Repositories
{
    internal class ClubsRepository
    {
        public List<Club> GetAll()
        {
            var t = Db.GetDataTable("SELECT ClubId,Name,City,CreatedAt FROM clubs ORDER BY Name;");
            return t.Rows.Cast<DataRow>().Select(Map).ToList();
        }
        public void Add(Club c) => Db.ExecuteNonQuery(
            "INSERT INTO clubs(Name,City,CreatedAt) VALUES(@Name,@City,NOW());",
            Db.Param("@Name", c.Name.Trim()), Db.Param("@City", c.City.Trim()));
        public void Update(Club c) => Db.ExecuteNonQuery(
            "UPDATE clubs SET Name=@Name,City=@City WHERE ClubId=@ClubId;",
            Db.Param("@Name", c.Name.Trim()), Db.Param("@City", c.City.Trim()), Db.Param("@ClubId", c.ClubId));
        public void Delete(int id) => Db.ExecuteNonQuery(
            "DELETE FROM clubs WHERE ClubId=@ClubId;", Db.Param("@ClubId", id));
        private static Club Map(DataRow r) => new()
        {
            ClubId = Convert.ToInt32(r["ClubId"]), Name = r["Name"]?.ToString() ?? "",
            City = r["City"]?.ToString() ?? "",
            CreatedAt = r["CreatedAt"] is DBNull ? null : Convert.ToDateTime(r["CreatedAt"])
        };
    }
}
