using FootballLeague.Data;
using FootballLeague.Models;
using MySql.Data.MySqlClient;
using System.Data;
namespace FootballLeague.Repositories
{
    internal class MatchesRepository
    {
        public List<Match> GetMatches(int? leagueId=null,int? roundNo=null,int? clubId=null,DateTime? fromDate=null)
        {
            var sql=@"SELECT m.MatchId,m.LeagueId,l.Name AS LeagueName,m.RoundNo,
                             m.HomeClubId,h.Name AS HomeClubName,h.City AS HomeClubCity,
                             m.AwayClubId,a.Name AS AwayClubName,a.City AS AwayClubCity,
                             m.MatchDate,m.Stadium,m.HomeGoals,m.AwayGoals,
                             (SELECT COUNT(*) FROM players p WHERE p.ClubId=m.HomeClubId) AS HomePlayers,
                             (SELECT COUNT(*) FROM players p WHERE p.ClubId=m.AwayClubId) AS AwayPlayers
                      FROM matches m JOIN leagues l ON l.LeagueId=m.LeagueId
                      JOIN clubs h ON h.ClubId=m.HomeClubId JOIN clubs a ON a.ClubId=m.AwayClubId
                      WHERE 1=1";
            var prms=new List<MySqlParameter>();
            if(leagueId>0){sql+=" AND m.LeagueId=@L";prms.Add(Db.Param("@L",leagueId));}
            if(roundNo>0) {sql+=" AND m.RoundNo=@R"; prms.Add(Db.Param("@R",roundNo));}
            if(clubId>0)  {sql+=" AND (m.HomeClubId=@C OR m.AwayClubId=@C)";prms.Add(Db.Param("@C",clubId));}
            if(fromDate.HasValue){sql+=" AND m.MatchDate>=@D";prms.Add(Db.Param("@D",fromDate.Value.ToString("yyyy-MM-dd")));}
            sql+=" ORDER BY m.RoundNo,m.MatchDate,m.MatchId;";
            return Db.GetDataTable(sql,prms.ToArray()).Rows.Cast<DataRow>().Select(MapMatch).ToList();
        }
        public Match? GetById(int id)
        {
            const string sql=@"SELECT m.MatchId,m.LeagueId,l.Name AS LeagueName,m.RoundNo,
                               m.HomeClubId,h.Name AS HomeClubName,h.City AS HomeClubCity,
                               m.AwayClubId,a.Name AS AwayClubName,a.City AS AwayClubCity,
                               m.MatchDate,m.Stadium,m.HomeGoals,m.AwayGoals,0 AS HomePlayers,0 AS AwayPlayers
                               FROM matches m JOIN leagues l ON l.LeagueId=m.LeagueId
                               JOIN clubs h ON h.ClubId=m.HomeClubId JOIN clubs a ON a.ClubId=m.AwayClubId
                               WHERE m.MatchId=@Id;";
            var t=Db.GetDataTable(sql,Db.Param("@Id",id));
            return t.Rows.Count>0?MapMatch(t.Rows[0]):null;
        }
        public void Add(Match m)
        {
            if(m.HomeClubId==m.AwayClubId) throw new InvalidOperationException("Домакинът и гостът не могат да са един и същ отбор!");
            Db.ExecuteNonQuery("INSERT INTO matches(LeagueId,RoundNo,HomeClubId,AwayClubId,MatchDate,Stadium) VALUES(@L,@R,@H,@A,@D,@S);",
                Db.Param("@L",m.LeagueId),Db.Param("@R",m.RoundNo),Db.Param("@H",m.HomeClubId),Db.Param("@A",m.AwayClubId),
                Db.Param("@D",m.MatchDate.HasValue?m.MatchDate.Value.ToString("yyyy-MM-dd"):(object)DBNull.Value),
                Db.Param("@S",m.Stadium.Trim()));
        }
        public void Update(Match m)
        {
            if(m.HomeClubId==m.AwayClubId) throw new InvalidOperationException("Домакинът и гостът не могат да са един и същ отбор!");
            Db.ExecuteNonQuery("UPDATE matches SET LeagueId=@L,RoundNo=@R,HomeClubId=@H,AwayClubId=@A,MatchDate=@D,Stadium=@S WHERE MatchId=@Id;",
                Db.Param("@L",m.LeagueId),Db.Param("@R",m.RoundNo),Db.Param("@H",m.HomeClubId),Db.Param("@A",m.AwayClubId),
                Db.Param("@D",m.MatchDate.HasValue?m.MatchDate.Value.ToString("yyyy-MM-dd"):(object)DBNull.Value),
                Db.Param("@S",m.Stadium.Trim()),Db.Param("@Id",m.MatchId));
        }
        public void SaveResult(int matchId,int homeGoals,int awayGoals) =>
            Db.ExecuteNonQuery("UPDATE matches SET HomeGoals=@H,AwayGoals=@A WHERE MatchId=@Id;",
                Db.Param("@H",homeGoals),Db.Param("@A",awayGoals),Db.Param("@Id",matchId));
        public void Delete(int id) => Db.ExecuteNonQuery("DELETE FROM matches WHERE MatchId=@Id;",Db.Param("@Id",id));
        public void DeleteSchedule(int leagueId) => Db.ExecuteNonQuery("DELETE FROM matches WHERE LeagueId=@L;",Db.Param("@L",leagueId));
        public bool HasMatches(int leagueId) => Convert.ToInt32(Db.ExecuteScalar("SELECT COUNT(*) FROM matches WHERE LeagueId=@L;",Db.Param("@L",leagueId)))>0;
        public int GenerateSchedule(int leagueId,List<int> clubIds,bool twoLegs=false)
        {
            if(clubIds.Count<2) throw new InvalidOperationException("Нужни са поне 2 отбора.");
            var rounds=BuildRoundRobin(clubIds,twoLegs);
            using var conn=Db.GetConnection();conn.Open();
            using var tx=conn.BeginTransaction();
            try
            {
                using(var del=new MySqlCommand("DELETE FROM matches WHERE LeagueId=@L;",conn,tx))
                { del.Parameters.Add(Db.Param("@L",leagueId));del.ExecuteNonQuery(); }
                int total=0;
                using var ins=new MySqlCommand("INSERT INTO matches(LeagueId,RoundNo,HomeClubId,AwayClubId) VALUES(@L,@R,@H,@A);",conn,tx);
                ins.Parameters.Add(Db.Param("@L",leagueId));
                ins.Parameters.Add(Db.Param("@R",0));
                ins.Parameters.Add(Db.Param("@H",0));
                ins.Parameters.Add(Db.Param("@A",0));
                foreach(var(rnd,home,away) in rounds)
                {
                    ins.Parameters["@R"].Value=rnd;
                    ins.Parameters["@H"].Value=home;
                    ins.Parameters["@A"].Value=away;
                    ins.ExecuteNonQuery();total++;
                }
                tx.Commit();return total;
            }
            catch{tx.Rollback();throw;}
        }
        private static List<(int r,int h,int a)> BuildRoundRobin(List<int> teams,bool twoLegs)
        {
            var list=new List<int>(teams);
            if(list.Count%2!=0)list.Add(0);
            int n=list.Count,rounds=n-1,half=n/2;
            var result=new List<(int,int,int)>();
            for(int r=0;r<rounds;r++)
            {
                for(int i=0;i<half;i++){int h=list[i],a=list[n-1-i];if(h!=0&&a!=0)result.Add(r%2==0?(r+1,h,a):(r+1,a,h));}
                var last=list[n-1];for(int i=n-1;i>1;i--)list[i]=list[i-1];list[1]=last;
            }
            if(twoLegs){int first=result.Count;for(int i=0;i<first;i++){var(rnd,h,a)=result[i];result.Add((rnd+rounds,a,h));}}
            return result;
        }
        private static Match MapMatch(DataRow r)=>new()
        {
            MatchId=Convert.ToInt32(r["MatchId"]),LeagueId=Convert.ToInt32(r["LeagueId"]),
            LeagueName=r["LeagueName"]?.ToString()??"",RoundNo=Convert.ToInt32(r["RoundNo"]),
            HomeClubId=Convert.ToInt32(r["HomeClubId"]),HomeClubName=r["HomeClubName"]?.ToString()??"",HomeClubCity=r["HomeClubCity"]?.ToString()??"",
            AwayClubId=Convert.ToInt32(r["AwayClubId"]),AwayClubName=r["AwayClubName"]?.ToString()??"",AwayClubCity=r["AwayClubCity"]?.ToString()??"",
            MatchDate=r["MatchDate"] is DBNull?null:Convert.ToDateTime(r["MatchDate"]),
            Stadium=r["Stadium"]?.ToString()??"",
            HomeGoals=r["HomeGoals"] is DBNull?null:Convert.ToInt32(r["HomeGoals"]),
            AwayGoals=r["AwayGoals"] is DBNull?null:Convert.ToInt32(r["AwayGoals"]),
            HomePlayers=Convert.ToInt32(r["HomePlayers"]),AwayPlayers=Convert.ToInt32(r["AwayPlayers"])
        };
    }
}
