using FootballLeague.Data;
using FootballLeague.Models;
using System.Data;

namespace FootballLeague.Repositories
{
    public class StandingsRepository
    {
        public List<Standing> GetStandings(int leagueId)
        {
            var dict = new Dictionary<int, Standing>();

            // 1. Участници в лигата
            var teams = Db.GetDataTable(
                "SELECT c.ClubId, c.Name FROM league_teams lt " +
                "JOIN clubs c ON c.ClubId = lt.ClubId WHERE lt.LeagueId = @L;",
                Db.Param("@L", leagueId));

            foreach (DataRow r in teams.Rows)
            {
                int id = Convert.ToInt32(r["ClubId"]);
                dict[id] = new Standing { ClubId = id, ClubName = r["Name"].ToString() ?? "" };
            }

            // 2. Всички изиграни мачове
            var matches = Db.GetDataTable(
                "SELECT m.HomeClubId, m.AwayClubId, m.HomeGoals, m.AwayGoals, " +
                "h.Name AS HomeName, a.Name AS AwayName " +
                "FROM matches m " +
                "JOIN clubs h ON h.ClubId = m.HomeClubId " +
                "JOIN clubs a ON a.ClubId = m.AwayClubId " +
                "WHERE m.LeagueId = @L " +
                "AND m.HomeGoals IS NOT NULL AND m.AwayGoals IS NOT NULL;",
                Db.Param("@L", leagueId));

            foreach (DataRow r in matches.Rows)
            {
                int homeId    = Convert.ToInt32(r["HomeClubId"]);
                int awayId    = Convert.ToInt32(r["AwayClubId"]);
                int homeGoals = Convert.ToInt32(r["HomeGoals"]);
                int awayGoals = Convert.ToInt32(r["AwayGoals"]);

                if (!dict.ContainsKey(homeId))
                    dict[homeId] = new Standing { ClubId = homeId, ClubName = r["HomeName"].ToString() ?? "" };
                if (!dict.ContainsKey(awayId))
                    dict[awayId] = new Standing { ClubId = awayId, ClubName = r["AwayName"].ToString() ?? "" };

                var home = dict[homeId];
                var away = dict[awayId];

                home.MatchesPlayed++; away.MatchesPlayed++;
                home.GoalsFor += homeGoals; home.GoalsAgainst += awayGoals;
                away.GoalsFor += awayGoals; away.GoalsAgainst += homeGoals;

                if      (homeGoals > awayGoals)  { home.Wins++;  away.Losses++; }
                else if (homeGoals == awayGoals)  { home.Draws++; away.Draws++;  }
                else                              { away.Wins++;  home.Losses++; }
            }

            // 3. Форма (последни 5 мача)
            BuildForm(leagueId, dict);

            // 4. Сортиране: Точки → Голова разлика → Отбелязани голове → Победи → Име
            var sorted = dict.Values
                .OrderByDescending(s => s.Points)
                .ThenByDescending(s => s.GoalDifference)
                .ThenByDescending(s => s.GoalsFor)
                .ThenByDescending(s => s.Wins)
                .ThenBy(s => s.ClubName)
                .ToList();

            for (int i = 0; i < sorted.Count; i++)
                sorted[i].Position = i + 1;

            return sorted;
        }

        private static void BuildForm(int leagueId, Dictionary<int, Standing> dict)
        {
            var rows = Db.GetDataTable(
                "SELECT HomeClubId, AwayClubId, HomeGoals, AwayGoals " +
                "FROM matches " +
                "WHERE LeagueId = @L " +
                "AND HomeGoals IS NOT NULL AND AwayGoals IS NOT NULL " +
                "ORDER BY MatchDate DESC, MatchId DESC;",
                Db.Param("@L", leagueId));

            var last5 = new Dictionary<int, List<char>>();

            foreach (DataRow r in rows.Rows)
            {
                int h  = Convert.ToInt32(r["HomeClubId"]);
                int a  = Convert.ToInt32(r["AwayClubId"]);
                int hg = Convert.ToInt32(r["HomeGoals"]);
                int ag = Convert.ToInt32(r["AwayGoals"]);

                if (!last5.ContainsKey(h)) last5[h] = new List<char>();
                if (!last5.ContainsKey(a)) last5[a] = new List<char>();

                if (last5[h].Count < 5)
                    last5[h].Add(hg > ag ? 'W' : hg == ag ? 'D' : 'L');
                if (last5[a].Count < 5)
                    last5[a].Add(ag > hg ? 'W' : ag == hg ? 'D' : 'L');
            }

            foreach (var kvp in last5)
                if (dict.ContainsKey(kvp.Key))
                    dict[kvp.Key].Форма = string.Concat(kvp.Value.Select(c =>
                        c == 'W' ? "W" : c == 'D' ? "D" : "L"));
        }

        public (int pts1, int pts2) GetHeadToHead(int leagueId, int clubId1, int clubId2)
        {
            var rows = Db.GetDataTable(
                "SELECT HomeClubId, HomeGoals, AwayGoals FROM matches " +
                "WHERE LeagueId = @L " +
                "AND HomeGoals IS NOT NULL AND AwayGoals IS NOT NULL " +
                "AND ((HomeClubId = @C1 AND AwayClubId = @C2) " +
                "  OR (HomeClubId = @C2 AND AwayClubId = @C1));",
                Db.Param("@L",  leagueId),
                Db.Param("@C1", clubId1),
                Db.Param("@C2", clubId2));

            int pts1 = 0, pts2 = 0;
            foreach (DataRow r in rows.Rows)
            {
                int h  = Convert.ToInt32(r["HomeClubId"]);
                int hg = Convert.ToInt32(r["HomeGoals"]);
                int ag = Convert.ToInt32(r["AwayGoals"]);
                bool homeIsC1 = h == clubId1;

                if      (hg > ag)  { if (homeIsC1) pts1 += 3; else pts2 += 3; }
                else if (hg == ag) { pts1++; pts2++; }
                else               { if (homeIsC1) pts2 += 3; else pts1 += 3; }
            }
            return (pts1, pts2);
        }
    }
}
