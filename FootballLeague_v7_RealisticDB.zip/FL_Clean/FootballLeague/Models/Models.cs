namespace FootballLeague.Models
{
    public class Club
    {
        public int ClubId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public DateTime? CreatedAt { get; set; }
        public override string ToString() => Name;
    }

    public class Player
    {
        public int PlayerId { get; set; }
        public int ClubId { get; set; }
        public string ClubName { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public DateTime BirthDate { get; set; }
        public string Position { get; set; } = string.Empty;
        public int? ShirtNumber { get; set; }
        public string Status { get; set; } = "Active";
        public int Age => DateTime.Today.Year - BirthDate.Year
                          - (DateTime.Today.DayOfYear < BirthDate.DayOfYear ? 1 : 0);
        public override string ToString() => $"{FullName} [{Position}]";
    }

    public class Transfer
    {
        public int TransferId { get; set; }
        public int PlayerId { get; set; }
        public string PlayerName { get; set; } = string.Empty;
        public int? FromClubId { get; set; }
        public string FromClubName { get; set; } = "Free agent";
        public int ToClubId { get; set; }
        public string ToClubName { get; set; } = string.Empty;
        public DateTime TransferDate { get; set; }
        public decimal? Fee { get; set; }
        public string Note { get; set; } = string.Empty;
    }

    public class League
    {
        public int LeagueId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Season { get; set; } = string.Empty;
        public int TeamCount { get; set; }
        public override string ToString() => $"{Name} ({Season})";
    }

    public class Match
    {
        public int MatchId { get; set; }
        public int LeagueId { get; set; }
        public string LeagueName { get; set; } = string.Empty;
        public int RoundNo { get; set; }
        public int HomeClubId { get; set; }
        public string HomeClubName { get; set; } = string.Empty;
        public string HomeClubCity { get; set; } = string.Empty;
        public int AwayClubId { get; set; }
        public string AwayClubName { get; set; } = string.Empty;
        public string AwayClubCity { get; set; } = string.Empty;
        public DateTime? MatchDate { get; set; }
        public string Stadium { get; set; } = string.Empty;
        public int? HomeGoals { get; set; }
        public int? AwayGoals { get; set; }
        public bool IsPlayed => HomeGoals.HasValue && AwayGoals.HasValue;
        public int HomePlayers { get; set; }
        public int AwayPlayers { get; set; }
        public string Домакин => $"{HomeClubName} ({HomeClubCity})";
        public string Гост => $"{AwayClubName} ({AwayClubCity})";
        public string Резултат => IsPlayed ? $"{HomeGoals} : {AwayGoals}" : "— не изигран —";
        public string Дата => MatchDate.HasValue ? MatchDate.Value.ToString("dd.MM.yyyy") : "—";
    }

    public class Goal
    {
        public int GoalId { get; set; }
        public int MatchId { get; set; }
        public int PlayerId { get; set; }
        public string PlayerName { get; set; } = string.Empty;
        public int ClubId { get; set; }
        public string ClubName { get; set; } = string.Empty;
        public int Minute { get; set; }
        public bool IsOwnGoal { get; set; }
        public string Тип => IsOwnGoal ? "⚽ Автогол" : "⚽ Гол";
        public string Минута => $"{Minute}'";
    }

    public class Card
    {
        public int CardId { get; set; }
        public int MatchId { get; set; }
        public int PlayerId { get; set; }
        public string PlayerName { get; set; } = string.Empty;
        public int ClubId { get; set; }
        public string ClubName { get; set; } = string.Empty;
        public string CardType { get; set; } = "Yellow";
        public int Minute { get; set; }
        public string Тип => CardType == "Red" ? "🟥 Червен" : "🟨 Жълт";
        public string Минута => $"{Minute}'";
    }

    public class Foul
    {
        public int FoulId { get; set; }
        public int MatchId { get; set; }
        public int PlayerId { get; set; }
        public string PlayerName { get; set; } = string.Empty;
        public int ClubId { get; set; }
        public string ClubName { get; set; } = string.Empty;
        public int Minute { get; set; }
        public string FoulType { get; set; } = string.Empty;
        public string Минута => $"{Minute}'";
    }

    public class Standing
    {
        public int    ClubId         { get; set; }
        public int    Position       { get; set; }
        public string ClubName       { get; set; } = string.Empty;
        public int    MatchesPlayed  { get; set; }
        public int    Wins           { get; set; }
        public int    Draws          { get; set; }
        public int    Losses         { get; set; }
        public int    GoalsFor       { get; set; }
        public int    GoalsAgainst   { get; set; }
        public int    GoalDifference => GoalsFor - GoalsAgainst;
        public int    Points         => Wins * 3 + Draws;
        // Display helpers
        public string Голове    => $"{GoalsFor} : {GoalsAgainst}";
        public string Разлика   => GoalDifference > 0 ? $"+{GoalDifference}" : $"{GoalDifference}";
        public string Форма     { get; set; } = string.Empty; // last 5 results W/D/L
    }
}
