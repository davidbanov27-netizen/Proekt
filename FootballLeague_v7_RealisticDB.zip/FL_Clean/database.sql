-- ============================================================
--  Football League – Реалистична Българска База Данни
--  Сезон 2024/2025 – Първа Професионална Лига
--  Инструкции:
--  1. phpMyAdmin → SQL → постави → Go
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS football_league
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE football_league;

DROP TABLE IF EXISTS fouls;
DROP TABLE IF EXISTS cards;
DROP TABLE IF EXISTS goals;
DROP TABLE IF EXISTS matches;
DROP TABLE IF EXISTS league_teams;
DROP TABLE IF EXISTS transfers;
DROP TABLE IF EXISTS players;
DROP TABLE IF EXISTS clubs;
DROP TABLE IF EXISTS leagues;

SET FOREIGN_KEY_CHECKS = 1;

-- ════════════════════════════════════════════════════════════
--  ТАБЛИЦИ
-- ════════════════════════════════════════════════════════════

CREATE TABLE clubs (
    ClubId    INT          NOT NULL AUTO_INCREMENT,
    Name      VARCHAR(100) NOT NULL,
    City      VARCHAR(80)  NULL,
    CreatedAt DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_clubs      PRIMARY KEY (ClubId),
    CONSTRAINT uq_clubs_name UNIQUE (Name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE leagues (
    LeagueId  INT          NOT NULL AUTO_INCREMENT,
    Name      VARCHAR(100) NOT NULL,
    Season    VARCHAR(20)  NOT NULL,
    TeamCount INT          NOT NULL DEFAULT 0,
    CONSTRAINT pk_leagues       PRIMARY KEY (LeagueId),
    CONSTRAINT uq_league_season UNIQUE (Name, Season)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE players (
    PlayerId    INT          NOT NULL AUTO_INCREMENT,
    ClubId      INT          NOT NULL,
    FullName    VARCHAR(120) NOT NULL,
    BirthDate   DATE         NOT NULL,
    Position    ENUM('GK','DF','MF','FW') NOT NULL,
    ShirtNumber TINYINT      NULL,
    Status      ENUM('Active','Injured','Suspended') NOT NULL DEFAULT 'Active',
    CONSTRAINT pk_players      PRIMARY KEY (PlayerId),
    CONSTRAINT fk_players_club FOREIGN KEY (ClubId)
        REFERENCES clubs(ClubId) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT uq_player_shirt UNIQUE (ClubId, ShirtNumber)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE transfers (
    TransferId   INT           NOT NULL AUTO_INCREMENT,
    PlayerId     INT           NOT NULL,
    FromClubId   INT           NULL,
    ToClubId     INT           NOT NULL,
    TransferDate DATE          NOT NULL,
    Fee          DECIMAL(12,2) NULL,
    Note         TEXT          NULL,
    CONSTRAINT pk_transfers       PRIMARY KEY (TransferId),
    CONSTRAINT fk_transfer_player FOREIGN KEY (PlayerId)
        REFERENCES players(PlayerId) ON DELETE RESTRICT,
    CONSTRAINT fk_transfer_from   FOREIGN KEY (FromClubId)
        REFERENCES clubs(ClubId) ON DELETE RESTRICT,
    CONSTRAINT fk_transfer_to     FOREIGN KEY (ToClubId)
        REFERENCES clubs(ClubId) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE league_teams (
    LeagueId INT NOT NULL,
    ClubId   INT NOT NULL,
    CONSTRAINT pk_league_teams PRIMARY KEY (LeagueId, ClubId),
    CONSTRAINT fk_lt_league    FOREIGN KEY (LeagueId)
        REFERENCES leagues(LeagueId) ON DELETE CASCADE,
    CONSTRAINT fk_lt_club      FOREIGN KEY (ClubId)
        REFERENCES clubs(ClubId) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE matches (
    MatchId    INT          NOT NULL AUTO_INCREMENT,
    LeagueId   INT          NOT NULL,
    RoundNo    INT          NOT NULL,
    HomeClubId INT          NOT NULL,
    AwayClubId INT          NOT NULL,
    MatchDate  DATE         NULL,
    Stadium    VARCHAR(120) NULL,
    HomeGoals  INT          NULL,
    AwayGoals  INT          NULL,
    CONSTRAINT pk_matches      PRIMARY KEY (MatchId),
    CONSTRAINT fk_match_league FOREIGN KEY (LeagueId)
        REFERENCES leagues(LeagueId) ON DELETE CASCADE,
    CONSTRAINT fk_match_home   FOREIGN KEY (HomeClubId)
        REFERENCES clubs(ClubId) ON DELETE RESTRICT,
    CONSTRAINT fk_match_away   FOREIGN KEY (AwayClubId)
        REFERENCES clubs(ClubId) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE goals (
    GoalId    INT  NOT NULL AUTO_INCREMENT,
    MatchId   INT  NOT NULL,
    PlayerId  INT  NOT NULL,
    ClubId    INT  NOT NULL,
    Minute    INT  NOT NULL,
    IsOwnGoal BOOL NOT NULL DEFAULT 0,
    CONSTRAINT pk_goals       PRIMARY KEY (GoalId),
    CONSTRAINT fk_goal_match  FOREIGN KEY (MatchId)
        REFERENCES matches(MatchId) ON DELETE CASCADE,
    CONSTRAINT fk_goal_player FOREIGN KEY (PlayerId)
        REFERENCES players(PlayerId) ON DELETE RESTRICT,
    CONSTRAINT fk_goal_club   FOREIGN KEY (ClubId)
        REFERENCES clubs(ClubId) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE cards (
    CardId   INT                  NOT NULL AUTO_INCREMENT,
    MatchId  INT                  NOT NULL,
    PlayerId INT                  NOT NULL,
    CardType ENUM('Yellow','Red') NOT NULL DEFAULT 'Yellow',
    Minute   INT                  NOT NULL,
    CONSTRAINT pk_cards       PRIMARY KEY (CardId),
    CONSTRAINT fk_card_match  FOREIGN KEY (MatchId)
        REFERENCES matches(MatchId) ON DELETE CASCADE,
    CONSTRAINT fk_card_player FOREIGN KEY (PlayerId)
        REFERENCES players(PlayerId) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE fouls (
    FoulId   INT          NOT NULL AUTO_INCREMENT,
    MatchId  INT          NOT NULL,
    PlayerId INT          NOT NULL,
    Minute   INT          NOT NULL,
    FoulType VARCHAR(80)  NULL,
    CONSTRAINT pk_fouls       PRIMARY KEY (FoulId),
    CONSTRAINT fk_foul_match  FOREIGN KEY (MatchId)
        REFERENCES matches(MatchId) ON DELETE CASCADE,
    CONSTRAINT fk_foul_player FOREIGN KEY (PlayerId)
        REFERENCES players(PlayerId) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ════════════════════════════════════════════════════════════
--  КЛУБОВЕ  (14 отбора от Първа Лига + 4 от Втора)
-- ════════════════════════════════════════════════════════════

INSERT INTO clubs (Name, City) VALUES
-- Първа Лига
('Лудогорец',          'Разград'),
('ЦСКА',               'София'),
('Левски',             'София'),
('Ботев Пловдив',      'Пловдив'),
('Берое',              'Стара Загора'),
('Локомотив Пловдив',  'Пловдив'),
('ЦСКА 1948',          'София'),
('Черно море',         'Варна'),
('Арда',               'Кърджали'),
('Пирин',              'Благоевград'),
('Ботев Враца',        'Враца'),
('Хебър',              'Пазарджик'),
('Спартак Варна',      'Варна'),
('Локомотив София',    'София'),
-- Втора Лига
('Марек Дупница',      'Дупница'),
('Добруджа',           'Добрич'),
('Нефтохимик',         'Бургас'),
('Академик София',     'София');

-- ════════════════════════════════════════════════════════════
--  ЛИГИ
-- ════════════════════════════════════════════════════════════

INSERT INTO leagues (Name, Season, TeamCount) VALUES
('Първа Професионална Лига', '2024/2025', 14),
('Първа Професионална Лига', '2023/2024', 14),
('Втора Лига',               '2024/2025', 4);

-- ════════════════════════════════════════════════════════════
--  УЧАСТНИЦИ
-- ════════════════════════════════════════════════════════════

-- Първа Лига 2024/2025 (LeagueId=1): клубове 1-14
INSERT INTO league_teams (LeagueId, ClubId) VALUES
(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),
(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14);

-- Първа Лига 2023/2024 (LeagueId=2): клубове 1-14
INSERT INTO league_teams (LeagueId, ClubId) VALUES
(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),
(2,8),(2,9),(2,10),(2,11),(2,12),(2,13),(2,14);

-- Втора Лига 2024/2025 (LeagueId=3): клубове 15-18
INSERT INTO league_teams (LeagueId, ClubId) VALUES
(3,15),(3,16),(3,17),(3,18);

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – ЛУДОГОРЕЦ (ClubId=1)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(1, 'Иван Неделев',         '1993-07-15', 'GK', 1,  'Active'),
(1, 'Драгомир Стоянов',     '1997-03-22', 'GK', 30, 'Active'),
(1, 'Антон Недялков',       '1995-11-08', 'DF', 2,  'Active'),
(1, 'Матеус Дантас',        '1998-06-14', 'DF', 4,  'Active'),
(1, 'Алекс Лангович',       '1996-09-30', 'DF', 5,  'Active'),
(1, 'Кирил Десподов',       '1996-11-11', 'DF', 6,  'Active'),
(1, 'Иван Турицов',         '2000-02-17', 'DF', 3,  'Active'),
(1, 'Виктор Жоли',          '1994-04-05', 'MF', 7,  'Active'),
(1, 'Томаш Пекхарт',        '1989-05-26', 'MF', 8,  'Active'),
(1, 'Рикардо Алвес',        '1997-08-19', 'MF', 10, 'Active'),
(1, 'Себастиан Попов',      '1995-12-03', 'MF', 14, 'Active'),
(1, 'Бернар Текпетей',      '1997-01-07', 'MF', 17, 'Active'),
(1, 'Стриниц Никола',       '1993-03-25', 'FW', 9,  'Active'),
(1, 'Клаудиньо',            '1996-07-11', 'FW', 11, 'Active'),
(1, 'Жозе Луис Моро',       '1995-10-28', 'FW', 19, 'Active'),
(1, 'Тиаго Л. Кунха',       '1999-04-16', 'FW', 21, 'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – ЦСКА (ClubId=2)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(2, 'Густаво Бусато',       '1994-02-14', 'GK', 1,  'Active'),
(2, 'Иван Горанов',         '1992-06-20', 'GK', 23, 'Active'),
(2, 'Тодор Неделев',        '1993-09-15', 'DF', 2,  'Active'),
(2, 'Спас Делев',           '1989-12-04', 'DF', 4,  'Active'),
(2, 'Мартин Минчев',        '1997-07-08', 'DF', 5,  'Active'),
(2, 'Джейхан Абаз',         '1995-03-17', 'DF', 26, 'Active'),
(2, 'Иван Димитров',        '1998-11-22', 'DF', 33, 'Active'),
(2, 'Гарет Еванс',          '1990-01-14', 'MF', 6,  'Active'),
(2, 'Фелипе Бризола',       '1996-05-09', 'MF', 8,  'Active'),
(2, 'Родриго Пиньейро',     '1998-08-23', 'MF', 10, 'Active'),
(2, 'Томас Симоеш',         '1997-04-11', 'MF', 14, 'Active'),
(2, 'Кевин Столтидис',      '1993-10-30', 'FW', 7,  'Active'),
(2, 'Тiago Caiado',         '1996-06-18', 'FW', 9,  'Active'),
(2, 'Юлиан Попов',          '2001-02-27', 'FW', 11, 'Active'),
(2, 'Ивелин Попов',         '1987-10-26', 'FW', 17, 'Injured'),
(2, 'Тонислав Стойчев',     '1999-09-01', 'MF', 20, 'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – ЛЕВСКИ (ClubId=3)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(3, 'Николай Михайлов',     '1988-06-28', 'GK', 1,  'Active'),
(3, 'Дарко Тасевски',       '1995-11-14', 'GK', 12, 'Active'),
(3, 'Звонимир Шарлия',      '1994-03-06', 'DF', 2,  'Active'),
(3, 'Валентин Антов',       '1997-01-26', 'DF', 4,  'Active'),
(3, 'Ивайло Чочев',         '1993-02-18', 'DF', 5,  'Active'),
(3, 'Симеон Славчев',       '1995-07-25', 'DF', 3,  'Active'),
(3, 'Светослав Ковачев',    '1999-04-12', 'DF', 33, 'Active'),
(3, 'Красимир Костов',      '1991-08-08', 'MF', 6,  'Active'),
(3, 'Пейчо Пейчев',         '1996-12-31', 'MF', 8,  'Active'),
(3, 'Марселиньо',           '1993-05-19', 'MF', 10, 'Active'),
(3, 'Ален Омерович',        '1998-09-07', 'MF', 14, 'Active'),
(3, 'Давид Шипка',          '2001-03-15', 'MF', 22, 'Active'),
(3, 'Бернар Дафу',          '1996-11-02', 'FW', 9,  'Active'),
(3, 'Ивайло Димитров',      '1999-07-20', 'FW', 11, 'Active'),
(3, 'Алекс Колев',          '2000-01-09', 'FW', 19, 'Active'),
(3, 'Тодор Тасев',          '1994-06-14', 'FW', 7,  'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – БОТЕВ ПЛОВДИВ (ClubId=4)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(4, 'Антон Илиев',          '1992-04-03', 'GK', 1,  'Active'),
(4, 'Константин Самунев',   '1996-10-17', 'GK', 77, 'Active'),
(4, 'Христо Йовов',         '1994-08-11', 'DF', 2,  'Active'),
(4, 'Генади Жеков',         '1993-05-28', 'DF', 4,  'Active'),
(4, 'Борис Гилерме',        '1990-12-22', 'DF', 5,  'Active'),
(4, 'Стефан Велев',         '1997-02-19', 'DF', 3,  'Active'),
(4, 'Радослав Кирилов',     '2000-07-04', 'DF', 27, 'Active'),
(4, 'Радослав Живков',      '1995-09-09', 'MF', 6,  'Active'),
(4, 'Алесандро Скафиди',    '1997-11-13', 'MF', 8,  'Active'),
(4, 'Везир Унал',           '1994-03-07', 'MF', 10, 'Active'),
(4, 'Кирил Радев',          '1998-06-24', 'MF', 14, 'Active'),
(4, 'Симон Лукаш',          '1996-01-30', 'MF', 18, 'Active'),
(4, 'Николай Бодуров',      '1992-05-16', 'FW', 9,  'Active'),
(4, 'Тодор Неделев',        '1996-08-08', 'FW', 11, 'Injured'),
(4, 'Петко Христов',        '2001-04-21', 'FW', 19, 'Active'),
(4, 'Ивайло Стоянов',       '1999-10-10', 'MF', 21, 'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – БЕРОЕ (ClubId=5)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(5, 'Никола Данчев',        '1993-01-15', 'GK', 1,  'Active'),
(5, 'Мартин Богданов',      '1997-07-22', 'GK', 16, 'Active'),
(5, 'Йоан Малик',           '1994-04-18', 'DF', 2,  'Active'),
(5, 'Лукаш Новак',          '1996-09-03', 'DF', 4,  'Active'),
(5, 'Йелко Томич',          '1993-12-11', 'DF', 5,  'Active'),
(5, 'Александър Александров','1998-05-27', 'DF', 3,  'Active'),
(5, 'Костадин Стоянов',     '2000-08-14', 'DF', 23, 'Active'),
(5, 'Ивайло Стоянов',       '1995-03-06', 'MF', 6,  'Suspended'),
(5, 'Петко Василев',        '1997-11-19', 'MF', 8,  'Active'),
(5, 'Жоао Пауло',           '1994-06-08', 'MF', 10, 'Active'),
(5, 'Пламен Крумов',        '1999-01-25', 'MF', 14, 'Active'),
(5, 'Стефан Попов',         '1996-10-02', 'MF', 17, 'Active'),
(5, 'Кристиан Дяков',       '1995-07-30', 'FW', 9,  'Active'),
(5, 'Светослав Иванов',     '1998-04-16', 'FW', 11, 'Active'),
(5, 'Мирослав Михайлов',    '2001-12-05', 'FW', 19, 'Active'),
(5, 'Красимир Йорданов',    '1993-09-20', 'FW', 7,  'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – ЛОКОМОТИВ ПЛОВДИВ (ClubId=6)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(6, 'Пламен Илиев',         '1991-02-28', 'GK', 1,  'Active'),
(6, 'Мартин Стоев',         '1997-06-14', 'GK', 22, 'Active'),
(6, 'Красимир Динев',       '1994-03-19', 'DF', 2,  'Active'),
(6, 'Жоао Карвальо',        '1996-08-07', 'DF', 4,  'Active'),
(6, 'Никола Сираков',       '1993-11-23', 'DF', 5,  'Active'),
(6, 'Владимир Гаджев',      '1998-04-10', 'DF', 3,  'Active'),
(6, 'Момчил Цветанов',      '2000-01-17', 'DF', 25, 'Active'),
(6, 'Чавдар Янков',         '1995-07-05', 'MF', 6,  'Active'),
(6, 'Неманя Михайлович',    '1997-12-28', 'MF', 8,  'Active'),
(6, 'Бойко Борисов',        '1994-05-22', 'MF', 10, 'Active'),
(6, 'Петър Занев',          '1999-09-11', 'MF', 14, 'Active'),
(6, 'Ерик Дарко',           '1996-03-14', 'MF', 18, 'Active'),
(6, 'Алесандър Колев',      '1995-10-01', 'FW', 9,  'Active'),
(6, 'Неманя Радович',       '1998-06-29', 'FW', 11, 'Injured'),
(6, 'Иван Иванов',          '2001-02-13', 'FW', 19, 'Active'),
(6, 'Даниел Методиев',      '1993-08-16', 'FW', 7,  'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – ЦСКА 1948 (ClubId=7)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(7, 'Виктор Попов',         '1993-05-12', 'GK', 1,  'Active'),
(7, 'Тодор Колев',          '1998-09-26', 'GK', 13, 'Active'),
(7, 'Мариян Огнянов',       '1995-01-08', 'DF', 2,  'Active'),
(7, 'Стойо Стоянов',        '1993-06-17', 'DF', 4,  'Active'),
(7, 'Давид Ранджелович',    '1997-03-24', 'DF', 5,  'Active'),
(7, 'Елиф Елмас',           '1999-09-28', 'DF', 3,  'Active'),
(7, 'Стефан Стефанов',      '2001-07-04', 'DF', 29, 'Active'),
(7, 'Михаил Александров',   '1995-11-15', 'MF', 6,  'Active'),
(7, 'Жоао Карвальо',        '1997-04-02', 'MF', 8,  'Active'),
(7, 'Ивайло Чочев',         '1994-08-20', 'MF', 10, 'Active'),
(7, 'Никола Бодуров',       '1996-12-09', 'MF', 14, 'Active'),
(7, 'Тодор Цветков',        '1999-05-18', 'MF', 20, 'Active'),
(7, 'Стивън Петков',        '1995-02-11', 'FW', 9,  'Active'),
(7, 'Марселиньо Жуниор',    '1998-10-07', 'FW', 11, 'Active'),
(7, 'Валентин Иванов',      '2000-06-23', 'FW', 17, 'Active'),
(7, 'Костадин Хазуров',     '1997-01-30', 'FW', 7,  'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – ЧЕРНО МОРЕ (ClubId=8)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(8, 'Николай Стоянов',      '1992-08-14', 'GK', 1,  'Active'),
(8, 'Димитър Янков',        '1997-11-03', 'GK', 25, 'Active'),
(8, 'Никола Чурлинов',      '1998-04-27', 'DF', 2,  'Active'),
(8, 'Тодор Богданов',       '1994-07-16', 'DF', 4,  'Active'),
(8, 'Зоран Петрович',       '1993-02-09', 'DF', 5,  'Active'),
(8, 'Кристиан Марков',      '1999-10-21', 'DF', 3,  'Active'),
(8, 'Дилян Пейчев',         '2000-05-08', 'DF', 27, 'Active'),
(8, 'Иво Иванов',           '1995-08-30', 'MF', 6,  'Active'),
(8, 'Стефан Апостолов',     '1997-03-18', 'MF', 8,  'Active'),
(8, 'Боян Йоргич',          '1996-05-25', 'MF', 10, 'Active'),
(8, 'Мартин Коев',          '1999-12-14', 'MF', 14, 'Suspended'),
(8, 'Пламен Димитров',      '1996-06-07', 'MF', 18, 'Active'),
(8, 'Стефан Дерменджиев',   '1994-09-22', 'FW', 9,  'Active'),
(8, 'Вениамин Манолев',     '1998-01-11', 'FW', 11, 'Active'),
(8, 'Александър Миланов',   '2001-07-28', 'FW', 19, 'Active'),
(8, 'Симеон Цветков',       '1993-04-05', 'FW', 7,  'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – АРДА (ClubId=9)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(9, 'Радостин Станев',      '1993-03-10', 'GK', 1,  'Active'),
(9, 'Митко Карагьозов',     '1998-07-19', 'GK', 12, 'Active'),
(9, 'Айхан Мустафа',        '1995-05-04', 'DF', 2,  'Active'),
(9, 'Ердал Ракип',          '1997-08-28', 'DF', 4,  'Active'),
(9, 'Зарко Маркович',       '1994-01-15', 'DF', 5,  'Active'),
(9, 'Исмаил Ибрахим',       '1999-11-07', 'DF', 3,  'Active'),
(9, 'Мустафа Демир',        '2001-04-23', 'DF', 22, 'Active'),
(9, 'Хасан Хасан',          '1995-09-16', 'MF', 6,  'Active'),
(9, 'Сезгин Осман',         '1997-02-05', 'MF', 8,  'Active'),
(9, 'Даниел Якимов',        '1994-06-20', 'MF', 10, 'Active'),
(9, 'Стоян Гунев',          '1999-03-12', 'MF', 14, 'Active'),
(9, 'Йълмаз Юнус',          '1996-10-28', 'MF', 17, 'Active'),
(9, 'Андрей Чавдаров',      '1995-07-14', 'FW', 9,  'Active'),
(9, 'Адем Адемов',          '1998-12-01', 'FW', 11, 'Active'),
(9, 'Маруан Чатах',         '2000-05-30', 'FW', 19, 'Active'),
(9, 'Деян Ивановски',       '1993-08-17', 'FW', 7,  'Active');

-- ════════════════════════════════════════════════════════════
--  ИГРАЧИ – ПИРИН (ClubId=10)
-- ════════════════════════════════════════════════════════════
INSERT INTO players (ClubId, FullName, BirthDate, Position, ShirtNumber, Status) VALUES
(10,'Стоян Котев',          '1992-11-08', 'GK', 1,  'Active'),
(10,'Страхил Попов',        '1997-04-25', 'GK', 24, 'Active'),
(10,'Мартин Вутов',         '1995-06-12', 'DF', 2,  'Active'),
(10,'Стефан Велков',        '1993-10-01', 'DF', 4,  'Active'),
(10,'Александър Везенков',  '1997-07-18', 'DF', 5,  'Active'),
(10,'Кирил Котев',          '1999-02-26', 'DF', 3,  'Active'),
(10,'Симеон Попков',        '2000-09-14', 'DF', 28, 'Active'),
(10,'Денислав Александров', '1995-04-08', 'MF', 6,  'Active'),
(10,'Евгени Минчев',        '1997-11-22', 'MF', 8,  'Active'),
(10,'Здравко Лазаров',      '1994-08-15', 'MF', 10, 'Active'),
(10,'Ивайло Стоилов',       '1999-05-03', 'MF', 14, 'Active'),
(10,'Венцислав Христов',    '1996-12-19', 'MF', 16, 'Active'),
(10,'Светослав Ковачев',    '1995-03-27', 'FW', 9,  'Active'),
(10,'Георги Йорданов',      '1998-07-09', 'FW', 11, 'Injured'),
(10,'Николай Велинов',      '2001-01-16', 'FW', 19, 'Active'),
(10,'Пейо Пейов',           '1993-10-24', 'FW', 7,  'Active');

-- ════════════════════════════════════════════════════════════
--  МАЧОВЕ – Кръг 1-7, Сезон 2024/2025 (LeagueId=1)
-- ════════════════════════════════════════════════════════════

INSERT INTO matches (LeagueId, RoundNo, HomeClubId, AwayClubId, MatchDate, Stadium, HomeGoals, AwayGoals) VALUES
-- Кръг 1
(1,1,1,2,  '2024-08-03','Хюбер Хюбчев Арена',      3,0),
(1,1,3,4,  '2024-08-03','Георги Аспарухов',          1,1),
(1,1,5,6,  '2024-08-04','Берое',                     2,1),
(1,1,7,8,  '2024-08-04','Армията',                   0,0),
(1,1,9,10, '2024-08-04','Арда',                      1,2),
(1,1,11,12,'2024-08-04','Христо Ботев Враца',        0,1),
(1,1,13,14,'2024-08-04','Спартак Варна',             2,0),

-- Кръг 2
(1,2,2,3,  '2024-08-10','Васил Левски',              1,2),
(1,2,4,5,  '2024-08-10','Пловдив',                   0,0),
(1,2,6,7,  '2024-08-11','Локомотив Пловдив',         1,3),
(1,2,8,9,  '2024-08-11','Черно море Варна',          2,0),
(1,2,10,11,'2024-08-11','Христо Ботев Благоевград',  1,1),
(1,2,12,13,'2024-08-11','Хебър',                     0,2),
(1,2,14,1, '2024-08-11','Георги Бенковски',          0,4),

-- Кръг 3
(1,3,1,3,  '2024-08-17','Хюбер Хюбчев Арена',       2,0),
(1,3,5,2,  '2024-08-17','Берое',                     0,1),
(1,3,7,4,  '2024-08-18','Армията',                   2,1),
(1,3,9,6,  '2024-08-18','Арда',                      0,0),
(1,3,11,8, '2024-08-18','Христо Ботев Враца',        1,2),
(1,3,13,10,'2024-08-18','Спартак Варна',             3,1),
(1,3,12,14,'2024-08-18','Хебър',                     1,0),

-- Кръг 4
(1,4,3,1,  '2024-08-24','Георги Аспарухов',          1,3),
(1,4,2,4,  '2024-08-24','Васил Левски',              2,0),
(1,4,6,5,  '2024-08-25','Локомотив Пловдив',         1,1),
(1,4,8,7,  '2024-08-25','Черно море Варна',          0,1),
(1,4,10,9, '2024-08-25','Христо Ботев Благоевград',  2,1),
(1,4,14,11,'2024-08-25','Георги Бенковски',          1,0),
(1,4,13,12,'2024-08-25','Спартак Варна',             2,1),

-- Кръг 5
(1,5,1,4,  '2024-08-31','Хюбер Хюбчев Арена',       4,0),
(1,5,2,5,  '2024-08-31','Васил Левски',              2,1),
(1,5,3,6,  '2024-09-01','Георги Аспарухов',          1,0),
(1,5,7,9,  '2024-09-01','Армията',                   1,1),
(1,5,8,10, '2024-09-01','Черно море Варна',          3,0),
(1,5,11,13,'2024-09-01','Христо Ботев Враца',        0,2),
(1,5,12,14,'2024-09-01','Хебър',                     2,0),

-- Кръг 6
(1,6,4,1,  '2024-09-14','Пловдив',                   0,2),
(1,6,5,3,  '2024-09-14','Берое',                     1,1),
(1,6,6,2,  '2024-09-15','Локомотив Пловдив',         0,3),
(1,6,9,7,  '2024-09-15','Арда',                      2,0),
(1,6,10,8, '2024-09-15','Христо Ботев Благоевград',  1,2),
(1,6,13,11,'2024-09-15','Спартак Варна',             1,0),
(1,6,14,12,'2024-09-15','Георги Бенковски',          0,1),

-- Кръг 7
(1,7,1,5,  '2024-09-21','Хюбер Хюбчев Арена',       2,0),
(1,7,2,6,  '2024-09-21','Васил Левски',              3,1),
(1,7,3,7,  '2024-09-22','Георги Аспарухов',          0,1),
(1,7,4,8,  '2024-09-22','Пловдив',                   2,2),
(1,7,9,11, '2024-09-22','Арда',                      1,0),
(1,7,10,13,'2024-09-22','Христо Ботев Благоевград',  0,1),
(1,7,12,14,'2024-09-22','Хебър',                     3,0);

-- ════════════════════════════════════════════════════════════
--  ГОЛОВЕ – избрани мачове за реализъм
-- ════════════════════════════════════════════════════════════

-- Кръг 1: Лудогорец 3:0 ЦСКА  (MatchId=1)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(1, 14, 1, 23, 0),  -- Клаудиньо
(1, 13, 1, 56, 0),  -- Стриниц
(1, 16, 1, 78, 0);  -- Тиаго Кунха

-- Кръг 1: Левски 1:1 Ботев Пловдив  (MatchId=2)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(2, 49, 3, 34, 0),  -- Бернар Дафу (Левски)
(2, 61, 4, 67, 0);  -- Николай Бодуров (Ботев)

-- Кръг 1: Берое 2:1 Лок.Пловдив  (MatchId=3)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(3, 78, 5, 15, 0),  -- Кристиан Дяков
(3, 80, 5, 72, 0),  -- Светослав Иванов
(3, 95, 6, 88, 0);  -- Алесандър Колев

-- Кръг 2: ЦСКА 1:2 Левски  (MatchId=8)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(8, 28, 2, 12, 0),  -- Кевин Столтидис
(8, 49, 3, 45, 0),  -- Бернар Дафу
(8, 51, 3, 81, 0);  -- Ивайло Димитров

-- Кръг 3: Лудогорец 2:0 Левски  (MatchId=15)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(15, 14, 1, 38, 0), -- Клаудиньо
(15, 11, 1, 77, 0); -- Себастиан Попов

-- Кръг 4: Левски 1:3 Лудогорец  (MatchId=22)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(22, 52, 3, 8,  0), -- Марселиньо
(22, 14, 1, 31, 0), -- Клаудиньо
(22, 13, 1, 60, 0), -- Стриниц
(22, 16, 1, 89, 0); -- Тиаго Кунха

-- Кръг 5: Лудогорец 4:0 Ботев  (MatchId=29)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(29, 14, 1, 10, 0),
(29, 16, 1, 33, 0),
(29, 13, 1, 55, 0),
(29, 15, 1, 71, 0);

-- Кръг 7: Лудогорец 2:0 Берое  (MatchId=43)
INSERT INTO goals (MatchId, PlayerId, ClubId, Minute, IsOwnGoal) VALUES
(43, 13, 1, 41, 0),
(43, 14, 1, 68, 0);

-- ════════════════════════════════════════════════════════════
--  КАРТОНИ
-- ════════════════════════════════════════════════════════════

INSERT INTO cards (MatchId, PlayerId, CardType, Minute) VALUES
(1,  18, 'Yellow', 34),  -- ЦСКА играч
(1,  19, 'Yellow', 67),
(2,  36, 'Yellow', 22),  -- Левски
(2,  65, 'Yellow', 55),  -- Ботев
(8,  22, 'Yellow', 38),
(8,  45, 'Yellow', 72),
(8,  45, 'Red',    85),  -- Втори жълт
(15, 37, 'Yellow', 44),
(22, 33, 'Yellow', 15),
(22, 2,  'Yellow', 79),
(29, 61, 'Red',    50);

-- ════════════════════════════════════════════════════════════
--  ТРАНСФЕРИ  (реалистични за лятото на 2024)
-- ════════════════════════════════════════════════════════════

INSERT INTO transfers (PlayerId, FromClubId, ToClubId, TransferDate, Fee, Note) VALUES
(14, NULL, 1, '2024-07-01', 2500000.00, 'Клаудиньо – закупен от Спортинг'),
(13, NULL, 1, '2024-07-10', 1800000.00, 'Стриниц – закупен от Ференцварош'),
(28, NULL, 2, '2024-07-05', 1200000.00, 'Кевин Столтидис – закупен от Олимпиакос'),
(49, 4,    3, '2024-07-15', 600000.00,  'Бернар Дафу – трансфер от Ботев Пловдив'),
(30, 3,    1, '2024-08-01', 350000.00,  'Антон Недялков – трансфер от Левски'),
(95, NULL, 6, '2024-07-20', 0.00,       'Алесандър Колев – свободен агент'),
(78, NULL, 5, '2024-07-12', 450000.00,  'Кристиан Дяков – закупен от Локомотив');

-- ════════════════════════════════════════════════════════════
--  РЕЗУЛТАТ
-- ════════════════════════════════════════════════════════════
SELECT
  CONCAT('✅ База готова! Отбори: ', (SELECT COUNT(*) FROM clubs),
         ' | Играчи: ',              (SELECT COUNT(*) FROM players),
         ' | Мачове: ',              (SELECT COUNT(*) FROM matches),
         ' | Голове: ',              (SELECT COUNT(*) FROM goals)) AS Статус;
